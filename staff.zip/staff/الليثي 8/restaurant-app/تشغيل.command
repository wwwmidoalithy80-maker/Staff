#!/bin/bash
cd "$(dirname "$0")"
echo "=================================================="
echo "  الشيف ابراهيم الليثي - إدارة الفروع والموظفين"
echo "=================================================="
echo ""

# التأكد إن Python3 مثبت أصلاً
if ! command -v python3 &> /dev/null; then
    echo "❌ خطأ: Python3 مش مثبت على الجهاز ده."
    echo ""
    echo "الحل: حمّل Python من الموقع الرسمي وثبّته:"
    echo "https://www.python.org/downloads/macos/"
    echo ""
    echo "بعد التثبيت، أعد تشغيل هذا الملف تاني."
    echo ""
    read -p "اضغط Enter للخروج..."
    exit 1
fi

echo "✅ Python3 موجود: $(python3 --version)"
echo ""
echo "جاري تجهيز البرنامج لأول مرة (قد يستغرق دقيقة واحدة)..."
python3 -m pip install -r requirements.txt --quiet --disable-pip-version-check

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ فشل تثبيت المكتبات المطلوبة (Flask وغيرها)."
    echo "تأكد إن جهازك متصل بالإنترنت، وجرب تاني."
    echo ""
    read -p "اضغط Enter للخروج..."
    exit 1
fi

echo "✅ المكتبات جاهزة."
echo ""
echo "=================================================="
echo "  التطبيق شغال الآن. لا تغلق هذه النافذة."
echo "  افتح المتصفح على العنوان: http://localhost:5050"
echo "=================================================="
echo ""

# فتح المتصفح تلقائيًا بعد ثانيتين من بدء تشغيل السيرفر
( sleep 2 && open "http://localhost:5050" ) &

python3 app.py

echo ""
echo "التطبيق اتوقف. لو ده حصل من غير ما تقفل النافذة بنفسك، فيه خطأ ظهر فوق."
read -p "اضغط Enter للخروج..."
