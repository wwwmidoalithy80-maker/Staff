@echo off
title Restaurant Management App
cd /d "%~dp0"

echo ============================================
echo   Setting up the app for the first time...
echo   (this may take a minute)
echo ============================================
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python
) else (
    where py >nul 2>nul
    if %errorlevel%==0 (
        set PYCMD=py
    ) else (
        echo ERROR: Python is not installed or not in PATH.
        echo Please install Python from python.org and check "Add python.exe to PATH" during setup.
        pause
        exit /b 1
    )
)

echo Using: %PYCMD%
%PYCMD% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Failed to install required packages. Check your internet connection.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   App is starting. Do NOT close this window.
echo   Open your browser and go to:
echo   http://localhost:5050
echo ============================================
echo.

%PYCMD% app.py

pause
