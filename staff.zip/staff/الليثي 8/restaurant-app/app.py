"""
تطبيق إدارة شركة المطاعم - وحدة الموظفين (حضور / إجازات / رواتب / أقسام / صلاحيات)
يعمل محليًا بالكامل - لا يحتاج إنترنت.
تشغيل: python app.py  ثم افتح المتصفح على http://localhost:5050
"""
import io
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import zlib
import uuid
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file, g, abort,
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import date, datetime, timedelta
import calendar
import database as db
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10MB حد أقصى لأي ملف مرفوع

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ALLOWED_UPLOAD_EXT = {"jpg", "jpeg", "png", "webp", "pdf"}


def _get_or_create_secret_key():
    key_path = os.path.join(BASE_DIR, "data", "secret.key")
    os.makedirs(os.path.dirname(key_path), exist_ok=True)
    if os.path.exists(key_path):
        with open(key_path, "r") as f:
            return f.read().strip()
    key = secrets.token_hex(32)
    with open(key_path, "w") as f:
        f.write(key)
    return key


app.secret_key = os.environ.get("APP_SECRET_KEY") or _get_or_create_secret_key()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
)

# وضع التشخيص: مقفول افتراضيًا (لأنه بيفتح ثغرة تنفيذ أوامر لأي جهاز على الشبكة).
# للتطوير فقط: شغّل بـ APP_DEBUG=1 وعلى جهازك وحده (APP_HOST=127.0.0.1).
DEBUG_MODE = os.environ.get("APP_DEBUG", "0") == "1"

# الشهر المحاسبي يبدأ يوم 29 من كل شهر ميلادي وينتهي يوم 28 من الشهر اللي بعده
MONTH_START_DAY = 29
DEPARTMENTS = db.DEPARTMENTS
DOCUMENT_TYPES = db.DOCUMENT_TYPES
PERMISSIONS = db.PERMISSIONS

db.init_db()


# ---------------------------------------------------------------- Helpers --
def get_conn():
    """اتصال واحد بقاعدة البيانات لكل طلب، بيتقفل تلقائيًا في النهاية حتى لو حصل خطأ."""
    if "db_conn" not in g:
        g.db_conn = db.get_db()
    return g.db_conn


@app.teardown_appcontext
def close_conn(exception=None):
    conn = g.pop("db_conn", None)
    if conn is not None:
        try:
            if exception:
                conn.rollback()
        finally:
            conn.close()


def current_user():
    if "user_id" not in session:
        return None
    if "_cu" in g:
        return g._cu
    conn = get_conn()
    u = conn.execute(
        """SELECT u.*, r.name AS role_name, r.permissions AS role_permissions
           FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?""",
        (session["user_id"],),
    ).fetchone()
    g._cu = u
    return u


def user_permissions(user):
    if not user or not user["role_permissions"]:
        return set()
    return set(user["role_permissions"].split(","))


def has_permission(user, key):
    return key in user_permissions(user)


def login_required(view):
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    wrapped.__name__ = view.__name__
    return wrapped


def permission_required(key):
    def decorator(view):
        def wrapped(*args, **kwargs):
            u = current_user()
            if not u:
                return redirect(url_for("login"))
            if not has_permission(u, key):
                flash("لا تملك صلاحية الوصول لهذه الصفحة", "error")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        wrapped.__name__ = view.__name__
        return wrapped
    return decorator


def accessible_branch_ids(user):
    """الفروع المسموح للمستخدم يشوفها: NULL = كل الفروع"""
    conn = get_conn()
    if user["branch_id"] is None:
        rows = conn.execute("SELECT id FROM branches").fetchall()
    else:
        rows = conn.execute("SELECT id FROM branches WHERE id = ?", (user["branch_id"],)).fetchall()
    return [r["id"] for r in rows]


def dept_clause(user, alias="e"):
    """جزء SQL إضافي لتقييد الاستعلام بقسم المستخدم لو محدد له قسم واحد بس."""
    if user["department"]:
        return f" AND {alias}.department = ?", [user["department"]]
    return "", []


_MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


def clean_date(value, default=None):
    """يرجّع تاريخ ISO صحيح (YYYY-MM-DD) أو القيمة الافتراضية (اليوم) لو المدخل غلط."""
    try:
        return date.fromisoformat((value or "").strip()).isoformat()
    except ValueError:
        return default if default is not None else date.today().isoformat()


def period_context(month_arg):
    if month_arg and not _MONTH_RE.match(month_arg):
        month_arg = None
    label = month_arg or db.current_period_label(MONTH_START_DAY)
    start_date, end_date = db.period_bounds(label, MONTH_START_DAY)
    return label, start_date, end_date


def _content_matches_ext(ext, head):
    """فحص محتوى الملف الفعلي (مش الامتداد بس) عشان ما يترفعش ملف مزيّف."""
    if ext in ("jpg", "jpeg"):
        return head.startswith(b"\xff\xd8\xff")
    if ext == "png":
        return head.startswith(b"\x89PNG\r\n\x1a\n")
    if ext == "webp":
        return head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if ext == "pdf":
        return head.startswith(b"%PDF")
    return False


def save_upload(file_storage, subfolder, images_only=False):
    """يحفظ ملف مرفوع باسم فريد، ويرجع (المسار النسبي أو None، رسالة خطأ أو None)."""
    if not file_storage or not file_storage.filename:
        return None, "لم يتم اختيار ملف"
    if "." not in file_storage.filename:
        return None, "الملف بدون امتداد واضح (مثل .jpg)"
    ext = file_storage.filename.rsplit(".", 1)[-1].lower()
    allowed = {"jpg", "jpeg", "png", "webp"} if images_only else ALLOWED_UPLOAD_EXT
    if ext not in allowed:
        return None, ("الصورة لازم تكون jpg أو png أو webp" if images_only
                      else f"صيغة .{ext} غير مدعومة — استخدم jpg, jpeg, png, webp أو pdf")
    head = file_storage.stream.read(16)
    file_storage.stream.seek(0)
    if not _content_matches_ext(ext, head):
        return None, "محتوى الملف لا يطابق امتداده — الملف تالف أو غير مدعوم"
    try:
        fname = f"{uuid.uuid4().hex}.{ext}"
        folder = os.path.join(BASE_DIR, "static", "uploads", subfolder)
        os.makedirs(folder, exist_ok=True)
        full_path = os.path.join(folder, fname)
        file_storage.save(full_path)
        if not os.path.exists(full_path) or os.path.getsize(full_path) == 0:
            return None, "فشل حفظ الملف على القرص (تحقق من صلاحيات الكتابة في مجلد البرنامج)"
        return f"uploads/{subfolder}/{fname}", None
    except Exception as ex:
        return None, f"خطأ غير متوقع أثناء الحفظ: {ex}"


@app.errorhandler(413)
def file_too_large(e):
    flash("الملف كبير جدًا (الحد الأقصى 10 ميجا) — قلّل حجم الصورة وحاول تاني", "error")
    ref = request.referrer or url_for("dashboard")
    return redirect(ref)


def _asset_url(filename):
    """رابط ملف static مع رقم إصدار (تاريخ التعديل) عشان المتصفح يحمّل التنسيق الجديد فورًا بعد أي تحديث."""
    try:
        v = int(os.path.getmtime(os.path.join(app.static_folder, filename)))
    except OSError:
        v = 0
    return url_for("static", filename=filename, v=v)


app.jinja_env.globals["asset"] = _asset_url
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0


def build_nav_alerts(u):
    """تنبيهات الجرس والشارات في القائمة: أهم حاجات محتاجة إجراء دلوقتي (حسب صلاحيات وفرع المستخدم)."""
    if "_nav_alerts" in g:
        return g._nav_alerts
    alerts, by_endpoint = [], {}
    try:
        conn = get_conn()
        branch_ids = accessible_branch_ids(u)
        if branch_ids:
            pl = ",".join("?" * len(branch_ids))
            d_sql, d_params = dept_clause(u, "e")
            base = branch_ids + d_params

            def add(key, label, count, endpoint, icon):
                if count > 0:
                    alerts.append({"key": key, "label": label, "count": count, "endpoint": endpoint, "icon": icon})
                    by_endpoint[endpoint] = by_endpoint.get(endpoint, 0) + count

            if has_permission(u, "mark_attendance"):
                n = conn.execute(
                    f"""SELECT COUNT(*) c FROM employees e
                        WHERE e.branch_id IN ({pl}) AND e.status='active'{d_sql}
                          AND NOT EXISTS (SELECT 1 FROM attendance a WHERE a.employee_id=e.id AND a.date=?)""",
                    base + [date.today().isoformat()],
                ).fetchone()["c"]
                add("unmarked", "موظف لم يُسجَّل حضورهم اليوم", n, "attendance", "cal")
            if has_permission(u, "approve_requests"):
                add("leaves", "طلب إجازة بانتظار القرار", conn.execute(
                    f"""SELECT COUNT(*) c FROM leave_requests lr JOIN employees e ON e.id=lr.employee_id
                        WHERE lr.status='pending' AND e.branch_id IN ({pl}){d_sql}""", base).fetchone()["c"],
                    "leave_requests", "leave")
                add("advances", "سلفة بانتظار الاعتماد", conn.execute(
                    f"""SELECT COUNT(*) c FROM advances adv JOIN employees e ON e.id=adv.employee_id
                        WHERE adv.status='pending' AND e.branch_id IN ({pl}){d_sql}""", base).fetchone()["c"],
                    "advances", "wallet")
                add("swaps", "طلب تبديل شفت بانتظار القرار", conn.execute(
                    f"""SELECT COUNT(*) c FROM shift_swap_requests ssr JOIN employees e ON e.id=ssr.from_employee_id
                        WHERE ssr.status='pending' AND e.branch_id IN ({pl}){d_sql}""", base).fetchone()["c"],
                    "shift_swaps", "cal")
            if has_permission(u, "manage_documents"):
                add("docs", "مستند منتهي أو قارب على الانتهاء", conn.execute(
                    f"""SELECT COUNT(*) c FROM employee_documents d JOIN employees e ON e.id=d.employee_id
                        WHERE e.branch_id IN ({pl}){d_sql} AND d.expiry_date IS NOT NULL AND d.expiry_date <= ?""",
                    base + [(date.today() + timedelta(days=30)).isoformat()]).fetchone()["c"],
                    "expiring_documents", "doc")
    except Exception:
        app.logger.exception("nav alerts failed")
    g._nav_alerts = (alerts, by_endpoint)
    return g._nav_alerts


@app.context_processor
def inject_user():
    u = current_user()
    alerts, by_ep = build_nav_alerts(u) if u else ([], {})
    return {
        "me": u,
        "my_perms": user_permissions(u) if u else set(),
        "DEPARTMENTS": DEPARTMENTS,
        "DOCUMENT_TYPES": DOCUMENT_TYPES,
        "PERMISSIONS": PERMISSIONS,
        "nav_alerts": alerts,
        "nav_alert_total": sum(a["count"] for a in alerts),
        "nav_badges": by_ep,
    }



# ------------------------------------------------------------------ الأمان --
# 1) CSRF  2) قفل مؤقت بعد محاولات دخول فاشلة  3) إجبار تغيير كلمة المرور الافتراضية
# 4) حراسة نطاق الفروع/الأقسام مركزيًا  5) حماية المرفقات (لازم تسجيل دخول)
def csrf_token():
    tok = session.get("_csrf")
    if not tok:
        tok = secrets.token_hex(16)
        session["_csrf"] = tok
    return tok


app.jinja_env.globals["csrf_token"] = csrf_token

_FORM_POST_RE = re.compile(r"(<form\b[^>]*\bmethod\s*=\s*[\"']?post[\"']?[^>]*>)", re.IGNORECASE)


@app.after_request
def inject_csrf_and_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if resp.mimetype == "text/html" and not resp.direct_passthrough and b"<form" in resp.get_data():
        html = resp.get_data(as_text=True)
        tag = f'<input type="hidden" name="csrf_token" value="{csrf_token()}">'
        html = _FORM_POST_RE.sub(lambda m: m.group(1) + tag, html)
        resp.set_data(html)
    return resp


_LOGIN_FAILS = {}          # (ip, username) -> [عدد المحاولات، وقت أول محاولة]
LOGIN_MAX_FAILS = 5
LOGIN_LOCK_SECONDS = 300


def _login_key(username):
    return (request.remote_addr or "?", (username or "").strip().lower())


def login_lock_remaining(username):
    rec = _LOGIN_FAILS.get(_login_key(username))
    if not rec:
        return 0
    count, first = rec
    elapsed = time.time() - first
    if elapsed > LOGIN_LOCK_SECONDS:
        _LOGIN_FAILS.pop(_login_key(username), None)
        return 0
    return int(LOGIN_LOCK_SECONDS - elapsed) if count >= LOGIN_MAX_FAILS else 0


def register_login_failure(username):
    key = _login_key(username)
    rec = _LOGIN_FAILS.get(key)
    if not rec or time.time() - rec[1] > LOGIN_LOCK_SECONDS:
        _LOGIN_FAILS[key] = [1, time.time()]
    else:
        rec[0] += 1


_SCOPE_SQL = {
    "emp_id": "SELECT branch_id, department FROM employees WHERE id=?",
    "att_id": """SELECT e.branch_id, e.department FROM attendance a
                 JOIN employees e ON e.id=a.employee_id WHERE a.id=?""",
    "adj_id": """SELECT e.branch_id, e.department FROM payroll_adjustments p
                 JOIN employees e ON e.id=p.employee_id WHERE p.id=?""",
    "req_id": """SELECT e.branch_id, e.department FROM leave_requests r
                 JOIN employees e ON e.id=r.employee_id WHERE r.id=?""",
    "adv_id": """SELECT e.branch_id, e.department FROM advances a
                 JOIN employees e ON e.id=a.employee_id WHERE a.id=?""",
    "swap_id": """SELECT e.branch_id, e.department FROM shift_swap_requests s
                  JOIN employees e ON e.id=s.from_employee_id WHERE s.id=?""",
    "unit_id": "SELECT branch_id, NULL AS department FROM company_housing_units WHERE id=?",
}
_FORM_SCOPE_SQL = {
    "employee_id": _SCOPE_SQL["emp_id"], "emp_id": _SCOPE_SQL["emp_id"],
    "from_employee_id": _SCOPE_SQL["emp_id"], "to_employee_id": _SCOPE_SQL["emp_id"],
    "shift_id": """SELECT e.branch_id, e.department FROM shifts s
                   JOIN employees e ON e.id=s.employee_id WHERE s.id=?""",
}


def _deny(msg="لا تملك صلاحية على هذا السجل (خارج فرعك أو قسمك)"):
    flash(msg, "error")
    return redirect(url_for("dashboard"))


def _in_scope(conn, u, branch_ids, sql, raw_id):
    try:
        rid = int(raw_id)
    except (TypeError, ValueError):
        return False
    row = conn.execute(sql, (rid,)).fetchone()
    if not row:
        return False
    if row["branch_id"] not in branch_ids:
        return False
    if u["department"] and row["department"] and row["department"] != u["department"]:
        return False
    return True


@app.before_request
def security_guard():
    path = request.path
    # المرفقات (صور البطاقات والمستندات) لا تُفتح إلا لمستخدم مسجّل دخول
    if path.startswith("/static/uploads/") and "user_id" not in session:
        abort(404)
    ep = request.endpoint
    if ep is None or ep in ("static", "health"):
        return None

    # حماية CSRF لكل الطلبات المعدِّلة
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
        real = session.get("_csrf") or ""
        if not real or not secrets.compare_digest(sent, real):
            flash("انتهت صلاحية الصفحة. حدّث الصفحة وأعد المحاولة.", "error")
            return redirect(request.referrer or url_for("login"))

    if ep in ("login", "logout"):
        return None

    u = current_user()
    if not u:
        return redirect(url_for("login"))

    # إجبار تغيير كلمة المرور الافتراضية / المُعاد ضبطها
    if u["must_change_password"] and ep != "change_password":
        flash("لازم تغيّر كلمة المرور أولًا قبل استخدام النظام.", "error")
        return redirect(url_for("change_password"))

    # حراسة النطاق: أي رقم موظف/فرع/سجل في الرابط أو النموذج لازم يكون داخل صلاحيات المستخدم
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    for key, sql in _SCOPE_SQL.items():
        if key in (request.view_args or {}) and not _in_scope(conn, u, branch_ids, sql, request.view_args[key]):
            return _deny()
    if "branch_id" in (request.view_args or {}):
        try:
            if int(request.view_args["branch_id"]) not in branch_ids:
                return _deny()
        except (TypeError, ValueError):
            return _deny()
    raw_branch = request.values.get("branch_id")
    if raw_branch:
        try:
            if int(raw_branch) not in branch_ids:
                return _deny()
        except ValueError:
            return _deny("قيمة الفرع غير صالحة")
    if request.method == "POST":
        for key, sql in _FORM_SCOPE_SQL.items():
            val = request.form.get(key)
            if val and not _in_scope(conn, u, branch_ids, sql, val):
                return _deny()
        for key in request.form.keys():
            if key.startswith(("status_", "checkin_", "checkout_", "shift_", "c_")):
                emp_part = key.split("_")[1] if len(key.split("_")) > 1 else ""
                if not _in_scope(conn, u, branch_ids, _SCOPE_SQL["emp_id"], emp_part):
                    return _deny()
    return None


@app.errorhandler(ValueError)
def bad_input(e):
    flash("بيانات غير صالحة في النموذج — راجع الحقول وحاول مرة أخرى.", "error")
    return redirect(request.referrer or url_for("dashboard"))


def _error_page(code, title, text):
    html = f"""<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{title}</title>
<style>body{{margin:0;background:#1a1c21;color:#eceef2;font-family:Tajawal,Tahoma,sans-serif;display:flex;
min-height:100vh;align-items:center;justify-content:center}}.b{{background:#282a30;border:1px solid #3b3e46;
border-radius:14px;padding:32px 36px;max-width:420px;text-align:center}}h1{{margin:0 0 6px;font-size:44px;color:#22c3e6}}
p{{color:#9ea2ad;line-height:1.7}}a{{display:inline-block;margin-top:10px;background:#3557e8;color:#fff;
padding:9px 20px;border-radius:9px;text-decoration:none;font-weight:700}}</style></head>
<body><div class="b"><h1>{code}</h1><h2 style="margin:0 0 8px">{title}</h2><p>{text}</p>
<a href="/">الرجوع للرئيسية</a></div></body></html>"""
    return html, code


@app.errorhandler(404)
def not_found(e):
    return _error_page(404, "الصفحة غير موجودة", "الرابط اللي فتحته مش موجود أو اتحذف.")


@app.errorhandler(500)
def server_error(e):
    app.logger.exception("Unhandled error: %s", e)
    return _error_page(500, "حصل خطأ غير متوقع", "اتسجّل الخطأ. جرّب تاني، ولو استمر ابعت رسالة الخطأ من نافذة التشغيل للمطوّر.")



# ------------------------------------------------------------ تصدير PDF --
def find_pdf_browser():
    """يدوّر على Edge أو Chrome على الجهاز (Edge موجود دايمًا على ويندوز 10/11)."""
    env = os.environ.get("PDF_BROWSER")
    if env and os.path.exists(env):
        return env
    cands = []
    pf = [os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA")]
    for base in filter(None, pf):
        cands += [
            os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(base, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
        ]
    cands += [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    ]
    for name in ("microsoft-edge", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome"):
        found = shutil.which(name)
        if found:
            cands.append(found)
    return next((c for c in cands if c and os.path.exists(c)), None)


_PDF_SLOTS = threading.Semaphore(2)
_PDF_CSP = ('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
            'style-src \'unsafe-inline\'; img-src data:; font-src data:">')


def _render_pdf(browser, html_path, pdf_path, profile_dir):
    base = [
        browser, "--disable-gpu", "--no-pdf-header-footer", "--print-to-pdf-no-header",
        "--hide-scrollbars", "--virtual-time-budget=4000", f"--user-data-dir={profile_dir}",
        f"--print-to-pdf={pdf_path}", "--no-first-run", "--disable-extensions",
    ]
    if hasattr(os, "geteuid") and os.geteuid() == 0:        # لينكس بصلاحية root (سيرفر/حاوية)
        base.insert(1, "--no-sandbox")
    flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    url = Path(html_path).as_uri()
    for mode in ("--headless=new", "--headless"):
        if os.path.exists(pdf_path):
            os.remove(pdf_path)
        try:
            subprocess.run(base[:1] + [mode] + base[1:] + [url], timeout=60,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **flags)
        except subprocess.TimeoutExpired:
            continue
        if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 500:
            return True
    return False


@app.route("/pdf/export", methods=["POST"])
def pdf_export():
    """يستقبل HTML الصفحة (بعد تعديلات المستخدم) ويرجّع PDF جاهز للتحميل."""
    request.max_content_length = 12 * 1024 * 1024
    browser = find_pdf_browser()
    if not browser:
        return {"error": "no_browser", "message": "مفيش Edge أو Chrome على الجهاز"}, 501
    html = request.get_data(as_text=True)
    if not html or "<html" not in html[:400].lower():
        return {"error": "bad_html", "message": "محتوى غير صالح"}, 400
    # أمان: بنمنع أي سكربت أو اتصال خارجي داخل صفحة التحويل
    html = re.sub(r"<script\b.*?</script>", "", html, flags=re.IGNORECASE | re.DOTALL)
    html = html.replace("<head>", "<head>" + _PDF_CSP, 1)
    name = re.sub(r'[\\/:*?"<>|\r\n]+', "-", request.args.get("name", "report"))[:80] or "report"
    if not _PDF_SLOTS.acquire(timeout=30):
        return {"error": "busy", "message": "السيرفر مشغول بتصدير ملفات تانية — حاول بعد لحظات"}, 503
    tmp = tempfile.mkdtemp(prefix="pdfx_")
    try:
        html_path = os.path.join(tmp, "page.html")
        pdf_path = os.path.join(tmp, "out.pdf")
        with open(html_path, "w", encoding="utf-8") as fh:
            fh.write(html)
        if not _render_pdf(browser, html_path, pdf_path, os.path.join(tmp, "profile")):
            return {"error": "render_failed", "message": "تعذّر تحويل الصفحة إلى PDF"}, 500
        with open(pdf_path, "rb") as fh:
            data = io.BytesIO(fh.read())
    finally:
        _PDF_SLOTS.release()
        shutil.rmtree(tmp, ignore_errors=True)
    return send_file(data, mimetype="application/pdf", as_attachment=True, download_name=f"{name}.pdf")

# ------------------------------------------------------------------ Auth --
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        wait = login_lock_remaining(username)
        if wait:
            flash(f"محاولات كتير غلط. استنى {wait // 60 + 1} دقيقة وحاول تاني.", "error")
            return render_template("login.html")
        conn = get_conn()
        u = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if u and check_password_hash(u["password_hash"], password):
            _LOGIN_FAILS.pop(_login_key(username), None)
            session.clear()                       # منع تثبيت الجلسة
            session["user_id"] = u["id"]
            session.permanent = True
            db.log_action(conn, u, "تسجيل دخول", "user", u["id"], None)
            conn.commit()
            return redirect(url_for("dashboard"))
        register_login_failure(username)
        flash("اسم المستخدم أو كلمة المرور غير صحيحة", "error")
    return render_template("login.html")


@app.route("/account/password", methods=["GET", "POST"])
def change_password():
    u = current_user()
    if not u:
        return redirect(url_for("login"))
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if not check_password_hash(u["password_hash"], current):
            flash("كلمة المرور الحالية غير صحيحة", "error")
        elif len(new) < 6:
            flash("كلمة المرور الجديدة لازم تكون 6 حروف/أرقام على الأقل", "error")
        elif new == db.DEFAULT_ADMIN_PASSWORD or new == current:
            flash("اختار كلمة مرور جديدة مختلفة عن الحالية والافتراضية", "error")
        elif new != confirm:
            flash("تأكيد كلمة المرور غير مطابق", "error")
        else:
            conn = get_conn()
            conn.execute(
                "UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?",
                (generate_password_hash(new), u["id"]),
            )
            db.log_action(conn, u, "تغيير كلمة المرور", "user", u["id"], None)
            conn.commit()
            flash("تم تغيير كلمة المرور بنجاح", "ok")
            return redirect(url_for("dashboard"))
    return render_template("account_password.html", forced=bool(u["must_change_password"]))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# -------------------------------------------------------------- Dashboard --
@app.route("/")
@login_required
def dashboard():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    d_sql, d_params = dept_clause(u, "e")
    today = date.today().isoformat()

    employees = conn.execute(
        f"SELECT * FROM employees e WHERE e.branch_id IN ({placeholders}) AND e.status='active'{d_sql}",
        branch_ids + d_params,
    ).fetchall()

    att_today = conn.execute(
        f"""SELECT a.status, COUNT(*) c FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            WHERE e.branch_id IN ({placeholders}) AND a.date = ?{d_sql}
            GROUP BY a.status""",
        branch_ids + [today] + d_params,
    ).fetchall()
    today_counts = {r["status"]: r["c"] for r in att_today}

    period_label, p_start, p_end = period_context(None)
    att_period = conn.execute(
        f"""SELECT a.status, COUNT(*) c FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            WHERE e.branch_id IN ({placeholders}) AND a.date BETWEEN ? AND ?{d_sql}
            GROUP BY a.status""",
        branch_ids + [p_start.isoformat(), p_end.isoformat()] + d_params,
    ).fetchall()
    period_counts = {r["status"]: r["c"] for r in att_period}

    dept_counts = conn.execute(
        f"""SELECT department, COUNT(*) c FROM employees e
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'{d_sql}
            GROUP BY department""",
        branch_ids + d_params,
    ).fetchall()

    branch_counts = conn.execute(
        f"""SELECT b.name, COUNT(e.id) c FROM branches b
            LEFT JOIN employees e ON e.branch_id=b.id AND e.status='active'{d_sql}
            WHERE b.id IN ({placeholders})
            GROUP BY b.id ORDER BY b.name""",
        d_params + branch_ids,
    ).fetchall()

    top_absence = conn.execute(
        f"""SELECT e.name, e.department, COUNT(*) c FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            WHERE e.branch_id IN ({placeholders}) AND a.status='absence'
                  AND a.date BETWEEN ? AND ?{d_sql}
            GROUP BY e.id ORDER BY c DESC LIMIT 5""",
        branch_ids + [p_start.isoformat(), p_end.isoformat()] + d_params,
    ).fetchall()

    payroll_cost = None
    payroll_breakdown = None
    cost_trend = []
    if has_permission(u, "view_payroll"):
        dept_scope = u["department"] if u["department"] else None
        full_report, payroll_cost = build_payroll_report(branch_ids, period_label, p_start, p_end,
                                                         dept_scope, persist=False)
        payroll_breakdown = {
            "gross": sum(r["gross"] for r in full_report),
            "absence_cut": sum(r["absence_cut"] for r in full_report),
            "fixed_deductions": sum(r["fixed_deductions"] for r in full_report),
            "other_deductions": sum(r["deduction"] for r in full_report),
            "bonus": sum(r["bonus"] for r in full_report),
            "net": payroll_cost,
        }
        for i in range(5, -1, -1):
            lbl = previous_period_label(period_label, i)
            if i == 0:
                cost_trend.append({"label": lbl, "cost": payroll_cost})
                continue
            ps, pe = db.period_bounds(lbl, MONTH_START_DAY)
            _, cost = build_payroll_report(branch_ids, lbl, ps, pe, dept_scope, persist=False)
            cost_trend.append({"label": lbl, "cost": cost})

    top_eval = conn.execute(
        f"""SELECT e.name, e.department, AVG(ev.overall_score) avg_score FROM evaluations ev
            JOIN employees e ON e.id = ev.employee_id
            WHERE e.branch_id IN ({placeholders}){d_sql} AND ev.period = ?
            GROUP BY e.id ORDER BY avg_score DESC LIMIT 5""",
        branch_ids + d_params + [period_label],
    ).fetchall()

    workforce_today = build_workforce_snapshot(conn, branch_ids, today, group_by_sub=False)

    # ---- مؤشرات إضافية للداشبورد المضغوط (الجوج + خريطة الحضور الحرارية)
    employees_total = len(employees)
    today_present = today_counts.get("present", 0) + today_counts.get("mission", 0)
    today_present_pct = round(today_present / employees_total * 100) if employees_total else 0
    not_marked_today = max(0, employees_total - sum(today_counts.values()))
    period_total_marks = sum(period_counts.values())
    period_present_pct = (
        round((period_counts.get("present", 0) + period_counts.get("mission", 0)) / period_total_marks * 100)
        if period_total_marks else 0
    )

    heat_days = []
    _d = p_start
    while _d <= p_end:
        heat_days.append(_d)
        _d += timedelta(days=1)
    dept_totals = {r["department"]: r["c"] for r in dept_counts}
    heat_raw = conn.execute(
        f"""SELECT e.department, a.date,
                   SUM(CASE WHEN a.status IN ('present','mission') THEN 1 ELSE 0 END) p,
                   COUNT(*) rec
            FROM attendance a JOIN employees e ON e.id = a.employee_id
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'
                  AND a.date BETWEEN ? AND ?{d_sql}
            GROUP BY e.department, a.date""",
        branch_ids + [p_start.isoformat(), p_end.isoformat()] + d_params,
    ).fetchall()
    heat_map = {(r["department"], r["date"]): (r["p"], r["rec"]) for r in heat_raw}
    heat_rows = []
    for dept_name, total in dept_totals.items():
        cells = []
        for hd in heat_days:
            p_, rec_ = heat_map.get((dept_name, hd.isoformat()), (0, 0))
            cells.append({
                "date": hd.isoformat(), "day": hd.day, "present": p_,
                "pct": round(p_ / total * 100) if (rec_ and total) else None,
            })
        heat_rows.append({"department": dept_name, "total": total, "cells": cells})

    pending_count = 0
    if has_permission(u, "approve_requests"):
        pl = ",".join("?" * len(branch_ids))
        pending_count += conn.execute(
            f"""SELECT COUNT(*) c FROM leave_requests lr JOIN employees e ON e.id=lr.employee_id
                WHERE lr.status='pending' AND e.branch_id IN ({pl})""", branch_ids,
        ).fetchone()["c"]
        pending_count += conn.execute(
            f"""SELECT COUNT(*) c FROM advances adv JOIN employees e ON e.id=adv.employee_id
                WHERE adv.status='pending' AND e.branch_id IN ({pl})""", branch_ids,
        ).fetchone()["c"]

    pl = ",".join("?" * len(branch_ids))
    quick_counts = {
        "active_advances": conn.execute(
            f"""SELECT COUNT(*) c FROM advances adv JOIN employees e ON e.id=adv.employee_id
                WHERE adv.status='active' AND e.branch_id IN ({pl})""", branch_ids,
        ).fetchone()["c"],
        "violations_period": conn.execute(
            f"""SELECT COUNT(*) c FROM violations v JOIN employees e ON e.id=v.employee_id
                WHERE e.branch_id IN ({pl}) AND v.date BETWEEN ? AND ?""",
            branch_ids + [p_start.isoformat(), p_end.isoformat()],
        ).fetchone()["c"],
        "expiring_docs": conn.execute(
            f"""SELECT COUNT(*) c FROM employee_documents d JOIN employees e ON e.id=d.employee_id
                WHERE e.branch_id IN ({pl}) AND d.expiry_date IS NOT NULL AND d.expiry_date <= ?""",
            branch_ids + [(date.today() + timedelta(days=30)).isoformat()],
        ).fetchone()["c"],
        "evaluations_period": conn.execute(
            f"""SELECT COUNT(*) c FROM evaluations ev JOIN employees e ON e.id=ev.employee_id
                WHERE e.branch_id IN ({pl}) AND ev.period = ?""",
            branch_ids + [period_label],
        ).fetchone()["c"],
        "shifts_today": conn.execute(
            f"""SELECT COUNT(*) c FROM shifts sh JOIN employees e ON e.id=sh.employee_id
                JOIN shift_types st ON st.id = sh.shift_type_id
                WHERE e.branch_id IN ({pl}) AND sh.date = ? AND st.is_off = 0""", branch_ids + [today],
        ).fetchone()["c"],
        "pending_swaps": conn.execute(
            f"""SELECT COUNT(*) c FROM shift_swap_requests ssr
                JOIN employees ef ON ef.id = ssr.from_employee_id
                WHERE ssr.status='pending' AND ef.branch_id IN ({pl})""", branch_ids,
        ).fetchone()["c"],
    }

    return render_template(
        "dashboard.html",
        employees_count=len(employees),
        today_counts=today_counts,
        period_counts=period_counts,
        dept_counts=dept_counts,
        branch_counts=branch_counts,
        top_absence=top_absence,
        top_eval=top_eval,
        payroll_cost=payroll_cost,
        payroll_breakdown=payroll_breakdown,
        cost_trend=cost_trend,
        workforce_today=workforce_today,
        pending_count=pending_count,
        quick_counts=quick_counts,
        today=today,
        period_label=period_label,
        p_start=p_start, p_end=p_end,
        today_present_pct=today_present_pct,
        period_present_pct=period_present_pct,
        not_marked_today=not_marked_today,
        heat_days=heat_days, heat_rows=heat_rows,
    )


# ------------------------------------------------------------------ Branches --
@app.route("/branches", methods=["GET", "POST"])
@permission_required("manage_branches")
def branches():
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    # "المدير العام": صلاحية إدارة المستخدمين + حساب غير مقيّد بفرع (branch_id فاضي) — مش بس الصلاحية،
    # عشان حساب مدير فرع (حتى لو بصلاحيات كاملة) يفضل مقيّد بفرعه ومايقدرش يحذف فروع تانية.
    is_super = has_permission(u, "manage_users") and u["branch_id"] is None
    if request.method == "POST":
        if not is_super:
            flash("إضافة فروع جديدة متاحة فقط لصاحب صلاحية إدارة المستخدمين (المدير العام)", "error")
            return redirect(url_for("branches"))
        name = request.form.get("name", "").strip()
        address = request.form.get("address", "").strip()
        phone = request.form.get("phone", "").strip()
        if name:
            conn.execute(
                "INSERT INTO branches (name, address, phone) VALUES (?, ?, ?)",
                (name, address, phone),
            )
            conn.commit()
            flash("تمت إضافة الفرع", "ok")
        return redirect(url_for("branches"))

    # القائمة دايمًا مقيّدة بفروع المستخدم المسموحة (accessible_branch_ids) — بترجع كل الفروع تلقائيًا
    # لو المستخدم غير مقيّد بفرع، فمفيش داعي لاستثناء منفصل هنا.
    ph = ",".join("?" * len(branch_ids)) if branch_ids else "NULL"
    rows = conn.execute(
        f"""SELECT b.*, (SELECT COUNT(*) FROM employees e WHERE e.branch_id=b.id AND e.status='active') AS emp_count,
                   (SELECT COUNT(*) FROM employees e WHERE e.branch_id=b.id) AS emp_count_all
           FROM branches b WHERE b.id IN ({ph}) ORDER BY b.id""", branch_ids
    ).fetchall()
    return render_template("branches.html", branches=rows, is_super=is_super)


@app.route("/branches/<int:branch_id>/edit", methods=["POST"])
@permission_required("manage_branches")
def edit_branch(branch_id):
    conn = get_conn()
    name = request.form.get("name", "").strip()
    address = request.form.get("address", "").strip()
    phone = request.form.get("phone", "").strip()
    if name:
        conn.execute(
            "UPDATE branches SET name=?, address=?, phone=? WHERE id=?",
            (name, address, phone, branch_id),
        )
        db.log_action(conn, current_user(), "تعديل بيانات فرع", "branch", branch_id, name)
        conn.commit()
        flash("تم تحديث بيانات الفرع", "ok")
    return redirect(url_for("branches"))


@app.route("/branches/<int:branch_id>/logo", methods=["POST"])
@permission_required("manage_branches")
def upload_branch_logo(branch_id):
    conn = get_conn()
    file = request.files.get("logo")
    path, err = save_upload(file, "branches", images_only=True)
    if path:
        conn.execute("UPDATE branches SET logo_path=? WHERE id=?", (path, branch_id))
        db.log_action(conn, current_user(), "رفع لوجو فرع", "branch", branch_id, path)
        conn.commit()
        flash("تم رفع اللوجو", "ok")
    else:
        flash(f"لم يتم رفع اللوجو: {err}", "error")
    return redirect(url_for("branches"))


@app.route("/branches/<int:branch_id>/delete", methods=["POST"])
@permission_required("manage_branches")
def delete_branch(branch_id):
    u = current_user()
    conn = get_conn()
    row = conn.execute("SELECT name FROM branches WHERE id=?", (branch_id,)).fetchone()
    if not row:
        flash("الفرع غير موجود", "error")
        return redirect(url_for("branches"))
    emp_n = conn.execute("SELECT COUNT(*) c FROM employees WHERE branch_id=?", (branch_id,)).fetchone()["c"]

    if emp_n:
        is_super = has_permission(u, "manage_users") and u["branch_id"] is None
        typed = (request.form.get("confirm_name") or "").strip()
        forced = request.form.get("force") == "1"
        if not is_super:
            flash(f"مينفعش تحذف فرع فيه {emp_n} موظف (نشط أو سابق) — نقل الموظفين أو أنهِ خدمتهم أولًا، "
                  "لأن الحذف هيمسح حضورهم ورواتبهم نهائيًا. حذف فرع فيه موظفون متاح فقط لصاحب صلاحية "
                  "إدارة المستخدمين (المدير العام).", "error")
            return redirect(url_for("branches"))
        if not (forced and typed == row["name"]):
            flash("لتأكيد حذف فرع فيه موظفون: اكتب اسم الفرع بالظبط في مربع التأكيد ثم اضغط حذف تاني.", "error")
            return redirect(url_for("branches"))
        # نسخة احتياطية كاملة تلقائية قبل أي حذف مدمّر، احتياطًا
        try:
            backup_name = db.backup_full()
        except Exception as ex:
            flash(f"اتوقف الحذف: تعذّر أخذ نسخة احتياطية أولًا للأمان ({ex}). حاول تاني.", "error")
            return redirect(url_for("branches"))
        conn.execute("DELETE FROM branches WHERE id = ?", (branch_id,))
        db.log_action(conn, u, "حذف فرع (فيه موظفون) — نسخة احتياطية قبل الحذف", "branch", branch_id,
                      f"{row['name']} ({emp_n} موظف) — نسخة: {backup_name}")
        conn.commit()
        flash(f"تم حذف الفرع ({emp_n} موظف وكل بياناتهم اتحذفوا — النسخة الاحتياطية في صفحة النسخ الاحتياطي)", "ok")
        return redirect(url_for("branches"))

    conn.execute("DELETE FROM branches WHERE id = ?", (branch_id,))
    db.log_action(conn, u, "حذف فرع", "branch", branch_id, row["name"])
    conn.commit()
    flash("تم حذف الفرع", "ok")
    return redirect(url_for("branches"))


# ------------------------------------------------------------------ سكن الشركة --
@app.route("/housing", methods=["GET", "POST"])
@permission_required("manage_employees")
def housing_page():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))

    if request.method == "POST":
        branch_id = int(request.form.get("branch_id"))
        name = request.form.get("name", "").strip()
        capacity = int(request.form.get("capacity") or 1)
        notes = request.form.get("notes", "").strip()
        if branch_id in branch_ids and name:
            conn.execute(
                "INSERT INTO company_housing_units (branch_id, name, capacity, notes) VALUES (?, ?, ?, ?)",
                (branch_id, name, capacity, notes),
            )
            conn.commit()
            flash("تمت إضافة الوحدة السكنية", "ok")
        return redirect(url_for("housing_page"))

    units = conn.execute(
        f"""SELECT hu.*, b.name AS branch_name,
                   (SELECT COUNT(*) FROM employees e WHERE e.housing_unit_id=hu.id AND e.status='active') AS occupied
            FROM company_housing_units hu JOIN branches b ON b.id = hu.branch_id
            WHERE hu.branch_id IN ({placeholders}) ORDER BY b.name, hu.name""",
        branch_ids,
    ).fetchall()

    residents = conn.execute(
        f"""SELECT e.*, hu.name AS unit_name FROM employees e
            JOIN company_housing_units hu ON hu.id = e.housing_unit_id
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'
            ORDER BY hu.name, e.name""",
        branch_ids,
    ).fetchall()

    branch_rows = conn.execute(f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()
    return render_template("housing.html", units=units, residents=residents, branches=branch_rows)


@app.route("/housing/<int:unit_id>/delete", methods=["POST"])
@permission_required("manage_employees")
def delete_housing_unit(unit_id):
    conn = get_conn()
    occupied = conn.execute(
        "SELECT COUNT(*) c FROM employees WHERE housing_unit_id=? AND status='active'", (unit_id,)
    ).fetchone()["c"]
    if occupied:
        flash(f"مينفعش تحذف الوحدة دي — فيها {occupied} موظف مسكّن حاليًا", "error")
    else:
        conn.execute("DELETE FROM company_housing_units WHERE id=?", (unit_id,))
        conn.commit()
        flash("تم حذف الوحدة السكنية", "ok")
    return redirect(url_for("housing_page"))


# ----------------------------------------------------------------- Employees --
@app.route("/employees", methods=["GET", "POST"])
@login_required
def employees():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        if not has_permission(u, "manage_employees"):
            flash("لا تملك صلاحية إضافة موظفين", "error")
            return redirect(url_for("employees"))
        branch_id = int(request.form.get("branch_id"))
        if branch_id not in branch_ids:
            flash("لا تملك صلاحية على هذا الفرع", "error")
            return redirect(url_for("employees"))
        new_name = request.form.get("name", "").strip()
        new_fp = request.form.get("fingerprint_no", "").strip()
        dup = find_duplicate_employee(conn, branch_id, new_name, new_fp)
        if dup:
            flash(f"يوجد بالفعل موظف بنفس {'البصمة' if new_fp else 'الاسم'} في هذا الفرع: "
                  f"«{dup['name']}»" + (" (سابق)" if dup["status"] != "active" else "") +
                  " — راجع بيانات الموظف الموجود بدل الإضافة من جديد.", "error")
            return redirect(url_for("employees"))
        cur = conn.execute(
            """INSERT INTO employees (branch_id, fingerprint_no, name, department, job_title,
               base_salary, start_date, residence, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')""",
            (
                branch_id,
                request.form.get("fingerprint_no", "").strip(),
                request.form.get("name", "").strip(),
                request.form.get("department", "").strip() or "غير محدد",
                request.form.get("job_title", "").strip(),
                float(request.form.get("base_salary") or 0),
                request.form.get("start_date") or None,
                request.form.get("residence", "").strip(),
            ),
        )
        new_emp_id = cur.lastrowid
        for item in db.DEFAULT_ONBOARDING_ITEMS:
            conn.execute(
                "INSERT INTO checklist_items (employee_id, kind, item) VALUES (?, 'onboarding', ?)",
                (new_emp_id, item),
            )
        db.log_action(conn, u, "إضافة موظف", "employee", new_emp_id, request.form.get("name", ""))
        conn.commit()
        flash("تمت إضافة الموظف", "ok")
        return redirect(url_for("employees"))

    dept_filter = request.args.get("department", "")
    search_q = request.args.get("q", "").strip()
    placeholders = ",".join("?" * len(branch_ids))
    d_sql, d_params = dept_clause(u, "e")
    query = f"""SELECT e.*, b.name AS branch_name FROM employees e
                JOIN branches b ON b.id = e.branch_id
                WHERE e.branch_id IN ({placeholders}){d_sql}"""
    params = list(branch_ids) + d_params
    if dept_filter:
        query += " AND e.department = ?"
        params.append(dept_filter)
    if search_q:
        query += " AND (e.name LIKE ? OR e.job_title LIKE ? OR e.fingerprint_no LIKE ?)"
        like = f"%{search_q}%"
        params += [like, like, like]
    query += " ORDER BY e.status ASC, e.name"

    rows = conn.execute(query, params).fetchall()
    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids
    ).fetchall()

    # تنبيه بالتكرارات القديمة (لو موجودة من قبل الإصلاح) عشان تراجعها يدويًا
    dup_groups = conn.execute(
        f"""SELECT branch_id, fingerprint_no, GROUP_CONCAT(id) AS ids, GROUP_CONCAT(name, ' / ') AS names, COUNT(*) c
            FROM employees WHERE branch_id IN ({placeholders}) AND fingerprint_no IS NOT NULL AND fingerprint_no != ''
            GROUP BY branch_id, fingerprint_no HAVING COUNT(*) > 1""", branch_ids).fetchall()
    name_dups = conn.execute(
        f"""SELECT branch_id, lower(trim(name)) nm, GROUP_CONCAT(id) AS ids, GROUP_CONCAT(name, ' / ') AS names, COUNT(*) c
            FROM employees WHERE branch_id IN ({placeholders}) AND status='active'
            GROUP BY branch_id, nm HAVING COUNT(*) > 1""", branch_ids).fetchall()
    duplicate_alerts = list(dup_groups) + [r for r in name_dups if r["ids"] not in [d["ids"] for d in dup_groups]]

    return render_template(
        "employees.html", employees=rows, branches=branch_rows,
        dept_filter=dept_filter, search_q=search_q, duplicate_alerts=duplicate_alerts,
    )


STATUS_LABELS_AR = {
    "present": "حاضر", "leave": "إجازة", "absence": "غياب", "half_day": "نصف يوم",
    "mission": "مأمورية", "start_of_work": "بداية العمل", "resignation": "استقالة",
    "end_of_service": "نهاية عمل", None: "لم يُسجَّل بعد",
}
app.jinja_env.globals["STATUS_LABELS_AR"] = STATUS_LABELS_AR


def build_workforce_detail(conn, branch_ids, sel_date, group_by_sub=True, dept_filter=None):
    """نفس فكرة build_workforce_snapshot لكن بترجع أسامي الموظفين فعليًا جوه كل قسم/قسم فرعي —
    لعرض 'مين فين النهاردة' وتصدير تقرير مفصّل بدل الأرقام المجمّعة بس."""
    placeholders = ",".join("?" * len(branch_ids))
    group_col = "COALESCE(e.sub_department, 'بدون تصنيف فرعي')" if group_by_sub else "'-'"
    query = f"""SELECT e.id AS emp_id, e.name, e.job_title, e.fingerprint_no, e.branch_id,
                       b.name AS branch_name, e.department, {group_col} AS sub_department,
                       a.status, a.check_in, a.check_out
                FROM employees e
                JOIN branches b ON b.id = e.branch_id
                LEFT JOIN attendance a ON a.employee_id = e.id AND a.date = ?
                WHERE e.branch_id IN ({placeholders}) AND e.status='active'"""
    params = [sel_date] + branch_ids
    if dept_filter:
        query += " AND e.department = ?"
        params.append(dept_filter)
    query += " ORDER BY e.department, sub_department, e.name"
    rows = conn.execute(query, params).fetchall()

    groups = {}
    for r in rows:
        key = (r["department"], r["sub_department"])
        g = groups.setdefault(key, {
            "department": r["department"], "sub_department": r["sub_department"],
            "total": 0, "present": 0, "absent": 0, "leave": 0, "mission": 0, "not_marked": 0,
            "employees": [],
        })
        g["total"] += 1
        st = r["status"]
        if st == "present":
            g["present"] += 1
        elif st == "absence":
            g["absent"] += 1
        elif st == "leave":
            g["leave"] += 1
        elif st == "mission":
            g["mission"] += 1
        elif st is None:
            g["not_marked"] += 1
        g["employees"].append({
            "id": r["emp_id"], "name": r["name"], "job_title": r["job_title"] or r["department"],
            "fingerprint_no": r["fingerprint_no"], "branch_name": r["branch_name"],
            "status": st, "status_ar": STATUS_LABELS_AR.get(st, st or "لم يُسجَّل بعد"),
            "check_in": r["check_in"], "check_out": r["check_out"],
        })

    result = []
    for g in groups.values():
        g["coverage_pct"] = round((g["present"] / g["total"]) * 100) if g["total"] else 0
        result.append(g)
    result.sort(key=lambda g: (g["department"], g["sub_department"]))
    return result


def build_workforce_snapshot(conn, branch_ids, sel_date, group_by_sub=True):
    """يبني لقطة القوة التشغيلية ليوم معيّن: كل قسم (وقسم فرعي لو مطلوب) مع حالة الحضور
    الفعلية اليوم — مفيد لمعرفة أماكن النقص التشغيلي بسرعة."""
    placeholders = ",".join("?" * len(branch_ids))
    group_col = "COALESCE(e.sub_department, 'بدون تصنيف فرعي')" if group_by_sub else "'-'"
    rows = conn.execute(
        f"""SELECT e.department, {group_col} AS sub_department, e.id AS emp_id, a.status
            FROM employees e
            LEFT JOIN attendance a ON a.employee_id = e.id AND a.date = ?
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'
            ORDER BY e.department, sub_department""",
        [sel_date] + branch_ids,
    ).fetchall()

    groups = {}
    for r in rows:
        key = (r["department"], r["sub_department"])
        g = groups.setdefault(key, {
            "department": r["department"], "sub_department": r["sub_department"],
            "total": 0, "present": 0, "absent": 0, "leave": 0, "mission": 0, "not_marked": 0,
        })
        g["total"] += 1
        st = r["status"]
        if st == "present":
            g["present"] += 1
        elif st == "absence":
            g["absent"] += 1
        elif st == "leave":
            g["leave"] += 1
        elif st == "mission":
            g["mission"] += 1
        elif st is None:
            g["not_marked"] += 1

    result = []
    for g in groups.values():
        g["coverage_pct"] = round((g["present"] / g["total"]) * 100) if g["total"] else 0
        result.append(g)
    result.sort(key=lambda g: (g["department"], g["sub_department"]))
    return result


@app.route("/sub-departments", methods=["GET", "POST"])
@permission_required("manage_employees")
def sub_departments_page():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        parent = request.form.get("parent_department", "").strip()
        name = request.form.get("name", "").strip()
        if parent and name:
            try:
                conn.execute(
                    "INSERT INTO sub_departments (parent_department, name) VALUES (?, ?)", (parent, name)
                )
                conn.commit()
                flash("تمت إضافة القسم الفرعي", "ok")
            except Exception:
                flash("القسم الفرعي ده موجود بالفعل تحت نفس القسم", "error")
        return redirect(url_for("sub_departments_page"))

    sub_depts = conn.execute("SELECT * FROM sub_departments ORDER BY parent_department, name").fetchall()
    sel_date = clean_date(request.args.get("date"))
    dept_filter = request.args.get("department", "")
    workforce = build_workforce_detail(conn, branch_ids, sel_date, group_by_sub=True, dept_filter=dept_filter or None)

    return render_template(
        "sub_departments.html", sub_depts=sub_depts, workforce=workforce,
        DEPARTMENTS=DEPARTMENTS, sel_date=sel_date, dept_filter=dept_filter,
    )


@app.route("/sub-departments/export.xlsx")
@permission_required("manage_employees")
def sub_departments_export():
    """تصدير تقرير القوة التشغيلية التفصيلي (أسامي الموظفين وحالتهم) ليوم معيّن — Excel."""
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_date = clean_date(request.args.get("date"))
    dept_filter = request.args.get("department", "")
    workforce = build_workforce_detail(conn, branch_ids, sel_date, group_by_sub=True, dept_filter=dept_filter or None)

    from openpyxl.styles import Border, Side
    wb = Workbook()
    ws = wb.active
    ws.title = "القوة التشغيلية"
    ws.sheet_view.rightToLeft = True
    navy, cyan = "002060", "00B0F0"
    thin = Side(style="thin", color="B7B7B7")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    status_fill = {
        "present": "C6EFCE", "absence": "FFC7CE", "leave": "BDD7EE",
        "mission": "E4C7F1", "half_day": "FFEB9C", None: "F2F2F2",
    }

    def put(cell, value, fill=None, color="000000", bold=False, size=11):
        c = ws[cell]
        c.value = value
        c.font = Font(bold=bold, color=color, size=size)
        c.alignment = center
        c.border = border
        if fill:
            c.fill = PatternFill("solid", fgColor=fill)
        return c

    title = f"تقرير القوة التشغيلية — {sel_date}" + (f" — {dept_filter}" if dept_filter else "")
    ws.merge_cells("A1:G1")
    put("A1", title, navy, "FFFFFF", True, 15)
    headers = ["القسم", "القسم الفرعي", "الموظف", "المسمى الوظيفي", "البصمة", "الحالة", "وقت الحضور/الانصراف"]
    for i, h in enumerate(headers):
        put(f"{chr(65 + i)}2", h, cyan, bold=True)

    row_i = 3
    for g in workforce:
        for e in g["employees"]:
            times = " / ".join(t for t in (e["check_in"], e["check_out"]) if t) or "—"
            put(f"A{row_i}", g["department"])
            put(f"B{row_i}", g["sub_department"])
            put(f"C{row_i}", e["name"])
            put(f"D{row_i}", e["job_title"])
            put(f"E{row_i}", e["fingerprint_no"] or "—")
            put(f"F{row_i}", e["status_ar"], status_fill.get(e["status"]), bold=True)
            put(f"G{row_i}", times)
            row_i += 1
        if g["employees"]:
            put(f"A{row_i}", f"إجمالي {g['department']} — {g['sub_department']}", "F2F2F2", bold=True)
            ws.merge_cells(f"A{row_i}:E{row_i}")
            put(f"F{row_i}", f"{g['present']}/{g['total']} حاضر ({g['coverage_pct']}%)", "F2F2F2", bold=True)
            ws.merge_cells(f"F{row_i}:G{row_i}")
            row_i += 1

    widths = [16, 20, 26, 20, 12, 14, 20]
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    ws.freeze_panes = "A3"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"القوة_التشغيلية_{sel_date}.xlsx"
    return send_file(buf, as_attachment=True, download_name=fname,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/sub-departments/print")
@permission_required("manage_employees")
def sub_departments_print():
    """نسخة طباعة/PDF مخصّصة لتقرير القوة التشغيلية والأسامي — مستند A4 متعدد الصفحات بتصميم مرتّب،
    بدل الاعتماد على طباعة المتصفح الافتراضية للصفحة الشغالة."""
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_date = clean_date(request.args.get("date"))
    dept_filter = request.args.get("department", "")
    sel_branch = request.args.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else None
    use_branch_ids = [sel_branch] if sel_branch and sel_branch in branch_ids else branch_ids
    workforce = build_workforce_detail(conn, use_branch_ids, sel_date, group_by_sub=True, dept_filter=dept_filter or None)

    totals = {"total": 0, "present": 0, "absent": 0, "leave": 0, "mission": 0, "not_marked": 0}
    for g in workforce:
        for k in totals:
            totals[k] += g.get(k, 0)
    totals["coverage_pct"] = round(totals["present"] / totals["total"] * 100) if totals["total"] else 0

    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({','.join('?' * len(branch_ids))})", branch_ids).fetchall()
    branch_name = (next((b['name'] for b in branch_rows if b['id'] == sel_branch), '')
                  if sel_branch else ("كل الفروع" if len(branch_rows) > 1 else (branch_rows[0]['name'] if branch_rows else '')))
    branch_logo = next((b["logo_path"] for b in branch_rows if b["id"] == sel_branch), None) if sel_branch else None

    return render_template(
        "workforce_print.html", workforce=workforce, totals=totals, sel_date=sel_date,
        dept_filter=dept_filter, branches=branch_rows, sel_branch=sel_branch, branch_name=branch_name,
        branch_logo=branch_logo, printed_at=datetime.now().strftime("%Y-%m-%d %H:%M"),
    )


@app.route("/sub-departments/<int:sd_id>/delete", methods=["POST"])
@permission_required("manage_employees")
def delete_sub_department(sd_id):
    conn = get_conn()
    conn.execute("DELETE FROM sub_departments WHERE id=?", (sd_id,))
    conn.commit()
    flash("تم حذف القسم الفرعي", "ok")
    return redirect(url_for("sub_departments_page"))


EMP_IMPORT_HEADERS = [
    "الاسم", "رقم البصمة", "القسم", "القسم الفرعي", "الوظيفة", "الراتب الأساسي",
    "بدل سكن", "بدل انتقال", "بدل وجبة", "تأمينات اجتماعية", "ضريبة دخل",
    "تاريخ بداية العمل", "مكان السكن", "نوع الإقامة (مقيم/مغترب)", "يوم الإجازة الأسبوعي",
    "رقم الهاتف", "الرقم القومي", "اسم البنك", "رقم الحساب البنكي",
    "اسم قريب للطوارئ", "صلة القرابة", "هاتف القريب",
]


@app.route("/employees/import", methods=["GET", "POST"])
@permission_required("manage_employees")
def employees_import():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    branch_rows = conn.execute(f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()

    if request.method == "POST":
        branch_id = int(request.form.get("branch_id"))
        if branch_id not in branch_ids:
            flash("لا تملك صلاحية على هذا الفرع", "error")
            return redirect(url_for("employees_import"))
        file = request.files.get("file")
        if not file or not file.filename.lower().endswith((".xlsx", ".xlsm")):
            flash("لازم ترفع ملف Excel بصيغة xlsx", "error")
            return redirect(url_for("employees_import"))

        def cell_str(row, idx):
            return str(row[idx]).strip() if len(row) > idx and row[idx] not in (None, "") else ""

        def cell_float(row, idx):
            try:
                return float(row[idx]) if len(row) > idx and row[idx] not in (None, "") else 0
            except (ValueError, TypeError):
                return 0

        wb = load_workbook(file, data_only=True)
        ws = wb.active
        added, errors, duplicates = 0, 0, 0
        dup_names = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or not row[0]:
                continue
            name = cell_str(row, 0)
            if not name:
                continue

            fp = cell_str(row, 1)
            dup = find_duplicate_employee(conn, branch_id, name, fp)
            if dup:
                duplicates += 1
                if len(dup_names) < 8:
                    dup_names.append(dup["name"])
                continue

            residence_type = cell_str(row, 13)
            if residence_type not in ("مقيم", "مغترب"):
                residence_type = "مقيم"
            start_date = _parse_cell_date(row[11]) if len(row) > 11 and row[11] else None

            cur = conn.execute(
                """INSERT INTO employees (branch_id, fingerprint_no, name, department, sub_department,
                   job_title, base_salary, housing_allowance, transport_allowance, meal_allowance,
                   social_insurance, tax_deduction, start_date, residence, residence_type,
                   weekly_day_off, phone, national_id, bank_name, bank_account,
                   relative_name, relative_relation, relative_phone, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')""",
                (
                    branch_id, cell_str(row, 1), name, cell_str(row, 2) or "غير محدد", cell_str(row, 3) or None,
                    cell_str(row, 4), cell_float(row, 5), cell_float(row, 6), cell_float(row, 7), cell_float(row, 8),
                    cell_float(row, 9), cell_float(row, 10), start_date, cell_str(row, 12), residence_type,
                    cell_str(row, 14) or None, cell_str(row, 15), cell_str(row, 16), cell_str(row, 17), cell_str(row, 18),
                    cell_str(row, 19), cell_str(row, 20), cell_str(row, 21),
                ),
            )
            new_id = cur.lastrowid
            for item in db.DEFAULT_ONBOARDING_ITEMS:
                conn.execute(
                    "INSERT INTO checklist_items (employee_id, kind, item) VALUES (?, 'onboarding', ?)",
                    (new_id, item),
                )
            added += 1

        db.log_action(conn, u, "استيراد موظفين بالجملة", "employee", None, f"{added} موظف")
        conn.commit()
        msg = f"تم استيراد {added} موظف بنجاح"
        if errors:
            msg += f" ({errors} تحذير في بيانات الراتب)"
        if duplicates:
            names_preview = "، ".join(dup_names) + ("…" if duplicates > len(dup_names) else "")
            msg += f" — تم تجاهل {duplicates} صف مكرر (نفس الاسم أو البصمة موجود بالفعل في هذا الفرع: {names_preview})"
        flash(msg, "ok" if added else "error")
        return redirect(url_for("employees"))

    return render_template("employees_import.html", branches=branch_rows)


@app.route("/employees/import/template.xlsx")
@permission_required("manage_employees")
def employees_import_template():
    wb = Workbook()
    ws = wb.active
    ws.title = "نموذج الموظفين"
    ws.sheet_view.rightToLeft = True
    ws.append(EMP_IMPORT_HEADERS)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
    ws.append([
        "مثال: أحمد محمد", "801", "مطبخ", "الشواية", "شيف مساعد", 3000,
        500, 300, 200, 0, 0,
        date.today(), "المعادي", "مقيم", "الجمعة",
        "01012345678", "29001011234567", "بنك مصر", "EG123456789",
        "محمد أحمد", "الأب", "01098765432",
    ])
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 20
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name="employees_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/employees/<int:emp_id>/edit", methods=["GET", "POST"])
@permission_required("manage_employees")
def edit_employee(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        flash("الموظف غير موجود", "error")
        return redirect(url_for("employees"))

    if request.method == "POST":
        new_branch_id = int(request.form.get("branch_id"))
        new_fp = request.form.get("fingerprint_no", "").strip()
        if new_fp:
            clash = conn.execute(
                "SELECT id, name FROM employees WHERE branch_id=? AND fingerprint_no=? AND id != ?",
                (new_branch_id, new_fp, emp_id)).fetchone()
            if clash:
                flash(f"رقم البصمة {new_fp} مستخدم بالفعل للموظف «{clash['name']}» في نفس الفرع — "
                      "غيّر الرقم أو راجع بيانات الموظف التاني.", "error")
                return redirect(url_for("edit_employee", emp_id=emp_id))
        conn.execute(
            """UPDATE employees SET branch_id=?, fingerprint_no=?, name=?, department=?,
               sub_department=?, job_title=?, base_salary=?, housing_allowance=?, transport_allowance=?,
               meal_allowance=?, social_insurance=?, tax_deduction=?, national_id=?,
               bank_name=?, bank_account=?, start_date=?, residence=?, residence_type=?,
               weekly_day_off=?, phone=?, relative_name=?, relative_phone=?, relative_relation=?,
               housing_unit_id=?, status=? WHERE id=?""",
            (
                new_branch_id,
                new_fp,
                request.form.get("name", "").strip(),
                request.form.get("department", "").strip() or "غير محدد",
                request.form.get("sub_department", "").strip() or None,
                request.form.get("job_title", "").strip(),
                float(request.form.get("base_salary") or 0),
                float(request.form.get("housing_allowance") or 0),
                float(request.form.get("transport_allowance") or 0),
                float(request.form.get("meal_allowance") or 0),
                float(request.form.get("social_insurance") or 0),
                float(request.form.get("tax_deduction") or 0),
                request.form.get("national_id", "").strip(),
                request.form.get("bank_name", "").strip(),
                request.form.get("bank_account", "").strip(),
                request.form.get("start_date") or None,
                request.form.get("residence", "").strip(),
                request.form.get("residence_type") or "مقيم",
                request.form.get("weekly_day_off", "").strip() or None,
                request.form.get("phone", "").strip(),
                request.form.get("relative_name", "").strip(),
                request.form.get("relative_phone", "").strip(),
                request.form.get("relative_relation", "").strip(),
                int(request.form.get("housing_unit_id")) if request.form.get("housing_unit_id") else None,
                request.form.get("status"),
                emp_id,
            ),
        )
        db.log_action(conn, current_user(), "تعديل بيانات موظف", "employee", emp_id,
                      request.form.get("name", ""))
        conn.commit()
        flash("تم تحديث بيانات الموظف", "ok")
        return redirect(url_for("edit_employee", emp_id=emp_id))

    sub_departments_ = conn.execute(
        "SELECT * FROM sub_departments WHERE parent_department=? ORDER BY name", (emp["department"],)
    ).fetchall()
    housing_units_ = conn.execute(
        "SELECT * FROM company_housing_units WHERE branch_id=? ORDER BY name", (emp["branch_id"],)
    ).fetchall()
    branch_rows = conn.execute("SELECT * FROM branches").fetchall()
    documents = conn.execute(
        "SELECT * FROM employee_documents WHERE employee_id=? ORDER BY id DESC", (emp_id,)
    ).fetchall()
    checklist_on = conn.execute(
        "SELECT * FROM checklist_items WHERE employee_id=? AND kind='onboarding' ORDER BY id", (emp_id,)
    ).fetchall()
    checklist_off = conn.execute(
        "SELECT * FROM checklist_items WHERE employee_id=? AND kind='offboarding' ORDER BY id", (emp_id,)
    ).fetchall()
    evaluations_ = conn.execute(
        "SELECT * FROM evaluations WHERE employee_id=? ORDER BY period DESC", (emp_id,)
    ).fetchall()
    return render_template(
        "employee_edit.html", e=emp, branches=branch_rows, documents=documents,
        checklist_on=checklist_on, checklist_off=checklist_off, evaluations=evaluations_,
        can_manage_docs=has_permission(current_user(), "manage_documents"),
        can_evaluate=has_permission(current_user(), "manage_evaluations"),
        today_iso=date.today().isoformat(), sub_departments=sub_departments_,
        housing_units=housing_units_, leave_rotation=db.leave_rotation_status(conn, emp),
    )


@app.route("/employees/<int:emp_id>/checklist/<int:item_id>/toggle", methods=["POST"])
@permission_required("manage_employees")
def toggle_checklist_item(emp_id, item_id):
    conn = get_conn()
    row = conn.execute("SELECT done FROM checklist_items WHERE id=? AND employee_id=?", (item_id, emp_id)).fetchone()
    if row:
        new_val = 0 if row["done"] else 1
        done_at = date.today().isoformat() if new_val else None
        conn.execute("UPDATE checklist_items SET done=?, done_at=? WHERE id=?", (new_val, done_at, item_id))
        conn.commit()
    return redirect(url_for("edit_employee", emp_id=emp_id))


@app.route("/employees/<int:emp_id>/photo", methods=["POST"])
@permission_required("manage_documents")
def upload_employee_photo(emp_id):
    conn = get_conn()
    file = request.files.get("photo")
    path, err = save_upload(file, "employees", images_only=True)
    if path:
        conn.execute("UPDATE employees SET photo_path=? WHERE id=?", (path, emp_id))
        db.log_action(conn, current_user(), "رفع صورة موظف", "employee", emp_id, path)
        conn.commit()
        flash("تم رفع الصورة", "ok")
    else:
        flash(f"لم يتم رفع الصورة: {err}", "error")
    return redirect(url_for("edit_employee", emp_id=emp_id))


@app.route("/employees/<int:emp_id>/documents/add", methods=["POST"])
@permission_required("manage_documents")
def add_employee_document(emp_id):
    conn = get_conn()
    file = request.files.get("file")
    path, err = save_upload(file, "documents")
    if path:
        conn.execute(
            """INSERT INTO employee_documents (employee_id, doc_type, file_path, submitted_date, expiry_date, note)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                emp_id,
                request.form.get("doc_type", "أخرى"),
                path,
                request.form.get("submitted_date") or date.today().isoformat(),
                request.form.get("expiry_date") or None,
                request.form.get("note", "").strip(),
            ),
        )
        conn.commit()
        flash("تم رفع المستند", "ok")
    else:
        flash(f"لم يتم رفع المستند: {err}", "error")
    return redirect(url_for("edit_employee", emp_id=emp_id))


@app.route("/employees/<int:emp_id>/documents/<int:doc_id>/delete", methods=["POST"])
@permission_required("manage_documents")
def delete_employee_document(emp_id, doc_id):
    conn = get_conn()
    conn.execute("DELETE FROM employee_documents WHERE id=? AND employee_id=?", (doc_id, emp_id))
    conn.commit()
    flash("تم حذف المستند", "ok")
    return redirect(url_for("edit_employee", emp_id=emp_id))


@app.route("/employees/<int:emp_id>/toggle", methods=["POST"])
@permission_required("manage_employees")
def toggle_employee(emp_id):
    u = current_user()
    conn = get_conn()
    row = conn.execute("SELECT status, name FROM employees WHERE id=?", (emp_id,)).fetchone()
    if row:
        new_status = "inactive" if row["status"] == "active" else "active"
        end_date = date.today().isoformat() if new_status == "inactive" else None
        conn.execute(
            "UPDATE employees SET status=?, end_date=? WHERE id=?",
            (new_status, end_date, emp_id),
        )
        if new_status == "inactive":
            existing = conn.execute(
                "SELECT COUNT(*) c FROM checklist_items WHERE employee_id=? AND kind='offboarding'",
                (emp_id,),
            ).fetchone()["c"]
            if existing == 0:
                for item in db.DEFAULT_OFFBOARDING_ITEMS:
                    conn.execute(
                        "INSERT INTO checklist_items (employee_id, kind, item) VALUES (?, 'offboarding', ?)",
                        (emp_id, item),
                    )
            db.log_action(conn, u, "إنهاء خدمة موظف", "employee", emp_id, row["name"])
        else:
            db.log_action(conn, u, "إعادة تفعيل موظف", "employee", emp_id, row["name"])
        conn.commit()
    return redirect(url_for("employees"))


@app.route("/documents/expiring")
@permission_required("manage_documents")
def expiring_documents():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    cutoff = (date.today() + timedelta(days=30)).isoformat()
    rows = conn.execute(
        f"""SELECT d.*, e.name AS emp_name, e.department FROM employee_documents d
            JOIN employees e ON e.id = d.employee_id
            WHERE e.branch_id IN ({placeholders}) AND d.expiry_date IS NOT NULL AND d.expiry_date <= ?
            ORDER BY d.expiry_date ASC""",
        branch_ids + [cutoff],
    ).fetchall()
    today_iso = date.today().isoformat()
    return render_template("expiring_documents.html", rows=rows, today=today_iso)


def previous_period_label(label, n=1):
    y, m = map(int, label.split("-"))
    for _ in range(n):
        m -= 1
        if m < 1:
            m = 12
            y -= 1
    return f"{y:04d}-{m:02d}"


def gather_employee_profile_data(emp_id, branch_ids, u, month_arg):
    conn = get_conn()
    emp = conn.execute(
        "SELECT e.*, b.name AS branch_name FROM employees e JOIN branches b ON b.id=e.branch_id WHERE e.id=?",
        (emp_id,),
    ).fetchone()
    if not emp or emp["branch_id"] not in branch_ids:
        return None

    label, p_start, p_end = period_context(month_arg)

    att_counts = conn.execute(
        """SELECT status, COUNT(*) c FROM attendance WHERE employee_id=? AND date BETWEEN ? AND ?
           GROUP BY status""",
        (emp_id, p_start.isoformat(), p_end.isoformat()),
    ).fetchall()
    att_map = {r["status"]: r["c"] for r in att_counts}
    total_marked = sum(att_map.values())
    attendance_pct = round((att_map.get("present", 0) / total_marked) * 100, 1) if total_marked else None

    this_year = date.today().year
    violations_ = conn.execute(
        """SELECT v.*, vt.name AS type_name FROM violations v
           JOIN violation_types vt ON vt.id = v.violation_type_id
           WHERE v.employee_id=? AND substr(v.date,1,4)=? ORDER BY v.date DESC""",
        (emp_id, str(this_year)),
    ).fetchall()

    evaluations_ = conn.execute(
        "SELECT * FROM evaluations WHERE employee_id=? ORDER BY period", (emp_id,)
    ).fetchall()

    leave_types_ = conn.execute("SELECT * FROM leave_types ORDER BY id").fetchall()
    balances = []
    for lt in leave_types_:
        if lt["annual_quota"] is None:
            continue
        b = db.leave_balance(conn, emp_id, lt["id"], this_year)
        balances.append({"type_name": lt["name"], **b})

    active_advances = conn.execute(
        "SELECT * FROM advances WHERE employee_id=? AND status='active' ORDER BY id", (emp_id,)
    ).fetchall()

    documents = conn.execute(
        "SELECT * FROM employee_documents WHERE employee_id=? ORDER BY id DESC", (emp_id,)
    ).fetchall()

    trend = []
    for i in range(5, -1, -1):
        lbl = previous_period_label(label, i)
        ps, pe = db.period_bounds(lbl, MONTH_START_DAY)
        rep, _ = build_payroll_report([emp["branch_id"]], lbl, ps, pe, persist=False, only_employee=emp_id)
        row = next((r for r in rep if r["id"] == emp_id), None)
        trend.append({"label": lbl, "net": row["net"] if row else 0})

    payroll_report_row = None
    if has_permission(u, "view_payroll"):
        rep, _ = build_payroll_report([emp["branch_id"]], label, p_start, p_end, only_employee=emp_id)
        payroll_report_row = next((r for r in rep if r["id"] == emp_id), None)

    return dict(
        e=emp, month=label, p_start=p_start, p_end=p_end,
        att_map=att_map, attendance_pct=attendance_pct, violations=violations_,
        evaluations=evaluations_, balances=balances, active_advances=active_advances,
        documents=documents, trend=trend, this_year=this_year, payroll_row=payroll_report_row,
    )


@app.route("/employees/<int:emp_id>/profile")
@login_required
def employee_profile(emp_id):
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    data = gather_employee_profile_data(emp_id, branch_ids, u, request.args.get("month"))
    if not data:
        flash("لا تملك صلاحية عرض هذا الموظف", "error")
        return redirect(url_for("employees"))
    return render_template("employee_profile.html", **data)


@app.route("/employees/<int:emp_id>/comprehensive-report")
@login_required
def employee_comprehensive_report(emp_id):
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    data = gather_employee_profile_data(emp_id, branch_ids, u, request.args.get("month"))
    if not data:
        flash("لا تملك صلاحية عرض هذا الموظف", "error")
        return redirect(url_for("employees"))
    return render_template("employee_comprehensive_report.html", **data)


@app.route("/employees/<int:emp_id>/comprehensive-report/export.xlsx")
@login_required
def employee_comprehensive_report_export(emp_id):
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    data = gather_employee_profile_data(emp_id, branch_ids, u, request.args.get("month"))
    if not data:
        flash("لا تملك صلاحية عرض هذا الموظف", "error")
        return redirect(url_for("employees"))
    e = data["e"]

    wb = Workbook()
    ws = wb.active
    ws.title = "بيانات الموظف"
    ws.sheet_view.rightToLeft = True

    def add_section(title):
        ws.append([title])
        ws.cell(row=ws.max_row, column=1).font = Font(bold=True, color="FFFFFF")
        ws.cell(row=ws.max_row, column=1).fill = PatternFill("solid", fgColor="001A62")

    add_section("البيانات الأساسية")
    for label_, val in [
        ("الاسم", e["name"]), ("الفرع", e["branch_name"]), ("القسم", e["department"]),
        ("القسم الفرعي", e["sub_department"] or "—"), ("الوظيفة", e["job_title"] or "—"),
        ("رقم البصمة", e["fingerprint_no"] or "—"), ("الرقم القومي", e["national_id"] or "—"),
        ("تاريخ التعيين", e["start_date"] or "—"), ("الحالة", "نشط" if e["status"] == "active" else "غير نشط"),
    ]:
        ws.append([label_, val])

    add_section("بيانات الاتصال والسكن")
    for label_, val in [
        ("رقم الهاتف", e["phone"] or "—"), ("مكان السكن", e["residence"] or "—"),
        ("نوع الإقامة", e["residence_type"]), ("يوم الإجازة الأسبوعي", e["weekly_day_off"] or "—"),
        ("اسم قريب للطوارئ", e["relative_name"] or "—"), ("صلة القرابة", e["relative_relation"] or "—"),
        ("هاتف القريب", e["relative_phone"] or "—"),
    ]:
        ws.append([label_, val])

    add_section(f"ملخص الحضور — الفترة {data['month']}")
    ws.append(["حضور", "إجازة", "غياب", "نصف يوم", "مأمورية"])
    ws.append([
        data["att_map"].get("present", 0), data["att_map"].get("leave", 0),
        data["att_map"].get("absence", 0), data["att_map"].get("half_day", 0),
        data["att_map"].get("mission", 0),
    ])

    if data["payroll_row"]:
        add_section("ملخص الراتب")
        r = data["payroll_row"]
        ws.append(["إجمالي الاستحقاقات", r["gross"]])
        ws.append(["إجمالي الخصومات", r["absence_cut"] + r["deduction"] + r["fixed_deductions"]])
        ws.append(["مكافآت", r["bonus"]])
        ws.append(["الصافي", r["net"]])

    add_section("المخالفات المسجّلة هذا العام")
    ws.append(["النوع", "التاريخ", "المرة", "الإجراء"])
    for v in data["violations"]:
        ws.append([v["type_name"], v["date"], v["occurrence_no"], v["action_taken"]])

    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 22

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"employee_{emp_id}_report.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


# ---------------------------------------------------------------- Attendance --
@app.route("/attendance", methods=["GET", "POST"])
@permission_required("mark_attendance")
def attendance():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    sel_date = clean_date(request.values.get("date"))
    sel_branch = request.values.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)

    if request.method == "POST":
        for key, value in request.form.items():
            if key.startswith("status_"):
                emp_id = int(key.replace("status_", ""))
                if value in ("present", "leave", "absence", "half_day", "mission", "start_of_work", "resignation", "end_of_service"):
                    check_in = request.form.get(f"checkin_{emp_id}", "").strip() or None
                    check_out = request.form.get(f"checkout_{emp_id}", "").strip() or None
                    conn.execute(
                        """INSERT INTO attendance (employee_id, date, status, check_in, check_out)
                           VALUES (?, ?, ?, ?, ?)
                           ON CONFLICT(employee_id, date) DO UPDATE
                           SET status=excluded.status, check_in=excluded.check_in, check_out=excluded.check_out""",
                        (emp_id, sel_date, value, check_in, check_out),
                    )
        conn.commit()
        flash("تم حفظ الحضور ليوم " + sel_date, "ok")
        return redirect(url_for("attendance", date=sel_date, branch_id=sel_branch))

    placeholders = ",".join("?" * len(branch_ids))
    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids
    ).fetchall()

    d_sql, d_params = dept_clause(u, "e")
    emp_rows = []
    if sel_branch:
        emp_rows = conn.execute(
            f"""SELECT e.*, a.status AS today_status, a.check_in, a.check_out,
                       st.name AS shift_name, st.is_off AS shift_is_off,
                       CASE WHEN st.is_off = 1 THEN NULL ELSE st.start_time END AS shift_start,
                       CASE WHEN st.is_off = 1 THEN NULL ELSE st.end_time END AS shift_end
               FROM employees e
               LEFT JOIN attendance a ON a.employee_id = e.id AND a.date = ?
               LEFT JOIN shifts sh ON sh.employee_id = e.id AND sh.date = ?
               LEFT JOIN shift_types st ON st.id = sh.shift_type_id
               WHERE e.branch_id = ? AND e.status='active'{d_sql}
               ORDER BY e.name""",
            [sel_date, sel_date, sel_branch] + d_params,
        ).fetchall()
    return render_template(
        "attendance.html",
        branches=branch_rows,
        employees=emp_rows,
        sel_date=sel_date,
        sel_branch=sel_branch,
    )


# ------------------------------------------------------ استيراد من ملف البصمة --
MARK_MAP = {
    "P": "present", "O": "leave", "X": "absence", "H": "half_day",
    "M": "mission", "S": "start_of_work", "R": "resignation", "F": "end_of_service",
}


def _parse_cell_date(value):
    """يحاول يحوّل قيمة خلية (تاريخ أو نص) لتاريخ ISO كامل (بسنة وشهر صحيحين)."""
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, str):
        v = value.strip()
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y"):
            try:
                return datetime.strptime(v, fmt).date().isoformat()
            except ValueError:
                continue
    return None


def _parse_day_only(value):
    """لو خلية العنوان رقم يوم بس من غير شهر/سنة (زي أجهزة البصمة اللي بتصدّر أعمدة 1، 2، 3 ... 31
    بدون تاريخ كامل)، يرجّع رقم اليوم (1-31) أو None. مطلوب بعدين نركّبه مع الشهر اللي المستخدم اختاره."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        n = int(value)
        return n if 1 <= n <= 31 else None
    if isinstance(value, str):
        v = value.strip().translate(_AR_DIGITS)
        v = re.sub(r"[^\d]", "", v)
        if v and v.isdigit():
            n = int(v)
            return n if 1 <= n <= 31 else None
    return None


@app.route("/attendance/import", methods=["GET", "POST"])
@permission_required("mark_attendance")
def attendance_import():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    branch_rows = conn.execute(f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()

    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename.lower().endswith((".xlsx", ".xlsm")):
            flash("لازم ترفع ملف Excel بصيغة xlsx", "error")
            return redirect(url_for("attendance_import"))

        month_str = (request.form.get("month") or "").strip()
        if not _MONTH_RE.match(month_str):
            flash("لازم تحدد الشهر اللي الملف ده بتاعه (فوق زرار الاستيراد) — ده ضروري عشان أي عمود"
                  " في الملف يكون فيه رقم يوم بس (زي أجهزة البصمة) يتفهم صح ومايتلخبطش مع شهر تاني.", "error")
            return redirect(url_for("attendance_import"))
        # الفترة المحاسبية الفعلية لشركتنا مش شهر ميلادي عادي: بتبدأ يوم 29 وتنتهي 28 الشهر اللي بعده
        # (مطابقة لنفس الفترة المستخدمة في التقرير الشهري والرواتب في باقي البرنامج)
        month_start, month_end = db.period_bounds(month_str, MONTH_START_DAY)
        days_in_month = (month_end - month_start).days + 1

        wb = load_workbook(file, data_only=True)
        ws = wb.active
        header = [cell.value for cell in ws[1]]
        if len(header) < 3:
            flash("شكل الملف غير صحيح — استخدم النموذج المُصدَّر من هنا", "error")
            return redirect(url_for("attendance_import"))

        # كل عمود تاريخ: أول لو فيه تاريخ كامل (سنة وشهر) في الملف نفسه بنستخدمه زي ما هو،
        # وإلا لو رقم يوم بس (زي أجهزة البصمة) بنركّبه مع الشهر اللي المستخدم اختاره فوق.
        date_cols = {}          # idx -> iso date
        outside_month = 0       # عدد أعمدة فيها تاريخ كامل لكن مش في الشهر المختار (بنسيبها زي ما هي ونتجاهلها من العدّ)
        for idx, h in enumerate(header):
            if idx < 2:
                continue
            full = _parse_cell_date(h)
            if full:
                d = date.fromisoformat(full)
                if d < month_start or d > month_end:
                    outside_month += 1
                date_cols[idx] = full
                continue
            day_n = _parse_day_only(h)
            if day_n and day_n <= days_in_month:
                # يوم 1 = أول يوم في الفترة المحاسبية (يوم 29)، مش أول يوم في الشهر الميلادي
                date_cols[idx] = (month_start + timedelta(days=day_n - 1)).isoformat()

        if not date_cols:
            flash("مفيش أعمدة تواريخ أو أرقام أيام اتعرفت في صف العناوين — تأكد إن الصف الأول فيه"
                  " تواريخ أو أرقام أيام من 1 لـ31.", "error")
            return redirect(url_for("attendance_import"))

        sel_branch = request.form.get("branch_id")
        branch_scope = [int(sel_branch)] if sel_branch and int(sel_branch) in branch_ids else branch_ids

        imported, unmatched, skipped = 0, 0, 0
        touched_dates = set()
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or not row[0]:
                continue
            fp = str(row[0]).strip()
            emp = conn.execute(
                "SELECT id FROM employees WHERE fingerprint_no=? AND branch_id IN (%s)" % (",".join("?" * len(branch_scope))),
                [fp] + branch_scope,
            ).fetchone()
            if not emp:
                unmatched += 1
                continue
            for idx, iso_date in date_cols.items():
                if idx >= len(row):
                    continue
                mark = row[idx]
                if not mark:
                    continue
                status = MARK_MAP.get(str(mark).strip().upper())
                if not status:
                    skipped += 1
                    continue
                conn.execute(
                    """INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, ?)
                       ON CONFLICT(employee_id, date) DO UPDATE SET status=excluded.status""",
                    (emp["id"], iso_date, status),
                )
                imported += 1
                touched_dates.add(iso_date)

        month_label_ar = f"{month_str} ({month_start.isoformat()} → {month_end.isoformat()})"
        db.log_action(conn, u, "استيراد حضور من ملف", "attendance", None,
                      f"شهر {month_label_ar}: {imported} سجل ({len(touched_dates)} يوم)، {unmatched} رقم بصمة غير معروف")
        conn.commit()
        msg = f"تم استيراد {imported} سجل حضور بنجاح لشهر {month_label_ar} ({len(touched_dates)} يوم مختلف)."
        if unmatched:
            msg += f" {unmatched} رقم بصمة مش متسجّل."
        if skipped:
            msg += f" {skipped} علامة غير مفهومة اتجاهلت."
        if outside_month:
            msg += (f" ملحوظة: {outside_month} عمود في الملف فيه تاريخ كامل خارج شهر {month_label_ar}"
                    " المختار — اتسجّل بتاريخه الحقيقي زي ما هو في الملف مش بالشهر المختار.")
        flash(msg, "ok" if imported else "error")
        return redirect(url_for("attendance_import", month=month_str, branch_id=sel_branch or ""))

    default_month = request.args.get("month") or db.current_period_label(MONTH_START_DAY)
    if not _MONTH_RE.match(default_month):
        default_month = db.current_period_label(MONTH_START_DAY)
    default_branch = request.args.get("branch_id") or (branch_ids[0] if branch_ids else "")
    dp_start, dp_end = db.period_bounds(default_month, MONTH_START_DAY)

    # تغطية كل فترة محاسبية (29 → 28) بدل الشهر الميلادي العادي، عشان تطابق نفس تعريف "الشهر" في باقي البرنامج
    raw_dates = conn.execute(
        f"""SELECT DISTINCT a.date FROM attendance a JOIN employees e ON e.id = a.employee_id
            WHERE e.branch_id IN ({placeholders}) AND a.date >= date('now', '-18 months')""", branch_ids).fetchall()
    period_counts = {}
    for r in raw_dates:
        d = date.fromisoformat(r["date"])
        # تسمية الفترة: لو اليوم >= 29 فهو من فترة الشهر اللي بعده، زي current_period_label بالظبط
        y, m = d.year, d.month
        if d.day >= MONTH_START_DAY:
            m += 1
            if m > 12:
                m, y = 1, y + 1
        lbl = f"{y:04d}-{m:02d}"
        period_counts[lbl] = period_counts.get(lbl, 0) + 1
    months_coverage = [
        {"ym": lbl, "days": cnt, "range": db.period_bounds(lbl, MONTH_START_DAY)}
        for lbl, cnt in sorted(period_counts.items(), reverse=True)[:18]
    ]

    return render_template(
        "attendance_import.html", branches=branch_rows, default_month=default_month,
        default_branch=default_branch, months_coverage=months_coverage,
        dp_start=dp_start, dp_end=dp_end, month_start_day=MONTH_START_DAY,
    )


@app.route("/attendance/import/template.xlsx")
@permission_required("mark_attendance")
def attendance_import_template():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    branch_id = int(request.args.get("branch_id") or (branch_ids[0] if branch_ids else 0))
    month_str = request.args.get("month") or db.current_period_label(MONTH_START_DAY)
    if not _MONTH_RE.match(month_str):
        month_str = db.current_period_label(MONTH_START_DAY)
    p_start, p_end = db.period_bounds(month_str, MONTH_START_DAY)
    period_days = [p_start + timedelta(days=i) for i in range((p_end - p_start).days + 1)]

    conn = get_conn()
    d_sql, d_params = dept_clause(u, "e")
    employees_ = conn.execute(
        f"SELECT * FROM employees e WHERE e.branch_id=? AND e.status='active'{d_sql} ORDER BY e.name",
        [branch_id] + d_params,
    ).fetchall()

    wb = Workbook()
    ws = wb.active
    ws.title = "نموذج الحضور"
    ws.sheet_view.rightToLeft = True
    headers = ["رقم البصمة", "الاسم"] + period_days
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
    for c in range(3, 3 + len(period_days)):
        ws.cell(row=1, column=c).number_format = "yyyy-mm-dd"
    for e in employees_:
        ws.append([e["fingerprint_no"] or "", e["name"]] + [""] * len(period_days))
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 24
    for c in range(3, 3 + len(period_days)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = 12
    ws.freeze_panes = "C2"
    note_row = len(employees_) + 3
    ws.cell(row=note_row, column=1,
            value=f"الفترة المحاسبية لشهر {month_str}: من {p_start.isoformat()} إلى {p_end.isoformat()} ({len(period_days)} يوم)")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"attendance_template_{month_str}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


MARK_LETTER = {
    "present": "P", "leave": "O", "absence": "X", "half_day": "H",
    "mission": "M", "start_of_work": "S", "resignation": "R", "end_of_service": "F",
}


@app.route("/attendance/monthly-report")
@permission_required("mark_attendance")
def monthly_attendance_report():
    u = current_user()
    branch_ids = accessible_branch_ids(u)

    sel_branch = request.args.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)
    dept_filter = request.args.get("department", "")

    rows, day_list, label, p_start, p_end, branch_rows, branch_name = gather_monthly_report_data(
        u, branch_ids, sel_branch, dept_filter, request.args.get("month")
    )

    # إجماليات اليوم (كم موظف حاضر كل يوم) وإجماليات الأعمدة لصف المجموع
    day_totals = [
        sum(1 for r in rows if r["marks"][i] in ("P", "M", "S"))
        for i in range(len(day_list))
    ]
    col_totals = {
        k: sum(r[k] for r in rows)
        for k in ("present", "leave", "absence", "half_day", "mission", "advances_total", "violations_total")
    }
    weekday_ar = ["اث", "ثل", "أر", "خم", "جم", "سب", "أح"]  # Monday=0 ... Sunday=6
    branch_logo = next((b["logo_path"] for b in branch_rows if b["id"] == sel_branch), None)

    return render_template(
        "monthly_attendance_report.html", rows=rows, day_list=day_list, month=label,
        p_start=p_start, p_end=p_end, branches=branch_rows, sel_branch=sel_branch,
        branch_name=branch_name, dept_filter=dept_filter,
        day_totals=day_totals, col_totals=col_totals, weekday_ar=weekday_ar,
        branch_logo=branch_logo, printed_on=date.today().isoformat(),
    )


@app.route("/attendance/monthly-report/export.xlsx")
@permission_required("export_reports")
def monthly_attendance_report_export():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    sel_branch = request.args.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)
    dept_filter = request.args.get("department", "")

    rows, day_list, label, p_start, p_end, branch_rows, branch_name = gather_monthly_report_data(
        u, branch_ids, sel_branch, dept_filter, request.args.get("month")
    )

    wb = Workbook()
    ws = wb.active
    ws.title = "التقرير الشهري"
    ws.sheet_view.rightToLeft = True
    headers = ["الموظف", "البصمة", "الوظيفة"] + [d.strftime("%d") for d in day_list] + \
              ["حضور", "إجازة", "غياب", "نصف يوم", "مأمورية", "إجمالي السلف", "إجمالي الجزاءات"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
    for r in rows:
        ws.append([
            r["emp"]["name"], r["emp"]["fingerprint_no"] or "", r["emp"]["job_title"] or "",
        ] + r["marks"] + [
            r["present"], r["leave"], r["absence"], r["half_day"], r["mission"],
            r["advances_total"], r["violations_total"],
        ])
    ws.column_dimensions["A"].width = 22
    for i in range(4, 4 + len(day_list)):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = 4

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"monthly_attendance_{label}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def gather_monthly_report_data(u, branch_ids, sel_branch, dept_filter, month_arg):
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    label, p_start, p_end = period_context(month_arg)

    branch_rows = conn.execute(f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()
    branch_name = next((b["name"] for b in branch_rows if b["id"] == sel_branch), "")

    day_list = []
    d = p_start
    while d <= p_end:
        day_list.append(d)
        d += timedelta(days=1)

    scope_dept = dept_filter or (u["department"] or None)
    employees_ = []
    if sel_branch:
        employees_ = employees_in_period(conn, [sel_branch], p_start, p_end, scope_dept)

    # استعلامين فقط لكل الموظفين بدل 3 استعلامات لكل موظف
    marks_by_emp, totals_by_emp = {}, {}
    if employees_:
        ids = [e["id"] for e in employees_]
        ph = ",".join("?" * len(ids))
        for m in conn.execute(
            f"SELECT employee_id, date, status FROM attendance WHERE employee_id IN ({ph}) AND date BETWEEN ? AND ?",
            ids + [p_start.isoformat(), p_end.isoformat()],
        ).fetchall():
            marks_by_emp.setdefault(m["employee_id"], []).append(m)
        for r in conn.execute(
            f"""SELECT employee_id, source_type, COALESCE(SUM(amount),0) s FROM payroll_adjustments
                WHERE employee_id IN ({ph}) AND month=? AND source_type IN ('advance','violation')
                GROUP BY employee_id, source_type""",
            ids + [label],
        ).fetchall():
            totals_by_emp[(r["employee_id"], r["source_type"])] = r["s"]

    rows = []
    for e in employees_:
        marks = marks_by_emp.get(e["id"], [])
        mark_by_date = {m["date"]: MARK_LETTER.get(m["status"], "") for m in marks}
        counts = {}
        for m in marks:
            counts[m["status"]] = counts.get(m["status"], 0) + 1
        rows.append({
            "emp": e,
            "marks": [mark_by_date.get(d.isoformat(), "") for d in day_list],
            "present": counts.get("present", 0),
            "leave": counts.get("leave", 0),
            "absence": counts.get("absence", 0),
            "half_day": counts.get("half_day", 0),
            "mission": counts.get("mission", 0),
            "advances_total": totals_by_emp.get((e["id"], "advance"), 0),
            "violations_total": totals_by_emp.get((e["id"], "violation"), 0),
        })
    return rows, day_list, label, p_start, p_end, branch_rows, branch_name


# ------------------------------------------------------------- سجل الحضور --
@app.route("/attendance/daily-report")
@permission_required("mark_attendance")
def daily_report():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    sel_date = clean_date(request.args.get("date"))

    d_sql, d_params = dept_clause(u, "e")
    rows = conn.execute(
        f"""SELECT e.id, e.name, e.department, e.job_title, b.name AS branch_name,
                   a.status, a.check_in, a.check_out
            FROM employees e
            JOIN branches b ON b.id = e.branch_id
            LEFT JOIN attendance a ON a.employee_id = e.id AND a.date = ?
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'{d_sql}
            ORDER BY b.name, e.department, e.name""",
        [sel_date] + branch_ids + d_params,
    ).fetchall()

    counts = {}
    for r in rows:
        st = r["status"] or "not_marked"
        counts[st] = counts.get(st, 0) + 1

    return render_template(
        "daily_report.html", rows=rows, sel_date=sel_date, counts=counts, total=len(rows)
    )


@app.route("/attendance/log")
@permission_required("edit_attendance_log")
def attendance_log():
    conn = get_conn()
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    emp_q = request.args.get("employee_id", "")
    date_from = clean_date(request.args.get("from"), "")
    date_to = clean_date(request.args.get("to"), "")

    ph = ",".join("?" * len(branch_ids)) or "NULL"
    d_sql, d_params = dept_clause(u, "e")
    query = f"""SELECT a.id, a.date, a.status, e.id AS emp_id, e.name, e.department, b.name AS branch_name
               FROM attendance a
               JOIN employees e ON e.id = a.employee_id
               JOIN branches b ON b.id = e.branch_id
               WHERE e.branch_id IN ({ph}){d_sql}"""
    params = list(branch_ids) + d_params
    if emp_q:
        query += " AND e.id = ?"
        params.append(int(emp_q))
    if date_from:
        query += " AND a.date >= ?"
        params.append(date_from)
    if date_to:
        query += " AND a.date <= ?"
        params.append(date_to)
    query += " ORDER BY a.date DESC LIMIT 300"

    rows = conn.execute(query, params).fetchall()
    all_employees = conn.execute(
        f"SELECT e.id, e.name FROM employees e WHERE e.branch_id IN ({ph}){d_sql} ORDER BY e.name",
        list(branch_ids) + d_params,
    ).fetchall()
    return render_template(
        "attendance_log.html", rows=rows, all_employees=all_employees,
        emp_q=emp_q, date_from=date_from, date_to=date_to,
    )


@app.route("/attendance/log/<int:att_id>/update", methods=["POST"])
@permission_required("edit_attendance_log")
def attendance_log_update(att_id):
    conn = get_conn()
    new_status = request.form.get("status")
    if new_status in ("present", "leave", "absence", "half_day", "mission", "start_of_work", "resignation", "end_of_service"):
        conn.execute("UPDATE attendance SET status=? WHERE id=?", (new_status, att_id))
        conn.commit()
        flash("تم تحديث السجل", "ok")
    return redirect(url_for("attendance_log"))


@app.route("/attendance/log/<int:att_id>/delete", methods=["POST"])
@permission_required("edit_attendance_log")
def attendance_log_delete(att_id):
    conn = get_conn()
    conn.execute("DELETE FROM attendance WHERE id=?", (att_id,))
    conn.commit()
    flash("تم حذف السجل", "ok")
    return redirect(url_for("attendance_log"))


# ------------------------------------------------------------------- Leaves --
@app.route("/leaves")
@login_required
def leaves():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    label, p_start, p_end = period_context(request.args.get("month"))
    dept_filter = request.args.get("department", "")
    placeholders = ",".join("?" * len(branch_ids))
    d_sql, d_params = dept_clause(u, "e")

    query = f"""SELECT e.name, e.department, e.job_title, b.name AS branch_name, a.date, a.status
                FROM attendance a
                JOIN employees e ON e.id = a.employee_id
                JOIN branches b ON b.id = e.branch_id
                WHERE e.branch_id IN ({placeholders}) AND a.status='leave'
                      AND a.date BETWEEN ? AND ?{d_sql}"""
    params = branch_ids + [p_start.isoformat(), p_end.isoformat()] + d_params
    if dept_filter:
        query += " AND e.department = ?"
        params.append(dept_filter)
    query += " ORDER BY e.name, a.date"

    rows = conn.execute(query, params).fetchall()
    return render_template(
        "leaves.html", rows=rows, month=label,
        p_start=p_start, p_end=p_end, dept_filter=dept_filter,
    )


@app.route("/leaves/export.xlsx")
@permission_required("export_reports")
def leaves_export():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    label, p_start, p_end = period_context(request.args.get("month"))
    placeholders = ",".join("?" * len(branch_ids))
    d_sql, d_params = dept_clause(u, "e")

    rows = conn.execute(
        f"""SELECT e.name, e.department, e.job_title, b.name AS branch_name, a.date
            FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            JOIN branches b ON b.id = e.branch_id
            WHERE e.branch_id IN ({placeholders}) AND a.status='leave'
                  AND a.date BETWEEN ? AND ?{d_sql}
            ORDER BY e.name, a.date""",
        branch_ids + [p_start.isoformat(), p_end.isoformat()] + d_params,
    ).fetchall()

    wb = Workbook()
    ws = wb.active
    ws.title = "الإجازات"
    ws.sheet_view.rightToLeft = True
    headers = ["الموظف", "القسم", "الوظيفة", "الفرع", "تاريخ الإجازة"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
        cell.alignment = Alignment(horizontal="center")
    for r in rows:
        ws.append([r["name"], r["department"], r["job_title"], r["branch_name"], r["date"]])
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 22

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"leaves_{label}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


# ------------------------------------------------------------------ Payroll --

def find_duplicate_employee(conn, branch_id, name, fingerprint_no):
    """يدوّر على موظف حالي في نفس الفرع بنفس البصمة (لو موجودة) أو بنفس الاسم بالظبط،
    عشان نمنع تكرار الإضافة من الاستيراد أو النموذج اليدوي."""
    name = (name or "").strip()
    fp = (fingerprint_no or "").strip()
    if fp:
        row = conn.execute(
            "SELECT id, name, status FROM employees WHERE branch_id=? AND fingerprint_no=?",
            (branch_id, fp)).fetchone()
        if row:
            return row
    if name:
        row = conn.execute(
            "SELECT id, name, status FROM employees WHERE branch_id=? AND lower(trim(name))=lower(trim(?)) "
            "AND status='active'",
            (branch_id, name)).fetchone()
        if row:
            return row
    return None


def employees_in_period(conn, branch_ids, p_start, p_end, dept_filter=None, only_employee=None):
    """الموظفون اللي كانوا على رأس العمل في أي يوم من الفترة (مش بس النشطين حاليًا):
    اتعيّنوا قبل نهايتها ولم تنتهِ خدمتهم قبل بدايتها، أو عندهم حضور مسجّل فيها."""
    if not branch_ids:
        return []
    ph = ",".join("?" * len(branch_ids))
    s_iso, e_iso = p_start.isoformat(), p_end.isoformat()
    query = f"""
        SELECT * FROM employees e
        WHERE e.branch_id IN ({ph})
          AND (
            (
              (e.start_date IS NULL OR e.start_date = '' OR e.start_date <= ?)
              AND (
                (e.status = 'active' AND (e.end_date IS NULL OR e.end_date = '' OR e.end_date >= ?))
                OR (e.status != 'active' AND e.end_date IS NOT NULL AND e.end_date >= ?)
              )
            )
            OR EXISTS (SELECT 1 FROM attendance a WHERE a.employee_id = e.id AND a.date BETWEEN ? AND ?)
          )"""
    params = list(branch_ids) + [e_iso, s_iso, s_iso, s_iso, e_iso]
    if dept_filter:
        query += " AND e.department = ?"
        params.append(dept_filter)
    if only_employee:
        query += " AND e.id = ?"
        params.append(only_employee)
    query += " ORDER BY e.name"
    return conn.execute(query, params).fetchall()


def _safe_date(value):
    try:
        return date.fromisoformat(value) if value else None
    except ValueError:
        return None


def period_worked_days(e, p_start, p_end):
    """عدد أيام الفترة اللي الموظف كان فيها على رأس العمل (للراتب الجزئي للمعيَّن/المنتهية خدمته وسط الشهر)."""
    period_days = (p_end - p_start).days + 1
    start = max(p_start, _safe_date(e["start_date"]) or p_start)
    end = p_end
    if e["status"] != "active":
        end = min(p_end, _safe_date(e["end_date"]) or p_end)
    days = (end - start).days + 1
    if days <= 0:          # بيانات تعيين غير منطقية — نعتبره اشتغل الفترة كاملة بدل ما نصفّر راتبه
        days = period_days
    return min(days, period_days), period_days


def build_payroll_report(branch_ids, label, p_start, p_end, dept_filter=None,
                         persist=True, only_employee=None):
    """persist=False = قراءة فقط (للداشبورد/البروفايل): لا يكتب أي خصومات في القاعدة."""
    conn = get_conn()
    employees_ = employees_in_period(conn, branch_ids, p_start, p_end, dept_filter, only_employee)
    can_persist = persist and p_start <= date.today()

    period_days = (p_end - p_start).days + 1

    report = []
    total_net = 0
    for e in employees_:
        if can_persist:
            ensure_advance_deductions(conn, e["id"], label, p_end)
            ensure_time_based_adjustments(conn, e["id"], label, p_start, p_end)
        counts = conn.execute(
            """SELECT status, COUNT(*) c FROM attendance
               WHERE employee_id=? AND date BETWEEN ? AND ? GROUP BY status""",
            (e["id"], p_start.isoformat(), p_end.isoformat()),
        ).fetchall()
        c = {r["status"]: r["c"] for r in counts}
        present = c.get("present", 0)
        half = c.get("half_day", 0)
        absence = c.get("absence", 0)
        leave = c.get("leave", 0)
        mission = c.get("mission", 0)
        start_of_work = c.get("start_of_work", 0)

        adjustments = conn.execute(
            "SELECT * FROM payroll_adjustments WHERE employee_id=? AND month=? ORDER BY id",
            (e["id"], label),
        ).fetchall()
        bonus = sum(a["amount"] for a in adjustments if a["kind"] == "bonus")
        deduction = sum(a["amount"] for a in adjustments if a["kind"] == "deduction")

        allowances = round((e["housing_allowance"] or 0) + (e["transport_allowance"] or 0) + (e["meal_allowance"] or 0), 2)
        gross_full = round(e["base_salary"] + allowances, 2)
        worked_days, _pd = period_worked_days(e, p_start, p_end)
        prorated = worked_days < period_days
        gross = round(gross_full * worked_days / period_days, 2) if prorated else gross_full
        fixed_deductions = round((e["social_insurance"] or 0) + (e["tax_deduction"] or 0), 2)

        rate = db.daily_rate(e["base_salary"])
        absence_cut = round(absence * rate + half * rate / 2, 2)
        net = round(gross - absence_cut - fixed_deductions - deduction + bonus, 2)
        total_net += net

        report.append({
            "id": e["id"], "name": e["name"], "department": e["department"],
            "title": e["job_title"], "base_salary": e["base_salary"],
            "housing_allowance": e["housing_allowance"] or 0,
            "transport_allowance": e["transport_allowance"] or 0,
            "meal_allowance": e["meal_allowance"] or 0,
            "allowances": allowances, "gross": gross,
            "social_insurance": e["social_insurance"] or 0,
            "tax_deduction": e["tax_deduction"] or 0,
            "fixed_deductions": fixed_deductions,
            "bank_account": e["bank_account"], "bank_name": e["bank_name"],
            "national_id": e["national_id"],
            "present": present, "leave": leave, "absence": absence, "half_day": half,
            "mission": mission, "start_of_work": start_of_work,
            "daily_rate": rate, "absence_cut": absence_cut, "bonus": bonus,
            "deduction": deduction, "net": net, "adjustments": adjustments,
            "period_days": period_days, "worked_days": worked_days,
            "prorated": prorated, "gross_full": gross_full,
            "status": e["status"],
        })
    return report, round(total_net, 2)



# ------------------------------------------------- كشف المرتبات (المصدر الأساسي للراتب) --
_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩٬٫", "0123456789,.")


def parse_number(raw, default=None):
    """يقبل أرقام عربية/إنجليزية وفواصل آلاف (٢٣٬٠٠٠ أو 23,000)."""
    txt = (raw or "").translate(_AR_DIGITS).replace(",", "").replace(" ", "").strip()
    try:
        return float(txt)
    except ValueError:
        return default


def _num_out(v):
    return int(v) if float(v).is_integer() else round(float(v), 2)


def staff_sheet_data(conn, u, sel_branch):
    """بيانات كشف المرتبات: قائمة واحدة مجمّعة حسب القسم + مؤشرات الميزانية والمبيعات المتوقعة.
    المرتب الأساسي هنا هو نفسه عمود base_salary في بيانات الموظف — مصدر واحد، فأي تعديل هنا
    بيظهر فورًا في كل مكان تاني بيحسب الراتب (تفاصيل الرواتب، بروفايل الموظف، التقارير)."""
    branch = conn.execute("SELECT * FROM branches WHERE id=?", (sel_branch,)).fetchone()
    d_sql, d_params = dept_clause(u, "e")
    emps = conn.execute(
        f"""SELECT e.* FROM employees e WHERE e.branch_id=? AND e.status='active'{d_sql}
            ORDER BY e.department, (e.sort_order IS NULL), e.sort_order, e.base_salary DESC, e.name""",
        [sel_branch] + d_params).fetchall()

    groups_map = {}
    order = []
    for e in emps:
        dept = e["department"] or "بدون قسم"
        if dept not in groups_map:
            groups_map[dept] = []
            order.append(dept)
        groups_map[dept].append(e)
    grand_total = sum(e["base_salary"] for e in emps)
    departments = []
    for dept in order:
        lst = groups_map[dept]
        total = sum(e["base_salary"] for e in lst)
        departments.append({
            "name": dept, "employees": lst, "total": total, "count": len(lst),
            "pct_of_total": round(total / grand_total * 100, 1) if grand_total else 0,
        })
    # الأقسام الأكبر تكلفة أولًا، أسهل للمتابعة البصرية
    departments.sort(key=lambda d: d["total"], reverse=True)

    budget = parse_number(get_setting(conn, f"staff_budget_{sel_branch}", "0"), 0)
    sales = parse_number(get_setting(conn, f"staff_sales_{sel_branch}", "0"), 0)
    cost_pct = round(grand_total / sales * 100, 1) if sales else None
    return {
        "departments": departments, "branch": branch, "grand_total": grand_total,
        "emp_count": len(emps),
        "budget": budget, "sales": sales, "cost_pct": cost_pct,
        "remaining": budget - grand_total if budget else None,
        "ok_min": parse_number(get_setting(conn, "staff_ok_min", "15"), 15),
        "ok_max": parse_number(get_setting(conn, "staff_ok_max", "22"), 22),
    }


@app.route("/payroll/sheet")
@permission_required("view_payroll")
def payroll_sheet():
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_branch = request.args.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)
    if not sel_branch:
        flash("مفيش فروع متاحة لحسابك", "error")
        return redirect(url_for("dashboard"))
    data = staff_sheet_data(conn, u, sel_branch)
    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({','.join('?' * len(branch_ids))})", branch_ids).fetchall()
    return render_template(
        "payroll_sheet.html", sel_branch=sel_branch, branches=branch_rows,
        can_edit=has_permission(u, "manage_payroll"), num=_num_out, **data)


@app.route("/payroll/sheet/update", methods=["POST"])
@permission_required("manage_payroll")
def payroll_sheet_update():
    """تعديل خانة من الكشف (مرتب / اسم / مسمى وظيفي / بصمة) وحفظها في بيانات الموظف مباشرة."""
    conn = get_conn()
    u = current_user()
    emp_id = int(request.form.get("emp_id", "0"))
    field = request.form.get("field", "")
    raw = (request.form.get("value") or "").strip()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        return {"ok": False, "message": "الموظف غير موجود"}, 404
    synced_note = None
    if field == "base_salary":
        val = parse_number(raw, None)
        if val is None or val < 0 or val > 10_000_000:
            return {"ok": False, "message": "اكتب رقم صحيح للمرتب", "value": _num_out(emp["base_salary"])}, 400
        conn.execute("UPDATE employees SET base_salary=? WHERE id=?", (val, emp_id))
        db.log_action(conn, u, "تعديل مرتب من كشف المرتبات", "employee", emp_id,
                      f"{emp['name']}: {_num_out(emp['base_salary'])} ← {_num_out(val)}")
        out = _num_out(val)
        # كشف المرتبات هو نفسه مصدر الراتب الأساسي في كل مكان تاني — مفيش نسخة منفصلة بتتخزن،
        # فالتعديل هنا بيظهر فورًا في تفاصيل الرواتب وبروفايل الموظف والتقارير من غير أي خطوة إضافية.
        synced_note = "تم تحديث الراتب الأساسي — هيظهر فورًا في تفاصيل الرواتب وبروفايل الموظف."
    elif field in ("name", "job_title", "fingerprint_no"):
        if field == "name" and not raw:
            return {"ok": False, "message": "الاسم مينفعش يبقى فاضي", "value": emp["name"]}, 400
        limit = {"name": 120, "job_title": 80, "fingerprint_no": 30}[field]
        out = raw[:limit]
        conn.execute(f"UPDATE employees SET {field}=? WHERE id=?", (out or None, emp_id))
        db.log_action(conn, u, "تعديل بيانات من كشف المرتبات", "employee", emp_id, f"{emp['name']}: {field}")
    else:
        return {"ok": False, "message": "حقل غير مسموح"}, 400
    conn.commit()
    return {"ok": True, "value": out, "synced_note": synced_note}


@app.route("/payroll/sheet/settings", methods=["POST"])
@permission_required("manage_payroll")
def payroll_sheet_settings():
    conn = get_conn()
    branch = request.form.get("branch_id", "")
    key = request.form.get("key", "")
    val = (request.form.get("value") or "").strip()
    per_branch = {"budget": "staff_budget", "sales": "staff_sales"}
    global_keys = {"ok_min": "staff_ok_min", "ok_max": "staff_ok_max"}
    if key in ("budget", "sales", "ok_min", "ok_max"):
        num = parse_number(val, None)
        if num is None or num < 0:
            return {"ok": False, "message": "اكتب رقم صحيح"}, 400
        val = str(_num_out(num))
    if key in per_branch and branch:
        set_setting(conn, f"{per_branch[key]}_{int(branch)}", val[:200])
    elif key in global_keys:
        set_setting(conn, global_keys[key], val[:200])
    else:
        return {"ok": False, "message": "إعداد غير معروف"}, 400
    conn.commit()
    return {"ok": True, "value": val}


@app.route("/payroll/sheet/export.xlsx")
@permission_required("view_payroll")
def payroll_sheet_export():
    """تصدير كشف المرتبات: قائمة واحدة مجمّعة حسب القسم، مع إجمالي لكل قسم وملخص عام بمعادلات حيّة."""
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_branch = int(request.args.get("branch_id") or (branch_ids[0] if branch_ids else 0))
    data = staff_sheet_data(conn, u, sel_branch)
    from openpyxl.styles import Border, Side
    wb = Workbook()
    ws = wb.active
    ws.title = "كشف المرتبات"
    ws.sheet_view.rightToLeft = True
    navy, cyan, grey = "002060", "00B0F0", "F2F2F2"
    thin = Side(style="thin", color="B7B7B7")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    def put(cell, value, fill=None, color="000000", bold=False, size=11):
        c = ws[cell]
        c.value = value
        c.font = Font(bold=bold, color=color, size=size)
        c.alignment = center
        c.border = border
        if fill:
            c.fill = PatternFill("solid", fgColor=fill)
        return c

    bname = data["branch"]["name"] if data["branch"] else ""
    ws.merge_cells("A1:F1")
    put("A1", f"كشف المرتبات — {bname}", navy, "FFFFFF", True, 15)
    headers = ["القسم", "الموظف", "المسمى الوظيفي", "البصمة", "المرتب الأساسي"]
    for i, h in enumerate(headers):
        put(f"{chr(65 + i)}2", h, cyan, bold=True)

    row_i = 3
    for g in data["departments"]:
        dept_start = row_i
        for e in g["employees"]:
            put(f"A{row_i}", g["name"])
            put(f"B{row_i}", e["name"])
            put(f"C{row_i}", e["job_title"] or g["name"])
            put(f"D{row_i}", e["fingerprint_no"] or "—")
            put(f"E{row_i}", _num_out(e["base_salary"]), bold=True, color="157347")
            row_i += 1
        ws.merge_cells(f"A{row_i}:D{row_i}")
        put(f"A{row_i}", f"إجمالي {g['name']} ({g['count']} موظف)", grey, bold=True)
        put(f"E{row_i}", f"=SUM(E{dept_start}:E{row_i - 1})", grey, bold=True)
        row_i += 2

    # الملخص العام: كل مؤشر في زوج خلايا (عنوان فوق، قيمة تحت) بعرض عمودين مدموجين — عشان
    # النص العربي الطويل (زي "النسبة الصحيحة" أو "المبيعات المتوقعة") ميتكسرش بشكل بيكبّر الصف
    hdr = row_i + 1
    pairs = [
        ("عدد الموظفين", data["emp_count"]),
        ("إجمالي الرواتب", _num_out(data["grand_total"])),
        ("ميزانية العمالة", _num_out(data["budget"])),
        ("المبيعات المتوقعة", _num_out(data["sales"])),
        ("الكوست %", f"{data['cost_pct']}%" if data["cost_pct"] is not None else "—"),
        ("النسبة الصحيحة", f"بين {_num_out(data['ok_min'])}% و {_num_out(data['ok_max'])}%"),
    ]
    for i, (lab, val) in enumerate(pairs):
        col_pair, row_pair = i % 3, hdr + (i // 3) * 2
        c1, c2 = chr(65 + col_pair * 2), chr(66 + col_pair * 2)
        ws.merge_cells(f"{c1}{row_pair}:{c2}{row_pair}")
        put(f"{c1}{row_pair}", lab, navy, "FFFFFF", True)
        ws.merge_cells(f"{c1}{row_pair + 1}:{c2}{row_pair + 1}")
        put(f"{c1}{row_pair + 1}", val, "92D050", bold=True)

    widths = [16, 26, 20, 16, 16, 16]
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    ws.freeze_panes = "A3"

    # إعدادات الطباعة: صفحة واحدة بالعرض (الأعمدة الستة كلها في عرض الورقة) بدل ما تتقسّم على صفحتين
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.5
    ws.print_options.horizontalCentered = True

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="كشف_المرتبات.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/payroll")
@permission_required("view_payroll")
def payroll():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    label, p_start, p_end = period_context(request.args.get("month"))
    dept_filter = request.args.get("department", "") or (u["department"] or "")
    report, total_net = build_payroll_report(branch_ids, label, p_start, p_end, dept_filter or None)
    return render_template(
        "payroll.html", report=report, month=label, total_net=total_net,
        p_start=p_start, p_end=p_end, dept_filter=dept_filter,
    )


@app.route("/payroll/export.xlsx")
@permission_required("export_reports")
def payroll_export():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    label, p_start, p_end = period_context(request.args.get("month"))
    dept_filter = request.args.get("department", "") or (u["department"] or "")
    report, total_net = build_payroll_report(branch_ids, label, p_start, p_end, dept_filter or None)

    wb = Workbook()
    ws = wb.active
    ws.title = "الرواتب"
    ws.sheet_view.rightToLeft = True
    headers = ["الموظف", "القسم", "الوظيفة", "الراتب الأساسي", "بدل سكن", "بدل انتقال",
               "بدل وجبة", "الإجمالي", "حضور", "إجازة", "غياب", "نصف يوم", "خصم الغياب",
               "تأمينات", "ضريبة", "مكافآت", "خصومات أخرى", "الصافي"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
        cell.alignment = Alignment(horizontal="center")
    for r in report:
        ws.append([
            r["name"], r["department"], r["title"], r["base_salary"],
            r["housing_allowance"], r["transport_allowance"], r["meal_allowance"], r["gross"],
            r["present"], r["leave"], r["absence"], r["half_day"], r["absence_cut"],
            r["social_insurance"], r["tax_deduction"], r["bonus"], r["deduction"], r["net"],
        ])
    ws.append(["الإجمالي"] + [""] * 16 + [total_net])
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 15

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"payroll_{label}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/payroll/bank-export.xlsx")
@permission_required("export_reports")
def bank_export():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    label, p_start, p_end = period_context(request.args.get("month"))
    dept_filter = request.args.get("department", "") or (u["department"] or "")
    report, total_net = build_payroll_report(branch_ids, label, p_start, p_end, dept_filter or None)

    wb = Workbook()
    ws = wb.active
    ws.title = "تحويل البنك"
    ws.sheet_view.rightToLeft = True
    headers = ["اسم الموظف", "الرقم القومي", "اسم البنك", "رقم الحساب / الآيبان", "صافي الراتب"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="001A62")
        cell.alignment = Alignment(horizontal="center")
    missing_bank = 0
    for r in report:
        if not r["bank_account"]:
            missing_bank += 1
        ws.append([r["name"], r["national_id"] or "", r["bank_name"] or "", r["bank_account"] or "", r["net"]])
    ws.append(["الإجمالي", "", "", "", total_net])
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 22

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name=f"bank_transfer_{label}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/payroll/report/<int:emp_id>")
@permission_required("view_payroll")
def payroll_report(emp_id):
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    label, p_start, p_end = period_context(request.args.get("month"))
    conn = get_conn()
    emp = conn.execute(
        "SELECT e.*, b.name AS branch_name FROM employees e JOIN branches b ON b.id=e.branch_id WHERE e.id=?",
        (emp_id,),
    ).fetchone()
    if not emp or emp["branch_id"] not in branch_ids:
        flash("لا تملك صلاحية عرض هذا الموظف", "error")
        return redirect(url_for("payroll"))

    report, _ = build_payroll_report([emp["branch_id"]], label, p_start, p_end, only_employee=emp_id)
    row = next((r for r in report if r["id"] == emp_id), None)
    if not row:
        flash("لا توجد بيانات لهذا الموظف في هذه الفترة", "error")
        return redirect(url_for("payroll"))

    return render_template(
        "payroll_report.html", e=emp, r=row, month=label,
        p_start=p_start, p_end=p_end,
    )


@app.route("/payroll/adjustment", methods=["POST"])
@permission_required("manage_payroll")
def add_adjustment():
    conn = get_conn()
    u = current_user()
    conn.execute(
        "INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note) VALUES (?, ?, ?, ?, ?)",
        (
            int(request.form["employee_id"]),
            request.form["month"],
            request.form["kind"],
            float(request.form["amount"]),
            request.form.get("note", ""),
        ),
    )
    db.log_action(conn, u, "إضافة تسوية راتب", "employee", int(request.form["employee_id"]),
                  f"{request.form['kind']} {request.form['amount']} — {request.form.get('note','')}")
    conn.commit()
    flash("تمت إضافة التسوية", "ok")
    return redirect(url_for("payroll", month=request.form["month"]))


@app.route("/payroll/adjustment/<int:adj_id>/delete", methods=["POST"])
@permission_required("manage_payroll")
def delete_adjustment(adj_id):
    conn = get_conn()
    row = conn.execute("SELECT month, employee_id FROM payroll_adjustments WHERE id=?", (adj_id,)).fetchone()
    conn.execute("DELETE FROM payroll_adjustments WHERE id=?", (adj_id,))
    if row:
        db.log_action(conn, current_user(), "حذف تسوية راتب", "employee", row["employee_id"], f"adj#{adj_id}")
    conn.commit()
    flash("تم حذف التسوية", "ok")
    return redirect(url_for("payroll", month=row["month"] if row else None))


# ------------------------------------------------------------- طلبات الإجازات --
@app.route("/leaves/requests", methods=["GET", "POST"])
@login_required
def leave_requests():
    u = current_user()
    if not (has_permission(u, "submit_requests") or has_permission(u, "approve_requests")):
        flash("لا تملك صلاحية الوصول لهذه الصفحة", "error")
        return redirect(url_for("dashboard"))

    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        if not has_permission(u, "submit_requests"):
            flash("لا تملك صلاحية تقديم طلبات", "error")
            return redirect(url_for("leave_requests"))
        emp_id = int(request.form["employee_id"])
        leave_type_id = int(request.form["leave_type_id"])
        start = request.form["start_date"]
        end = request.form["end_date"]
        force = request.form.get("force") == "1"
        days_count = (date.fromisoformat(end) - date.fromisoformat(start)).days + 1
        if days_count < 1:
            flash("تاريخ النهاية لازم يكون بعد تاريخ البداية", "error")
            return redirect(url_for("leave_requests"))

        bal = db.leave_balance(conn, emp_id, leave_type_id, date.fromisoformat(start).year)
        if bal and bal["remaining"] is not None and bal["remaining"] < days_count and not force:
            flash(
                f"الرصيد المتاح {bal['remaining']} يوم بس، والطلب {days_count} يوم. "
                "لو عايز تتجاوز الرصيد، حدّد 'تجاوز الرصيد' وأعد الإرسال.",
                "error",
            )
            return redirect(url_for("leave_requests"))

        conn.execute(
            """INSERT INTO leave_requests (employee_id, leave_type_id, start_date, end_date,
               days_count, reason, requested_by) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (emp_id, leave_type_id, start, end, days_count, request.form.get("reason", ""), u["id"]),
        )
        conn.commit()
        flash("تم تقديم طلب الإجازة، في انتظار الاعتماد", "ok")
        return redirect(url_for("leave_requests"))

    placeholders = ",".join("?" * len(branch_ids))
    status_filter = request.args.get("status", "pending")
    query = f"""SELECT lr.*, e.name AS emp_name, e.department, lt.name AS type_name
                FROM leave_requests lr
                JOIN employees e ON e.id = lr.employee_id
                JOIN leave_types lt ON lt.id = lr.leave_type_id
                WHERE e.branch_id IN ({placeholders})"""
    params = list(branch_ids)
    if status_filter and status_filter != "all":
        query += " AND lr.status = ?"
        params.append(status_filter)
    query += " ORDER BY lr.created_at DESC LIMIT 200"
    rows = conn.execute(query, params).fetchall()

    employees_ = conn.execute(
        f"SELECT * FROM employees WHERE branch_id IN ({placeholders}) AND status='active' ORDER BY name",
        branch_ids,
    ).fetchall()
    leave_types_ = conn.execute("SELECT * FROM leave_types ORDER BY id").fetchall()

    this_year = date.today().year
    balances = []
    for e in employees_:
        for lt in leave_types_:
            if lt["annual_quota"] is None:
                continue
            b = db.leave_balance(conn, e["id"], lt["id"], this_year)
            balances.append({"emp_name": e["name"], "type_name": lt["name"], **b})

    return render_template(
        "leave_requests.html", rows=rows, employees=employees_, leave_types=leave_types_,
        status_filter=status_filter, balances=balances, this_year=this_year,
    )


@app.route("/leaves/requests/<int:req_id>/decide", methods=["POST"])
@permission_required("approve_requests")
def decide_leave_request(req_id):
    conn = get_conn()
    u = current_user()
    decision = request.form.get("decision")
    note = request.form.get("note", "")
    lr = conn.execute("SELECT * FROM leave_requests WHERE id=?", (req_id,)).fetchone()
    if not lr or lr["status"] != "pending":
        flash("الطلب غير موجود أو تم اتخاذ قرار فيه من قبل", "error")
        return redirect(url_for("leave_requests"))

    if decision == "approved":
        conn.execute(
            "UPDATE leave_requests SET status='approved', decided_by=?, decision_note=?, decided_at=datetime('now') WHERE id=?",
            (u["id"], note, req_id),
        )
        d = date.fromisoformat(lr["start_date"])
        end = date.fromisoformat(lr["end_date"])
        while d <= end:
            conn.execute(
                """INSERT INTO attendance (employee_id, date, status, leave_type_id) VALUES (?, ?, 'leave', ?)
                   ON CONFLICT(employee_id, date) DO UPDATE SET status='leave', leave_type_id=excluded.leave_type_id""",
                (lr["employee_id"], d.isoformat(), lr["leave_type_id"]),
            )
            d += timedelta(days=1)
        flash("تم اعتماد الإجازة وتسجيلها في الحضور", "ok")
    elif decision == "rejected":
        conn.execute(
            "UPDATE leave_requests SET status='rejected', decided_by=?, decision_note=?, decided_at=datetime('now') WHERE id=?",
            (u["id"], note, req_id),
        )
        flash("تم رفض الطلب", "ok")
    conn.commit()
    return redirect(url_for("leave_requests"))


@app.route("/leaves/types/add", methods=["POST"])
@permission_required("approve_requests")
def add_leave_type():
    conn = get_conn()
    name = request.form.get("name", "").strip()
    quota = request.form.get("annual_quota", "").strip()
    paid = 1 if request.form.get("paid") == "1" else 0
    if name:
        try:
            conn.execute(
                "INSERT INTO leave_types (name, annual_quota, paid) VALUES (?, ?, ?)",
                (name, int(quota) if quota else None, paid),
            )
            conn.commit()
            flash("تمت إضافة نوع الإجازة", "ok")
        except Exception:
            flash("نوع الإجازة ده موجود بالفعل", "error")
    return redirect(url_for("leave_requests"))


@app.route("/leaves/types/<int:lt_id>/edit", methods=["POST"])
@permission_required("approve_requests")
def edit_leave_type(lt_id):
    conn = get_conn()
    name = request.form.get("name", "").strip()
    quota = request.form.get("annual_quota", "").strip()
    paid = 1 if request.form.get("paid") == "1" else 0
    if name:
        try:
            conn.execute(
                "UPDATE leave_types SET name=?, annual_quota=?, paid=? WHERE id=?",
                (name, int(quota) if quota else None, paid, lt_id),
            )
            conn.commit()
            flash("تم تحديث نوع الإجازة", "ok")
        except Exception:
            flash("فيه نوع إجازة تاني بنفس الاسم", "error")
    return redirect(url_for("leave_requests"))


@app.route("/leaves/rotation")
@login_required
def leave_rotation_page():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    d_sql, d_params = dept_clause(u, "e")

    sel_branch = request.args.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else None
    q = f"""SELECT e.*, b.name AS branch_name FROM employees e JOIN branches b ON b.id=e.branch_id
            WHERE e.branch_id IN ({placeholders}) AND e.status='active'{d_sql}"""
    params = list(branch_ids) + d_params
    if sel_branch and sel_branch in branch_ids:
        q += " AND e.branch_id = ?"
        params.append(sel_branch)
    # المغتربون أولًا (أهم للمتابعة اليومية)، وبعدين المقيمون، وكل مجموعة مرتبة بالاسم
    q += " ORDER BY (e.residence_type = 'مغترب') DESC, e.name"
    employees_ = conn.execute(q, params).fetchall()

    rows = []
    for i, e in enumerate(employees_, start=1):
        rotation = db.leave_rotation_status(conn, e)
        rows.append({"n": i, "emp": e, **rotation})

    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()
    view = request.args.get("view") or "expat"
    if view not in ("expat", "resident"):
        view = "expat"
    return render_template(
        "leave_rotation.html", rows=rows, branches=branch_rows, sel_branch=sel_branch,
        weekdays=WEEKDAYS_AR, can_edit=has_permission(u, "approve_requests"),
        today_iso=date.today().isoformat(), view=view,
    )


@app.route("/leaves/rotation/update", methods=["POST"])
@permission_required("approve_requests")
def leave_rotation_update():
    """تسجيل مباشر لآخر رجوع من إجازة (مغترب) أو يوم الإجازة الأسبوعي (مقيم) — بدون المرور بطلب إجازة كامل."""
    conn = get_conn()
    emp_id = int(request.form.get("emp_id", "0"))
    field = request.form.get("field", "")
    val = (request.form.get("value") or "").strip()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        return {"ok": False, "message": "الموظف غير موجود"}, 404
    if field == "last_leave_return":
        if val:
            val = clean_date(val, "")
            if not val:
                return {"ok": False, "message": "تاريخ غير صالح"}, 400
            if val > date.today().isoformat():
                return {"ok": False, "message": "التاريخ لا يمكن أن يكون في المستقبل"}, 400
        conn.execute("UPDATE employees SET last_leave_return=? WHERE id=?", (val or None, emp_id))
    elif field == "last_leave_days":
        num = parse_number(val, None)
        if val and (num is None or num < 1 or num > 30):
            return {"ok": False, "message": "اكتب عدد أيام صحيح من 1 إلى 30"}, 400
        conn.execute("UPDATE employees SET last_leave_days=? WHERE id=?", (int(num) if num else None, emp_id))
    elif field == "weekly_day_off":
        if val and val not in WEEKDAYS_AR:
            return {"ok": False, "message": "يوم غير صالح"}, 400
        conn.execute("UPDATE employees SET weekly_day_off=? WHERE id=?", (val or None, emp_id))
    elif field == "job_title":
        conn.execute("UPDATE employees SET job_title=? WHERE id=?", (val[:80] or None, emp_id))
    elif field == "fingerprint_no":
        val = val[:30]
        if val:
            clash = conn.execute(
                "SELECT id, name FROM employees WHERE branch_id=? AND fingerprint_no=? AND id != ?",
                (emp["branch_id"], val, emp_id)).fetchone()
            if clash:
                return {"ok": False, "message": f"رقم البصمة {val} مستخدم بالفعل للموظف «{clash['name']}»",
                        "value": emp["fingerprint_no"] or ""}, 400
        conn.execute("UPDATE employees SET fingerprint_no=? WHERE id=?", (val or None, emp_id))
    else:
        return {"ok": False, "message": "حقل غير مسموح"}, 400
    db.log_action(conn, current_user(), "تحديث دورة الإجازة", "employee", emp_id, f"{emp['name']}: {field}")
    conn.commit()
    fresh = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    rotation = db.leave_rotation_status(conn, fresh)
    return {"ok": True, "rotation": dict(rotation)}


# ------------------------------------------------------------------- السلف --
@app.route("/advances", methods=["GET", "POST"])
@login_required
def advances():
    u = current_user()
    if not (has_permission(u, "submit_requests") or has_permission(u, "approve_requests")):
        flash("لا تملك صلاحية الوصول لهذه الصفحة", "error")
        return redirect(url_for("dashboard"))

    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        if not has_permission(u, "submit_requests"):
            flash("لا تملك صلاحية تقديم طلبات", "error")
            return redirect(url_for("advances"))
        principal = float(request.form["principal_amount"])
        installment = float(request.form["monthly_installment"])
        advance_type = request.form.get("advance_type", "installment")
        if advance_type not in ("installment", "monthly_full"):
            advance_type = "installment"
        conn.execute(
            """INSERT INTO advances (employee_id, principal_amount, monthly_installment,
               remaining_balance, advance_type, note, requested_by) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (int(request.form["employee_id"]), principal, installment, principal,
             advance_type, request.form.get("note", ""), u["id"]),
        )
        conn.commit()
        flash("تم تقديم طلب السلفة، في انتظار الاعتماد", "ok")
        return redirect(url_for("advances"))

    placeholders = ",".join("?" * len(branch_ids))
    status_filter = request.args.get("status", "pending")
    query = f"""SELECT adv.*, e.name AS emp_name, e.department FROM advances adv
                JOIN employees e ON e.id = adv.employee_id
                WHERE e.branch_id IN ({placeholders})"""
    params = list(branch_ids)
    if status_filter and status_filter != "all":
        query += " AND adv.status = ?"
        params.append(status_filter)
    query += " ORDER BY adv.created_at DESC LIMIT 200"
    rows = conn.execute(query, params).fetchall()

    employees_ = conn.execute(
        f"SELECT * FROM employees WHERE branch_id IN ({placeholders}) AND status='active' ORDER BY name",
        branch_ids,
    ).fetchall()
    return render_template("advances.html", rows=rows, employees=employees_, status_filter=status_filter)


@app.route("/advances/<int:adv_id>/decide", methods=["POST"])
@permission_required("approve_requests")
def decide_advance(adv_id):
    conn = get_conn()
    u = current_user()
    decision = request.form.get("decision")
    adv = conn.execute("SELECT * FROM advances WHERE id=?", (adv_id,)).fetchone()
    if not adv or adv["status"] != "pending":
        flash("الطلب غير موجود أو تم اتخاذ قرار فيه من قبل", "error")
        return redirect(url_for("advances"))
    new_status = "active" if decision == "approved" else "rejected"
    conn.execute(
        "UPDATE advances SET status=?, decided_by=?, decided_at=datetime('now') WHERE id=?",
        (new_status, u["id"], adv_id),
    )
    conn.commit()
    flash("تم اعتماد السلفة" if new_status == "active" else "تم رفض الطلب", "ok")
    return redirect(url_for("advances"))


@app.route("/advances/<int:adv_id>/edit", methods=["POST"])
@permission_required("approve_requests")
def edit_advance(adv_id):
    conn = get_conn()
    adv = conn.execute("SELECT * FROM advances WHERE id=?", (adv_id,)).fetchone()
    if not adv or adv["status"] not in ("pending", "active"):
        flash("لا يمكن تعديل هذه السلفة (لازم تكون قيد الانتظار أو نشطة)", "error")
        return redirect(url_for("advances"))

    new_installment = float(request.form.get("monthly_installment") or adv["monthly_installment"])
    new_type = request.form.get("advance_type", adv["advance_type"])
    if new_type not in ("installment", "monthly_full"):
        new_type = adv["advance_type"]
    new_note = request.form.get("note", adv["note"])

    conn.execute(
        "UPDATE advances SET monthly_installment=?, advance_type=?, note=? WHERE id=?",
        (new_installment, new_type, new_note, adv_id),
    )
    db.log_action(conn, current_user(), "تعديل سلفة", "employee", adv["employee_id"], f"adv#{adv_id}")
    conn.commit()
    flash("تم تحديث بيانات السلفة", "ok")
    return redirect(url_for("advances"))


def ensure_advance_deductions(conn, employee_id, label, p_end=None):
    """يطبّق قسط السلفة النشطة لهذا الموظف على هذه الفترة، لمرة واحدة فقط، تلقائيًا.
    لا يخصم من فترة انتهت قبل اعتماد السلفة."""
    active_advances = conn.execute(
        "SELECT * FROM advances WHERE employee_id=? AND status='active' AND remaining_balance > 0",
        (employee_id,),
    ).fetchall()
    if p_end is not None:
        cutoff = p_end.isoformat()
        active_advances = [
            a for a in active_advances
            if (a["decided_at"] or a["created_at"] or "0000")[:10] <= cutoff
        ]
    for adv in active_advances:
        existing = conn.execute(
            "SELECT id FROM payroll_adjustments WHERE source_type='advance' AND source_id=? AND month=?",
            (adv["id"], label),
        ).fetchone()
        if existing:
            continue
        amount = adv["remaining_balance"] if adv["advance_type"] == "monthly_full" else min(adv["monthly_installment"], adv["remaining_balance"])
        note = "سلفة (تسدّد بالكامل آخر الشهر)" if adv["advance_type"] == "monthly_full" else "قسط سلفة"
        conn.execute(
            """INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note, source_type, source_id)
               VALUES (?, ?, 'deduction', ?, ?, 'advance', ?)""",
            (employee_id, label, amount, note, adv["id"]),
        )
        new_balance = round(adv["remaining_balance"] - amount, 2)
        new_status = "closed" if new_balance <= 0 else "active"
        conn.execute(
            "UPDATE advances SET remaining_balance=?, status=? WHERE id=?",
            (new_balance, new_status, adv["id"]),
        )
    conn.commit()


LATE_DEDUCTION_THRESHOLD_MIN = 30   # تأخير 30 دقيقة فأكثر = خصم ربع يوم
LATE_DEDUCTION_DAYS = 0.25
OVERTIME_MIN_THRESHOLD = 15         # أقل من 15 دقيقة أوفر تايم بيتجاهل (هامش بسيط)
OVERTIME_RATE_MULTIPLIER = 1.5


def ensure_time_based_adjustments(conn, employee_id, label, p_start, p_end):
    """يحسب خصم التأخير ومكافأة الأوفر تايم تلقائيًا من أوقات الحضور والانصراف الفعلية
    مقارنة بالشفت المجدول لكل يوم، لمرة واحدة فقط لكل يوم (idempotent)."""
    rows = conn.execute(
        """SELECT a.id AS att_id, a.date, a.check_in, a.check_out, e.base_salary,
                  st.start_time AS shift_start, st.end_time AS shift_end
           FROM attendance a
           JOIN employees e ON e.id = a.employee_id
           LEFT JOIN shifts sh ON sh.employee_id = a.employee_id AND sh.date = a.date
           LEFT JOIN shift_types st ON st.id = sh.shift_type_id
           WHERE a.employee_id=? AND a.date BETWEEN ? AND ? AND a.status='present'
                 AND st.id IS NOT NULL AND st.is_off = 0""",
        (employee_id, p_start.isoformat(), p_end.isoformat()),
    ).fetchall()

    for r in rows:
        already = conn.execute(
            "SELECT source_type FROM payroll_adjustments WHERE source_type IN ('late','overtime') AND source_id=?",
            (r["att_id"],),
        ).fetchall()
        done_types = {x["source_type"] for x in already}

        if r["check_in"] and "late" not in done_types:
            late_min = db.minutes_late(r["check_in"], r["shift_start"])
            if late_min >= LATE_DEDUCTION_THRESHOLD_MIN:
                amount = round(db.daily_rate(r["base_salary"]) * LATE_DEDUCTION_DAYS, 2)
                conn.execute(
                    """INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note, source_type, source_id)
                       VALUES (?, ?, 'deduction', ?, ?, 'late', ?)""",
                    (employee_id, label, amount, f"خصم تأخير {late_min} دقيقة يوم {r['date']}", r["att_id"]),
                )

        if r["check_out"] and "overtime" not in done_types:
            ot_min = db.minutes_overtime(r["check_out"], r["shift_start"], r["shift_end"])
            if ot_min >= OVERTIME_MIN_THRESHOLD:
                ot_hours = round(ot_min / 60, 2)
                amount = round(db.hourly_rate(r["base_salary"]) * ot_hours * OVERTIME_RATE_MULTIPLIER, 2)
                conn.execute(
                    """INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note, source_type, source_id)
                       VALUES (?, ?, 'bonus', ?, ?, 'overtime', ?)""",
                    (employee_id, label, amount, f"أوفر تايم {ot_hours} ساعة يوم {r['date']}", r["att_id"]),
                )
    conn.commit()


# ---------------------------------------------------------------- الشفتات --
MIN_REST_HOURS = 8
WEEKDAYS_AR = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"]


def week_start(d):
    """بداية الأسبوع (السبت) للتاريخ المعطى."""
    if isinstance(d, str):
        d = date.fromisoformat(clean_date(d))
    return d - timedelta(days=(d.weekday() + 2) % 7)


def _h12(t):
    hh, mm = map(int, t.split(":"))
    hh = hh % 12 or 12
    return f"{hh}.{mm:02d}" if mm else str(hh)


def shift_code(st):
    """الرمز المختصر للشفت في الجدول: أوف / رمز مخصص / بداية:نهاية بنظام 12 ساعة (مثال 13:00→03:00 = 1:3)."""
    if st is None:
        return ""
    if st["is_off"]:
        return "off"
    if st["code"]:
        return st["code"]
    return f"{_h12(st['start_time'])}:{_h12(st['end_time'])}"


app.jinja_env.globals["shift_code"] = shift_code


def _shift_interval(day_iso, start_time, end_time):
    base = datetime.combine(date.fromisoformat(day_iso), datetime.min.time())
    ss = db._time_to_minutes(start_time)
    se = db._time_to_minutes(end_time)
    if se <= ss:
        se += 24 * 60
    return base + timedelta(minutes=ss), base + timedelta(minutes=se)


def rest_gap_warnings(target_date, this_type, prev_type, next_type):
    """تنبيهات الراحة الفعلية (أقل من 8 ساعات) بين شفت اليوم وشفت اليوم اللي قبله/بعده."""
    out = []
    if not this_type or this_type["is_off"]:
        return out
    s0, e0 = _shift_interval(target_date, this_type["start_time"], this_type["end_time"])
    d = date.fromisoformat(target_date)
    if prev_type and not prev_type["is_off"]:
        _, pe = _shift_interval((d - timedelta(days=1)).isoformat(), prev_type["start_time"], prev_type["end_time"])
        gap = (s0 - pe).total_seconds() / 3600
        if gap < MIN_REST_HOURS:
            out.append(f"راحة {max(gap, 0):.1f} ساعة فقط بعد شفت اليوم السابق")
    if next_type and not next_type["is_off"]:
        ns, _ = _shift_interval((d + timedelta(days=1)).isoformat(), next_type["start_time"], next_type["end_time"])
        gap = (ns - e0).total_seconds() / 3600
        if gap < MIN_REST_HOURS:
            out.append(f"راحة {max(gap, 0):.1f} ساعة فقط قبل شفت اليوم التالي")
    return out


def shift_conflicts(conn, employee_id, target_date, shift_type_id=None):
    """تنبيهات ذكية عند جدولة شفت: راحة أقل من 8 ساعات فعليًا، أو إجازة معتمدة في نفس اليوم."""
    warnings = []
    d = date.fromisoformat(target_date)
    this_type = conn.execute("SELECT * FROM shift_types WHERE id=?", (shift_type_id,)).fetchone() if shift_type_id else None

    def type_on(day):
        return conn.execute(
            """SELECT st.* FROM shifts sh JOIN shift_types st ON st.id = sh.shift_type_id
               WHERE sh.employee_id=? AND sh.date=?""", (employee_id, day.isoformat())).fetchone()

    if this_type and not this_type["is_off"]:
        warnings += rest_gap_warnings(target_date, this_type, type_on(d - timedelta(days=1)), type_on(d + timedelta(days=1)))
        leave = conn.execute(
            """SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved'
               AND ? BETWEEN start_date AND end_date""", (employee_id, target_date)).fetchone()
        if leave:
            warnings.append("الموظف عنده إجازة معتمدة في اليوم ده")
    return warnings


def get_setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def set_setting(conn, key, value):
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value))


@app.route("/shifts", methods=["GET", "POST"])
@permission_required("manage_shifts")
def shifts_page():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    sel_date = clean_date(request.values.get("date"))
    sel_branch = request.values.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)

    if request.method == "POST":
        warnings_all = []
        for key, value in request.form.items():
            if key.startswith("shift_") and not value:
                conn.execute("DELETE FROM shifts WHERE employee_id=? AND date=?", (int(key.replace("shift_", "")), sel_date))
                continue
            if key.startswith("shift_") and value:
                emp_id = int(key.replace("shift_", ""))
                ename = conn.execute("SELECT name FROM employees WHERE id=?", (emp_id,)).fetchone()
                warnings_all += [f"{ename['name'] if ename else emp_id}: {w}"
                                 for w in shift_conflicts(conn, emp_id, sel_date, int(value))]
                conn.execute(
                    """INSERT INTO shifts (employee_id, shift_type_id, date) VALUES (?, ?, ?)
                       ON CONFLICT(employee_id, date) DO UPDATE SET shift_type_id=excluded.shift_type_id""",
                    (emp_id, int(value), sel_date),
                )
        conn.commit()
        if warnings_all:
            flash("تم الحفظ، لكن في تنبيهات: " + " | ".join(warnings_all), "error")
        else:
            flash("تم حفظ جدول الشفتات ليوم " + sel_date, "ok")
        return redirect(url_for("shifts_page", date=sel_date, branch_id=sel_branch))

    placeholders = ",".join("?" * len(branch_ids))
    branch_rows = conn.execute(f"SELECT * FROM branches WHERE id IN ({placeholders})", branch_ids).fetchall()
    shift_types_raw = conn.execute("SELECT * FROM shift_types ORDER BY id").fetchall()
    shift_types_ = []
    for st in shift_types_raw:
        ss = db._time_to_minutes(st["start_time"])
        se = db._time_to_minutes(st["end_time"])
        if se <= ss:
            se += 24 * 60
        hours = 0 if st["is_off"] else round((se - ss) / 60, 1)
        shift_types_.append({**dict(st), "hours": hours, "display_code": shift_code(st)})

    d_sql, d_params = dept_clause(u, "e")
    emp_rows = []
    if sel_branch:
        emp_rows = conn.execute(
            f"""SELECT e.*, sh.shift_type_id AS assigned_shift FROM employees e
                LEFT JOIN shifts sh ON sh.employee_id = e.id AND sh.date = ?
                WHERE e.branch_id = ? AND e.status='active'{d_sql}
                ORDER BY e.name""",
            [sel_date, sel_branch] + d_params,
        ).fetchall()

    return render_template(
        "shifts.html", branches=branch_rows, shift_types=shift_types_,
        employees=emp_rows, sel_date=sel_date, sel_branch=sel_branch,
    )



# ------------------------------------------------------- الجدول الأسبوعي --
JOB_PALETTE = [  # (لون الخلفية، لون الخط) — تلوين خلايا المسمى الوظيفي زي الجدول الورقي
    ("#FDE3A7", "#5c3b00"), ("#CDE8C4", "#1f4d14"), ("#C7D5F2", "#1a2f6b"), ("#FFC24D", "#4a2f00"),
    ("#F7F27E", "#4d4a00"), ("#8FD07F", "#123d0a"), ("#E8CDF3", "#4a1a6b"), ("#F6BDB6", "#6b1a12"),
    ("#A7E8DE", "#0a4a40"), ("#D6C7F2", "#2e1a6b"), ("#F2C7DE", "#6b1a45"), ("#C7F2D9", "#0a5c2a"),
    ("#F2E0C7", "#6b4a1a"), ("#C7E0F2", "#1a4a6b"), ("#E0F2C7", "#4a5c1a"), ("#F2C7C7", "#6b1a1a"),
    ("#0B1F5C", "#ffffff"),
]
SHIFT_TINTS = [
    "#2f4a7a", "#2f6a55", "#6a4a2f", "#5b3a7a", "#2f6a72", "#7a3a52", "#55622f", "#3a5a8a",
    "#7a5a2f", "#2f7a4a", "#6a2f5e", "#2f5e7a", "#7a2f2f", "#4a7a2f", "#5e2f7a", "#2f7a7a",
]
DEFAULT_WEEK_NOTE = "لا يجوز نهائياً الغياب بدون اذن في ايام الويك اند ولا يجوز التأخر الا عند وجود عذر قهري او الاستئذان من المدير المسؤل"


def _week_employees(conn, u, sel_branch, dept_filter, sort):
    if not sel_branch:
        return []
    d_sql, d_params = dept_clause(u, "e")
    q = "SELECT e.* FROM employees e WHERE e.branch_id = ? AND e.status='active'" + d_sql
    params = [sel_branch] + d_params
    if dept_filter:
        q += " AND e.department = ?"
        params.append(dept_filter)
    order = {
        "name": "e.name",
        "fp": "CAST(e.fingerprint_no AS INTEGER), e.name",
        "dept": "e.department, e.job_title, e.name",
    }.get(sort, "(e.sort_order IS NULL), e.sort_order, e.department, e.job_title, e.name")
    return conn.execute(q + " ORDER BY " + order, params).fetchall()


def _week_params(u, branch_ids):
    sel_branch = request.values.get("branch_id")
    sel_branch = int(sel_branch) if sel_branch else (branch_ids[0] if branch_ids else None)
    ws = week_start(request.values.get("week") or date.today())
    dept_filter = u["department"] or request.values.get("department") or None
    sort = request.values.get("sort", "custom")
    return sel_branch, ws, [ws + timedelta(days=i) for i in range(7)], dept_filter, sort


def _week_cells(conn, emp_ids, day_from, day_to):
    if not emp_ids:
        return {}
    ph = ",".join("?" * len(emp_ids))
    rows = conn.execute(
        f"""SELECT sh.employee_id, sh.date, st.* , st.id AS type_id
            FROM shifts sh JOIN shift_types st ON st.id = sh.shift_type_id
            WHERE sh.employee_id IN ({ph}) AND sh.date BETWEEN ? AND ?""",
        list(emp_ids) + [day_from.isoformat(), day_to.isoformat()],
    ).fetchall()
    return {(r["employee_id"], r["date"]): r for r in rows}


def _upsert_shift(conn, emp_id, day_iso, type_id):
    conn.execute(
        """INSERT INTO shifts (employee_id, shift_type_id, date) VALUES (?, ?, ?)
           ON CONFLICT(employee_id, date) DO UPDATE SET shift_type_id=excluded.shift_type_id""",
        (emp_id, type_id, day_iso))


@app.route("/shifts/week", methods=["GET", "POST"])
@permission_required("manage_shifts")
def shifts_week():
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_branch, ws, days, dept_filter, sort = _week_params(u, branch_ids)
    employees_ = _week_employees(conn, u, sel_branch, dept_filter, sort)
    types_ = conn.execute("SELECT * FROM shift_types ORDER BY is_off, id").fetchall()
    valid_ids = {t["id"] for t in types_}
    off_type = next((t for t in types_ if t["is_off"]), None)
    emp_ids = [e["id"] for e in employees_]

    if request.method == "POST":
        action = request.form.get("action", "save")
        before = _week_cells(conn, emp_ids, days[0], days[-1])
        changed = []
        for e in employees_:
            okey = f"o_{e['id']}"
            if okey in request.form:                      # ترتيب الموظف في الجداول (رقم أو فاضي)
                raw_o = request.form.get(okey, "").strip()
                new_o = int(raw_o) if raw_o.lstrip("-").isdigit() else None
                if new_o != e["sort_order"]:
                    conn.execute("UPDATE employees SET sort_order=? WHERE id=?", (new_o, e["id"]))
        for e in employees_:
            for d in days:
                key = f"c_{e['id']}_{d.isoformat()}"
                if key not in request.form:
                    continue
                raw = request.form.get(key, "")
                new = int(raw) if raw.strip() else None
                if new is not None and new not in valid_ids:
                    continue
                old_row = before.get((e["id"], d.isoformat()))
                old = old_row["type_id"] if old_row else None
                if new == old:
                    continue
                if new is None:
                    conn.execute("DELETE FROM shifts WHERE employee_id=? AND date=?", (e["id"], d.isoformat()))
                else:
                    _upsert_shift(conn, e["id"], d.isoformat(), new)
                    changed.append((e["id"], d.isoformat(), new))

        extra = ""
        after = _week_cells(conn, emp_ids, days[0], days[-1])
        if action == "copy_prev" and emp_ids:
            prev = _week_cells(conn, emp_ids, days[0] - timedelta(days=7), days[-1] - timedelta(days=7))
            n = 0
            for e in employees_:
                for d in days:
                    if (e["id"], d.isoformat()) in after:
                        continue
                    src = prev.get((e["id"], (d - timedelta(days=7)).isoformat()))
                    if src:
                        _upsert_shift(conn, e["id"], d.isoformat(), src["type_id"])
                        changed.append((e["id"], d.isoformat(), src["type_id"]))
                        n += 1
            extra = f" — اتنسخ {n} خانة فاضية من الأسبوع السابق"
        elif action == "fill_off" and off_type:
            n = 0
            for e in employees_:
                wd = e["weekly_day_off"]
                if wd in WEEKDAYS_AR:
                    d = days[WEEKDAYS_AR.index(wd)]
                    if (e["id"], d.isoformat()) not in after:
                        _upsert_shift(conn, e["id"], d.isoformat(), off_type["id"])
                        n += 1
            extra = f" — اتحطّ أوف لـ {n} موظف حسب يوم إجازتهم الأسبوعي المسجّل"
        elif action == "clear" and emp_ids:
            ph = ",".join("?" * len(emp_ids))
            conn.execute(f"DELETE FROM shifts WHERE employee_id IN ({ph}) AND date BETWEEN ? AND ?",
                         emp_ids + [days[0].isoformat(), days[-1].isoformat()])
            extra = " — اتفرّغ الأسبوع كله"
            changed = []
        db.log_action(conn, u, "حفظ الجدول الأسبوعي", "shifts", sel_branch,
                      f"أسبوع {ws.isoformat()} — {len(changed)} تغيير{extra}")
        conn.commit()

        warns = []
        names = {e["id"]: e["name"] for e in employees_}
        for emp_id, day_iso, type_id in changed:
            for w in shift_conflicts(conn, emp_id, day_iso, type_id):
                warns.append(f"{names.get(emp_id, emp_id)} ({day_iso[5:]}): {w}")
        msg = f"تم حفظ الجدول الأسبوعي{extra}"
        if warns:
            shown = " | ".join(warns[:6]) + (f" | و{len(warns) - 6} تنبيه آخر" if len(warns) > 6 else "")
            flash(f"{msg}. تنبيهات: {shown}", "error")
        else:
            flash(msg, "ok")
        return redirect(url_for("shifts_week", branch_id=sel_branch, week=ws.isoformat(),
                                department=request.values.get("department", ""), sort=sort))

    cells = _week_cells(conn, emp_ids, days[0], days[-1])
    types_view = []
    tint_i = 0
    for t in types_:
        d = dict(t)
        d["display_code"] = shift_code(t)
        if t["is_off"]:
            d["color"] = "#0B1F5C"
        else:
            d["color"] = SHIFT_TINTS[tint_i % len(SHIFT_TINTS)]
            tint_i += 1
        ss, se = db._time_to_minutes(t["start_time"]), db._time_to_minutes(t["end_time"])
        d["hours"] = 0 if t["is_off"] else round(((se + 1440 if se <= ss else se) - ss) / 60, 1)
        types_view.append(d)
    type_by_id = {t["id"]: t for t in types_view}
    cell_map = {f"{k[0]}|{k[1]}": v["type_id"] for k, v in cells.items()}
    branch_rows = conn.execute(
        f"SELECT * FROM branches WHERE id IN ({','.join('?' * len(branch_ids))})", branch_ids).fetchall() if branch_ids else []
    return render_template(
        "shifts_week.html", employees=employees_, days=days, ws=ws, cell_map=cell_map, types=types_view,
        type_by_id=type_by_id, branches=branch_rows, sel_branch=sel_branch, dept_filter=dept_filter or "",
        sort=sort, weekdays=WEEKDAYS_AR, prev_week=(ws - timedelta(days=7)).isoformat(),
        next_week=(ws + timedelta(days=7)).isoformat(), today=date.today().isoformat(),
        dept_locked=bool(u["department"]),
    )


@app.route("/shifts/week/print")
@permission_required("manage_shifts")
def shifts_week_print():
    u = current_user()
    conn = get_conn()
    branch_ids = accessible_branch_ids(u)
    sel_branch, ws, days, dept_filter, sort = _week_params(u, branch_ids)
    employees_ = _week_employees(conn, u, sel_branch, dept_filter, sort)
    cells = _week_cells(conn, [e["id"] for e in employees_], days[0], days[-1])
    branch = conn.execute("SELECT * FROM branches WHERE id=?", (sel_branch,)).fetchone() if sel_branch else None

    rows = []
    off_counts = [0] * 7
    work_counts = [0] * 7
    for e in employees_:
        title = (e["job_title"] or e["department"] or "").strip()
        pal = zlib.crc32(title.encode("utf-8")) % (len(JOB_PALETTE) - 1)
        bg, fg = JOB_PALETTE[pal]
        line = []
        for i, d in enumerate(days):
            c = cells.get((e["id"], d.isoformat()))
            if not c:
                line.append({"text": "-", "kind": "none"})
            elif c["is_off"]:
                line.append({"text": "off", "kind": "off"})
                off_counts[i] += 1
            else:
                line.append({"text": shift_code(c), "kind": "work", "name": c["name"]})
                work_counts[i] += 1
        rows.append({"emp": e, "title": title, "bg": bg, "fg": fg, "pal": pal, "cells": line})

    today = date.today()
    return render_template(
        "shifts_week_print.html", rows=rows, days=days, ws=ws, weekdays=WEEKDAYS_AR, branch=branch,
        off_counts=off_counts, work_counts=work_counts, sel_branch=sel_branch, dept_filter=dept_filter or "",
        sort=sort, branches=[b for b in conn.execute("SELECT * FROM branches").fetchall() if b["id"] in branch_ids],
        palette=JOB_PALETTE, today_name=WEEKDAYS_AR[(today.weekday() + 2) % 7],
        today_txt=f"{today.day} / {today.month} / {today.year}",
        note=get_setting(conn, "weekly_note", DEFAULT_WEEK_NOTE),
        header1=get_setting(conn, "weekly_header1", "الشيف ابراهيم الليثي"),
        header2=get_setting(conn, "weekly_header2", ""),
        title=get_setting(conn, "weekly_title", "جدول أجازات"),
    )


@app.route("/shifts/week/settings", methods=["POST"])
@permission_required("manage_shifts")
def shifts_week_settings():
    conn = get_conn()
    for form_key, setting_key in (("note", "weekly_note"), ("header1", "weekly_header1"),
                                  ("header2", "weekly_header2"), ("title", "weekly_title")):
        if form_key in request.form:
            set_setting(conn, setting_key, request.form.get(form_key, "").strip()[:400])
    conn.commit()
    return {"ok": True}


@app.route("/shifts/types/add", methods=["POST"])
@permission_required("manage_shifts")
def add_shift_type():
    conn = get_conn()
    name = request.form.get("name", "").strip()
    start_time = request.form.get("start_time", "").strip()
    end_time = request.form.get("end_time", "").strip()
    code = request.form.get("code", "").strip()[:10] or None
    if name and start_time and end_time:
        try:
            conn.execute(
                "INSERT INTO shift_types (name, start_time, end_time, code) VALUES (?, ?, ?, ?)",
                (name, start_time, end_time, code),
            )
            conn.commit()
            new_code = shift_code({"is_off": 0, "code": code, "start_time": start_time, "end_time": end_time})
            dup = [r["name"] for r in conn.execute(
                "SELECT * FROM shift_types WHERE is_off=0 AND name != ?", (name,)).fetchall()
                if shift_code(r) == new_code]
            if dup:
                flash(f"تمت إضافة الشفت، لكن رمزه ({new_code}) نفس رمز «{dup[0]}» — اكتب رمز مختصر مختلف عشان الجدول ما يتلخبطش.", "error")
            else:
                flash("تمت إضافة نوع الشفت", "ok")
        except Exception:
            flash("نوع الشفت ده موجود بالفعل", "error")
    return redirect(url_for("shifts_page"))


@app.route("/shifts/types/<int:st_id>/edit", methods=["POST"])
@permission_required("manage_shifts")
def edit_shift_type(st_id):
    conn = get_conn()
    name = request.form.get("name", "").strip()
    start_time = request.form.get("start_time", "").strip()
    end_time = request.form.get("end_time", "").strip()
    code = request.form.get("code", "").strip()[:10] or None
    st_row = conn.execute("SELECT is_off FROM shift_types WHERE id=?", (st_id,)).fetchone()
    if not st_row:
        flash("نوع الشفت غير موجود", "error")
        return redirect(url_for("shifts_page"))
    if st_row["is_off"]:
        flash("نوع «أوف» أساسي في النظام ومينفعش يتعدّل", "error")
        return redirect(url_for("shifts_page"))
    if name and start_time and end_time:
        try:
            conn.execute(
                "UPDATE shift_types SET name=?, start_time=?, end_time=?, code=? WHERE id=?",
                (name, start_time, end_time, code, st_id),
            )
            conn.commit()
            flash("تم تحديث نوع الشفت", "ok")
        except Exception:
            flash("فيه نوع شفت تاني بنفس الاسم", "error")
    return redirect(url_for("shifts_page"))


@app.route("/shifts/types/<int:st_id>/delete", methods=["POST"])
@permission_required("manage_shifts")
def delete_shift_type(st_id):
    conn = get_conn()
    st_row = conn.execute("SELECT is_off FROM shift_types WHERE id=?", (st_id,)).fetchone()
    if not st_row or st_row["is_off"]:
        flash("نوع «أوف» أساسي في النظام ومينفعش يتحذف" if st_row else "نوع الشفت غير موجود", "error")
        return redirect(url_for("shifts_page"))
    in_use = conn.execute("SELECT COUNT(*) c FROM shifts WHERE shift_type_id=?", (st_id,)).fetchone()["c"]
    if in_use:
        flash(f"مينفعش تحذف الشفت ده — مستخدم في {in_use} جدول حضور بالفعل", "error")
    else:
        conn.execute("DELETE FROM shift_types WHERE id=?", (st_id,))
        conn.commit()
        flash("تم حذف نوع الشفت", "ok")
    return redirect(url_for("shifts_page"))


@app.route("/shifts/swap/request", methods=["POST"])
@permission_required("manage_shifts")
def request_shift_swap():
    conn = get_conn()
    u = current_user()
    shift_id = int(request.form["shift_id"])
    to_employee_id = int(request.form["to_employee_id"])
    sh = conn.execute("SELECT * FROM shifts WHERE id=?", (shift_id,)).fetchone()
    if not sh:
        flash("الشفت غير موجود", "error")
        return redirect(url_for("shifts_page"))
    conn.execute(
        """INSERT INTO shift_swap_requests (shift_id, from_employee_id, to_employee_id, note, requested_by)
           VALUES (?, ?, ?, ?, ?)""",
        (shift_id, sh["employee_id"], to_employee_id, request.form.get("note", ""), u["id"]),
    )
    conn.commit()
    flash("تم تقديم طلب تبديل الشفت، في انتظار الاعتماد", "ok")
    return redirect(url_for("shift_swaps"))


@app.route("/shifts/swaps")
@permission_required("manage_shifts")
def shift_swaps():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    rows = conn.execute(
        f"""SELECT ssr.*, sh.date AS shift_date, st.name AS shift_name,
                   ef.name AS from_name, et.name AS to_name
            FROM shift_swap_requests ssr
            JOIN shifts sh ON sh.id = ssr.shift_id
            JOIN shift_types st ON st.id = sh.shift_type_id
            JOIN employees ef ON ef.id = ssr.from_employee_id
            JOIN employees et ON et.id = ssr.to_employee_id
            WHERE ef.branch_id IN ({placeholders})
            ORDER BY ssr.created_at DESC LIMIT 100""",
        branch_ids,
    ).fetchall()

    today = date.today().isoformat()
    upcoming_shifts = conn.execute(
        f"""SELECT sh.id, sh.date, e.name AS emp_name, st.name AS shift_name
            FROM shifts sh
            JOIN employees e ON e.id = sh.employee_id
            JOIN shift_types st ON st.id = sh.shift_type_id
            WHERE e.branch_id IN ({placeholders}) AND sh.date >= ? AND st.is_off = 0
            ORDER BY sh.date LIMIT 100""",
        branch_ids + [today],
    ).fetchall()
    employees_ = conn.execute(
        f"SELECT * FROM employees WHERE branch_id IN ({placeholders}) AND status='active' ORDER BY name",
        branch_ids,
    ).fetchall()

    return render_template(
        "shift_swaps.html", rows=rows, upcoming_shifts=upcoming_shifts, employees=employees_
    )


@app.route("/shifts/swap/<int:swap_id>/decide", methods=["POST"])
@permission_required("approve_requests")
def decide_shift_swap(swap_id):
    conn = get_conn()
    u = current_user()
    decision = request.form.get("decision")
    swap = conn.execute("SELECT * FROM shift_swap_requests WHERE id=?", (swap_id,)).fetchone()
    if not swap or swap["status"] != "pending":
        flash("الطلب غير موجود أو تم البت فيه من قبل", "error")
        return redirect(url_for("shift_swaps"))

    if decision == "approved":
        conn.execute("UPDATE shifts SET employee_id=? WHERE id=?", (swap["to_employee_id"], swap["shift_id"]))
        conn.execute(
            "UPDATE shift_swap_requests SET status='approved', decided_by=?, decided_at=datetime('now') WHERE id=?",
            (u["id"], swap_id),
        )
        flash("تم اعتماد تبديل الشفت", "ok")
    else:
        conn.execute(
            "UPDATE shift_swap_requests SET status='rejected', decided_by=?, decided_at=datetime('now') WHERE id=?",
            (u["id"], swap_id),
        )
        flash("تم رفض طلب التبديل", "ok")
    conn.commit()
    return redirect(url_for("shift_swaps"))


@app.route("/shifts/late-report")
@permission_required("manage_shifts")
def late_report():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    label, p_start, p_end = period_context(request.args.get("month"))
    conn = get_conn()
    placeholders = ",".join("?" * len(branch_ids))
    rows = conn.execute(
        f"""SELECT a.date, a.check_in, a.check_out, e.name, e.department,
                   st.start_time AS shift_start, st.end_time AS shift_end
            FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            LEFT JOIN shifts sh ON sh.employee_id=a.employee_id AND sh.date=a.date
            LEFT JOIN shift_types st ON st.id = sh.shift_type_id
            WHERE e.branch_id IN ({placeholders}) AND a.status='present'
                  AND a.date BETWEEN ? AND ? AND a.check_in IS NOT NULL AND st.id IS NOT NULL
                  AND st.is_off = 0
            ORDER BY a.date DESC""",
        branch_ids + [p_start.isoformat(), p_end.isoformat()],
    ).fetchall()

    report_rows = []
    for r in rows:
        late_min = db.minutes_late(r["check_in"], r["shift_start"])
        ot_min = db.minutes_overtime(r["check_out"], r["shift_start"], r["shift_end"]) if r["check_out"] else 0
        if late_min > 0 or ot_min > 0:
            report_rows.append({**dict(r), "late_min": late_min, "ot_min": ot_min})

    return render_template("late_report.html", rows=report_rows, month=label, p_start=p_start, p_end=p_end)


# ---------------------------------------------------------------- الجزاءات --
@app.route("/violations", methods=["GET", "POST"])
@permission_required("manage_penalties")
def violations():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        emp_id = int(request.form["employee_id"])
        vtype_id = int(request.form["violation_type_id"])
        vdate = request.form.get("date") or date.today().isoformat()
        year = date.fromisoformat(vdate).year
        prior = conn.execute(
            """SELECT COUNT(*) c FROM violations WHERE employee_id=? AND violation_type_id=?
               AND substr(date,1,4)=?""",
            (emp_id, vtype_id, str(year)),
        ).fetchone()["c"]
        occurrence_no = prior + 1
        action_label, ded_days = db.escalation_for(occurrence_no)

        cur = conn.execute(
            """INSERT INTO violations (employee_id, violation_type_id, occurrence_no,
               action_taken, deduction_days, date, note, recorded_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (emp_id, vtype_id, occurrence_no, action_label, ded_days, vdate,
             request.form.get("note", ""), u["id"]),
        )
        violation_id = cur.lastrowid

        if ded_days > 0:
            emp = conn.execute("SELECT base_salary FROM employees WHERE id=?", (emp_id,)).fetchone()
            amount = round(db.daily_rate(emp["base_salary"]) * ded_days, 2)
            label = db.current_period_label(MONTH_START_DAY)
            vtype = conn.execute("SELECT name FROM violation_types WHERE id=?", (vtype_id,)).fetchone()
            conn.execute(
                """INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note, source_type, source_id)
                   VALUES (?, ?, 'deduction', ?, ?, 'violation', ?)""",
                (emp_id, label, amount, f"جزاء: {vtype['name']} (المرة {occurrence_no}) - {action_label}", violation_id),
            )
        conn.commit()
        flash(f"تم تسجيل المخالفة — الإجراء: {action_label}", "ok")
        return redirect(url_for("violations"))

    placeholders = ",".join("?" * len(branch_ids))
    rows = conn.execute(
        f"""SELECT v.*, e.name AS emp_name, e.department, vt.name AS type_name
            FROM violations v
            JOIN employees e ON e.id = v.employee_id
            JOIN violation_types vt ON vt.id = v.violation_type_id
            WHERE e.branch_id IN ({placeholders})
            ORDER BY v.created_at DESC LIMIT 200""",
        branch_ids,
    ).fetchall()
    employees_ = conn.execute(
        f"SELECT * FROM employees WHERE branch_id IN ({placeholders}) AND status='active' ORDER BY name",
        branch_ids,
    ).fetchall()
    violation_types_ = conn.execute("SELECT * FROM violation_types ORDER BY id").fetchall()
    return render_template(
        "violations.html", rows=rows, employees=employees_, violation_types=violation_types_
    )


@app.route("/violations/types/add", methods=["POST"])
@permission_required("manage_penalties")
def add_violation_type():
    conn = get_conn()
    name = request.form.get("name", "").strip()
    if name:
        try:
            conn.execute("INSERT INTO violation_types (name) VALUES (?)", (name,))
            conn.commit()
            flash("تمت إضافة نوع المخالفة", "ok")
        except Exception:
            flash("نوع المخالفة ده موجود بالفعل", "error")
    return redirect(url_for("violations"))


@app.route("/violations/types/<int:vt_id>/edit", methods=["POST"])
@permission_required("manage_penalties")
def edit_violation_type(vt_id):
    conn = get_conn()
    name = request.form.get("name", "").strip()
    if name:
        try:
            conn.execute("UPDATE violation_types SET name=? WHERE id=?", (name, vt_id))
            conn.commit()
            flash("تم تحديث نوع المخالفة", "ok")
        except Exception:
            flash("فيه نوع مخالفة تاني بنفس الاسم", "error")
    return redirect(url_for("violations"))


# ---------------------------------------------------------------- التقييم --
EVAL_CRITERIA = [
    ("speed_score", "سرعة التحضير"),
    ("cleanliness_score", "النظافة"),
    ("quality_score", "الجودة"),
    ("punctuality_score", "الانضباط بالمواعيد"),
]


@app.route("/evaluations", methods=["GET", "POST"])
@permission_required("manage_evaluations")
def evaluations():
    u = current_user()
    branch_ids = accessible_branch_ids(u)
    conn = get_conn()

    if request.method == "POST":
        emp_id = int(request.form["employee_id"])
        period = request.form["period"]
        scores = {}
        for key, _ in EVAL_CRITERIA:
            scores[key] = int(request.form.get(key) or 0)
        overall = round(sum(scores.values()) / len(EVAL_CRITERIA), 2)
        bonus_percent = float(request.form.get("bonus_percent") or 0)

        cur = conn.execute(
            """INSERT INTO evaluations (employee_id, period, speed_score, cleanliness_score,
               quality_score, punctuality_score, overall_score, bonus_percent, note, evaluated_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (emp_id, period, scores["speed_score"], scores["cleanliness_score"],
             scores["quality_score"], scores["punctuality_score"], overall,
             bonus_percent, request.form.get("note", ""), u["id"]),
        )
        eval_id = cur.lastrowid

        if bonus_percent > 0:
            emp = conn.execute("SELECT base_salary FROM employees WHERE id=?", (emp_id,)).fetchone()
            amount = round(emp["base_salary"] * bonus_percent / 100, 2)
            conn.execute(
                """INSERT INTO payroll_adjustments (employee_id, month, kind, amount, note, source_type, source_id)
                   VALUES (?, ?, 'bonus', ?, ?, 'evaluation', ?)""",
                (emp_id, period, amount, f"مكافأة تقييم أداء ({bonus_percent}%)", eval_id),
            )
        db.log_action(conn, u, "تسجيل تقييم أداء", "employee", emp_id, f"الفترة {period} — {overall}/10")
        conn.commit()
        flash("تم حفظ التقييم", "ok")
        return redirect(url_for("evaluations"))

    placeholders = ",".join("?" * len(branch_ids))
    employees_ = conn.execute(
        f"SELECT * FROM employees WHERE branch_id IN ({placeholders}) AND status='active' ORDER BY name",
        branch_ids,
    ).fetchall()
    rows = conn.execute(
        f"""SELECT ev.*, e.name AS emp_name, e.department FROM evaluations ev
            JOIN employees e ON e.id = ev.employee_id
            WHERE e.branch_id IN ({placeholders})
            ORDER BY ev.created_at DESC LIMIT 100""",
        branch_ids,
    ).fetchall()
    return render_template(
        "evaluations.html", employees=employees_, rows=rows, criteria=EVAL_CRITERIA,
        default_period=db.current_period_label(MONTH_START_DAY),
    )


# -------------------------------------------------------------------- Users --
@app.route("/users", methods=["GET", "POST"])
@permission_required("manage_users")
def users():
    conn = get_conn()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        full_name = request.form.get("full_name", "").strip()
        role_id = request.form.get("role_id")
        branch_id = request.form.get("branch_id") or None
        department = request.form.get("department") or None
        if not username or not full_name or len(password) < 6:
            flash("اكتب اسم المستخدم والاسم الكامل وكلمة مرور 6 حروف على الأقل", "error")
            return redirect(url_for("users"))
        try:
            conn.execute(
                """INSERT INTO users (username, password_hash, full_name, role_id, branch_id, department, must_change_password)
                   VALUES (?, ?, ?, ?, ?, ?, 1)""",
                (username, generate_password_hash(password), full_name, role_id, branch_id, department),
            )
            db.log_action(conn, current_user(), "إضافة مستخدم", "user", None, username)
            conn.commit()
            flash("تمت إضافة المستخدم", "ok")
        except Exception:
            flash("اسم المستخدم موجود بالفعل", "error")
        return redirect(url_for("users"))

    rows = conn.execute(
        """SELECT u.*, b.name AS branch_name, r.name AS role_name FROM users u
           LEFT JOIN branches b ON b.id = u.branch_id
           JOIN roles r ON r.id = u.role_id
           ORDER BY u.id"""
    ).fetchall()
    branch_rows = conn.execute("SELECT * FROM branches").fetchall()
    role_rows = conn.execute("SELECT * FROM roles ORDER BY id").fetchall()
    return render_template("users.html", users=rows, branches=branch_rows, roles=role_rows)


@app.route("/users/<int:user_id>/delete", methods=["POST"])
@permission_required("manage_users")
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("لا يمكنك حذف نفسك", "error")
        return redirect(url_for("users"))
    conn = get_conn()
    urow = conn.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
    if conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"] <= 1:
        flash("مينفعش تحذف آخر مستخدم في النظام", "error")
        return redirect(url_for("users"))
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    if urow:
        db.log_action(conn, current_user(), "حذف مستخدم", "user", user_id, urow["username"])
    conn.commit()
    flash("تم حذف المستخدم", "ok")
    return redirect(url_for("users"))


@app.route("/users/<int:user_id>/edit", methods=["POST"])
@permission_required("manage_users")
def edit_user(user_id):
    conn = get_conn()
    full_name = request.form.get("full_name", "").strip()
    role_id = request.form.get("role_id")
    branch_id = request.form.get("branch_id") or None
    department = request.form.get("department") or None
    new_password = request.form.get("password", "").strip()

    if full_name and role_id:
        conn.execute(
            "UPDATE users SET full_name=?, role_id=?, branch_id=?, department=? WHERE id=?",
            (full_name, role_id, branch_id, department, user_id),
        )
        if new_password:
            if len(new_password) < 6:
                flash("كلمة المرور الجديدة لازم تكون 6 حروف على الأقل (باقي البيانات اتحفظت)", "error")
            else:
                conn.execute(
                    "UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?",
                    (generate_password_hash(new_password), user_id),
                )
        db.log_action(conn, current_user(), "تعديل مستخدم", "user", user_id, full_name)
        conn.commit()
        flash("تم تحديث بيانات المستخدم", "ok")
    return redirect(url_for("users"))



# -------------------------------------------------------------------- Roles --
@app.route("/roles")
@permission_required("manage_users")
def roles_page():
    conn = get_conn()
    role_rows = conn.execute("SELECT * FROM roles ORDER BY id").fetchall()
    return render_template("roles.html", roles=role_rows)


@app.route("/roles/<int:role_id>/update", methods=["POST"])
@permission_required("manage_users")
def update_role(role_id):
    conn = get_conn()
    selected = request.form.getlist("perm")
    valid = [p for p in selected if p in PERMISSIONS]
    role = conn.execute("SELECT name FROM roles WHERE id=?", (role_id,)).fetchone()
    conn.execute(
        "UPDATE roles SET permissions=? WHERE id=?", (",".join(valid), role_id)
    )
    db.log_action(get_conn(), current_user(), "تعديل صلاحيات دور", "role", role_id,
                  f"{role['name']}: {', '.join(valid)}")
    conn.commit()
    flash("تم تحديث صلاحيات الدور", "ok")
    return redirect(url_for("roles_page"))


# -------------------------------------------------------------- النسخ الاحتياطي --
@app.route("/backups", methods=["GET", "POST"])
@permission_required("manage_backups")
def backups_page():
    u = current_user()
    if request.method == "POST":
        full = request.form.get("kind") == "full"
        try:
            fname = db.backup_full() if full else db.backup_now()
        except Exception as ex:
            flash(f"تعذّر عمل النسخة الاحتياطية: {ex}", "error")
            return redirect(url_for("backups_page"))
        db.log_action(get_conn(), u, "نسخة احتياطية كاملة" if full else "نسخة احتياطية يدوية", "system", None, fname)
        get_conn().commit()
        flash("تم عمل نسخة احتياطية جديدة", "ok")
        return redirect(url_for("backups_page"))

    files = db.list_backups()
    return render_template("backups.html", files=files)


@app.route("/backups/download/<path:fname>")
@permission_required("manage_backups")
def download_backup(fname):
    fname = os.path.basename(fname)
    fpath = os.path.join(db.BACKUPS_DIR, fname)
    if not os.path.isfile(fpath) or not fname.endswith((".db", ".zip")) or fname.startswith("_tmp_"):
        flash("الملف غير موجود", "error")
        return redirect(url_for("backups_page"))
    return send_file(fpath, as_attachment=True, download_name=fname)


@app.route("/audit-log")
@permission_required("manage_backups")
def audit_log_page():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300").fetchall()
    return render_template("audit_log.html", rows=rows)


@app.route("/health")
def health():
    """نقطة فحص بسيطة - مفيدة عند النشر على استضافة سحابية للتأكد إن السيرفر شغال."""
    return {"status": "ok"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5050))
    host = os.environ.get("APP_HOST", "0.0.0.0")
    print("=" * 50)
    print(f"التطبيق شغال على: http://localhost:{port}")
    print("لو ده أول تشغيل: المستخدم admin وكلمة المرور المؤقتة مذكورة في ملف اقرأني —")
    print("والنظام هيطلب منك تغييرها فورًا بعد أول دخول.")
    print("=" * 50)
    if not DEBUG_MODE:
        try:                                        # خادم إنتاج أثبت لو waitress متسطّب (اختياري: pip install waitress)
            from waitress import serve
            serve(app, host=host, port=port, threads=8)
            raise SystemExit(0)
        except ImportError:
            pass
    app.run(host=host, port=port, debug=DEBUG_MODE)
