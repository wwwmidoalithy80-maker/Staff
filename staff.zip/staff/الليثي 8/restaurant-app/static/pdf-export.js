/*
 * تصدير PDF حقيقي (تحميل ملف) بدون نافذة طباعة.
 * بياخد صورة "نصية" من الصفحة الحالية (بما فيها أي تعديل عملته) ويبعتها للسيرفر،
 * والسيرفر بيحوّلها PDF بمتصفح Edge/Chrome المثبّت على الجهاز (نص واضح وقابل للتحديد).
 *
 *   PDFExport({ el: عنصر الورقة, filename: 'اسم', orientation: 'landscape'|'portrait', button: زر (اختياري) })
 */
(function(){
  function toDataURL(blob){
    return new Promise(function(res, rej){ var r = new FileReader(); r.onload = function(){ res(r.result); }; r.onerror = rej; r.readAsDataURL(blob); });
  }
  async function inlineImages(root){
    var imgs = Array.from(root.querySelectorAll('img'));
    for (var i = 0; i < imgs.length; i++){
      var im = imgs[i], src = im.getAttribute('src') || '';
      if (!src || src.indexOf('data:') === 0) continue;
      try{
        var resp = await fetch(src, {credentials:'same-origin'});
        if (resp.ok) im.setAttribute('src', await toDataURL(await resp.blob()));
      }catch(e){ im.removeAttribute('src'); }
    }
  }
  function collectCSS(){
    var css = '';
    Array.from(document.styleSheets).forEach(function(sheet){
      try{ Array.from(sheet.cssRules).forEach(function(r){ if (r.type !== 3) css += r.cssText + '\n'; }); }catch(e){}   // نتخطى @import والخارجي
    });
    return css;
  }
  function filenameSafe(n){ return (n || 'report').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80); }

  window.PDFExport = async function(opts){
    var btn = opts.button, oldText = btn ? btn.textContent : '';
    function busy(on, text){ if (!btn) return; btn.disabled = on; btn.textContent = on ? (text || 'جاري تجهيز PDF…') : oldText; }
    busy(true);
    try{
      if (document.fonts && document.fonts.ready) await document.fonts.ready;
      var clone = opts.el.cloneNode(true);
      clone.querySelectorAll('[contenteditable]').forEach(function(n){ n.removeAttribute('contenteditable'); });
      clone.querySelectorAll('.no-print').forEach(function(n){ n.remove(); });
      clone.classList.remove('editing');
      await inlineImages(clone);

      var orient = opts.orientation || 'portrait';
      var html = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">' +
        '<style>' + collectCSS() + '</style>' +
        '<style>@page{size:A4 ' + orient + ';margin:' + (opts.margin || '6mm') + ';}' +
        'html,body{background:#fff !important;margin:0 !important;padding:0 !important;}' +
        '.paper{box-shadow:none !important;margin:0 !important;}' +
        (opts.extraCSS || '') + '</style></head>' +
        '<body class="' + (opts.bodyClass || '') + '">' + clone.outerHTML + '</body></html>';

      var url = '/pdf/export?name=' + encodeURIComponent(filenameSafe(opts.filename)) + '&o=' + encodeURIComponent(orient);
      var resp = await fetch(url, {
        method: 'POST', credentials: 'same-origin',
        headers: {'X-CSRF-Token': window.CSRF_TOKEN || '', 'Content-Type': 'text/html; charset=utf-8'},
        body: html
      });
      if (!resp.ok){
        var err = {}; try{ err = await resp.json(); }catch(e){}
        if (err.error === 'no_browser'){
          if (window.confirm('لازم Microsoft Edge أو Google Chrome يكون مثبّت على الجهاز لتصدير PDF مباشرة.\n\nتحب تفتح نافذة الطباعة وتختار "Save as PDF"؟')) window.print();
        } else {
          alert(err.message || 'تعذّر إنشاء ملف PDF. جرّب الطباعة واختر Save as PDF.');
        }
        return;
      }
      var blob = await resp.blob();
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = filenameSafe(opts.filename) + '.pdf';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function(){ URL.revokeObjectURL(a.href); }, 4000);
    }catch(e){
      alert('حصل خطأ أثناء تجهيز الـ PDF: ' + e);
    }finally{ busy(false); }
  };
})();
