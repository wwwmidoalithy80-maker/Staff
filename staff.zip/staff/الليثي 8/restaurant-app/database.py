"""
طبقة قاعدة البيانات - تطبيق إدارة شركة المطاعم
SQLite محلي، بدون أي اتصال خارجي.
"""
import sqlite3
import os
import shutil
import zipfile
import calendar
from datetime import datetime, date, timedelta
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "app.db")
UPLOADS_DIR = os.path.join(BASE_DIR, "static", "uploads")
DEFAULT_ADMIN_PASSWORD = "admin123"


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 8000")
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    phone TEXT,
    logo_path TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    permissions TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role_id INTEGER NOT NULL REFERENCES roles(id),
    branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,   -- NULL = كل الفروع
    department TEXT,                                                 -- NULL = كل الأقسام
    must_change_password INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS company_housing_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    capacity INTEGER NOT NULL DEFAULT 1,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    fingerprint_no TEXT,
    name TEXT NOT NULL,
    department TEXT NOT NULL DEFAULT 'غير محدد',
    sub_department TEXT,
    job_title TEXT,
    base_salary REAL NOT NULL DEFAULT 0,
    housing_allowance REAL NOT NULL DEFAULT 0,
    transport_allowance REAL NOT NULL DEFAULT 0,
    meal_allowance REAL NOT NULL DEFAULT 0,
    social_insurance REAL NOT NULL DEFAULT 0,
    tax_deduction REAL NOT NULL DEFAULT 0,
    national_id TEXT,
    bank_name TEXT,
    bank_account TEXT,
    start_date TEXT,
    end_date TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
    photo_path TEXT,
    residence TEXT,
    residence_type TEXT NOT NULL DEFAULT 'مقيم' CHECK(residence_type IN ('مقيم','مغترب')),
    weekly_day_off TEXT,
    sort_order INTEGER,                 -- ترتيب الموظف في الجداول المطبوعة (اختياري)
    last_leave_return TEXT,             -- تسجيل يدوي مباشر لآخر رجوع من إجازة
    last_leave_days INTEGER,            -- عدد أيام آخر إجازة (4 متتالية أو أقل)
    phone TEXT,
    relative_name TEXT,
    relative_phone TEXT,
    relative_relation TEXT,
    housing_unit_id INTEGER REFERENCES company_housing_units(id) ON DELETE SET NULL,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS employee_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    doc_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    submitted_date TEXT,
    expiry_date TEXT,
    note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS checklist_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN ('onboarding','offboarding')),
    item TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    done_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    period TEXT NOT NULL,  -- 'YYYY-MM'
    speed_score INTEGER,
    cleanliness_score INTEGER,
    quality_score INTEGER,
    punctuality_score INTEGER,
    overall_score REAL,
    bonus_percent REAL,
    note TEXT,
    evaluated_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    username TEXT,
    action TEXT NOT NULL,
    entity TEXT,
    entity_id INTEGER,
    details TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('present','leave','absence','half_day','mission','start_of_work','resignation','end_of_service')),
    note TEXT,
    check_in TEXT,   -- 'HH:MM' وقت الحضور الفعلي
    check_out TEXT,  -- 'HH:MM' وقت الانصراف الفعلي
    UNIQUE(employee_id, date)
);

CREATE TABLE IF NOT EXISTS shift_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    start_time TEXT NOT NULL,   -- 'HH:MM'
    end_time TEXT NOT NULL,     -- 'HH:MM' (ممكن يكون قبل start_time لو الشفت بيعدّي نص الليل)
    is_off INTEGER NOT NULL DEFAULT 0,   -- 1 = يوم أوف (إجازة أسبوعية) مش شفت عمل
    code TEXT                            -- رمز مختصر للجدول (مثال 1:3) — لو فاضي بيتحسب من الأوقات
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS shifts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    shift_type_id INTEGER NOT NULL REFERENCES shift_types(id),
    date TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(employee_id, date)
);

CREATE TABLE IF NOT EXISTS shift_swap_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shift_id INTEGER NOT NULL REFERENCES shifts(id) ON DELETE CASCADE,
    from_employee_id INTEGER NOT NULL REFERENCES employees(id),
    to_employee_id INTEGER NOT NULL REFERENCES employees(id),
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
    note TEXT,
    requested_by INTEGER REFERENCES users(id),
    decided_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now')),
    decided_at TEXT
);

CREATE TABLE IF NOT EXISTS payroll_adjustments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    month TEXT NOT NULL,  -- 'YYYY-MM'
    kind TEXT NOT NULL CHECK(kind IN ('bonus','deduction')),
    amount REAL NOT NULL,
    note TEXT,
    source_type TEXT,      -- NULL = يدوي، أو 'advance' / 'violation'
    source_id INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS leave_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    annual_quota INTEGER,               -- NULL = غير محدود
    paid INTEGER NOT NULL DEFAULT 1     -- 1 = بأجر، 0 = بدون أجر
);

CREATE TABLE IF NOT EXISTS leave_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    leave_type_id INTEGER NOT NULL REFERENCES leave_types(id),
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    days_count INTEGER NOT NULL,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
    requested_by INTEGER REFERENCES users(id),
    decided_by INTEGER REFERENCES users(id),
    decision_note TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    decided_at TEXT
);

CREATE TABLE IF NOT EXISTS advances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    principal_amount REAL NOT NULL,
    monthly_installment REAL NOT NULL,
    remaining_balance REAL NOT NULL,
    advance_type TEXT NOT NULL DEFAULT 'installment' CHECK(advance_type IN ('installment','monthly_full')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','rejected','closed')),
    note TEXT,
    requested_by INTEGER REFERENCES users(id),
    decided_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now')),
    decided_at TEXT
);

CREATE TABLE IF NOT EXISTS sub_departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_department TEXT NOT NULL,
    name TEXT NOT NULL,
    UNIQUE(parent_department, name)
);

CREATE TABLE IF NOT EXISTS violation_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    violation_type_id INTEGER NOT NULL REFERENCES violation_types(id),
    occurrence_no INTEGER NOT NULL,
    action_taken TEXT NOT NULL,
    deduction_days REAL NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    note TEXT,
    recorded_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);
"""

DEPARTMENTS = ["مطبخ", "صالة", "كاشير", "توصيل", "إدارة"]

ATTENDANCE_STATUS_LABELS = {
    "present": "حضور", "leave": "إجازة", "absence": "غياب",
    "half_day": "نصف يوم", "mission": "مأمورية", "start_of_work": "بداية العمل",
    "resignation": "استقالة", "end_of_service": "نهاية عمل",
}

DOCUMENT_TYPES = [
    "صورة البطاقة", "شهادة ميلاد", "شهادة صحية", "فيش وتشبيه",
    "عقد العمل", "شهادة تأهيل/خبرة", "أخرى",
]

# مفاتيح الصلاحيات المتاحة في النظام
PERMISSIONS = {
    "manage_branches": "إدارة الفروع",
    "manage_users": "إدارة المستخدمين والأدوار",
    "manage_employees": "إضافة / تعديل بيانات الموظفين",
    "manage_documents": "رفع صور ومستندات الموظفين",
    "mark_attendance": "تسجيل الحضور اليومي",
    "edit_attendance_log": "تعديل / حذف سجلات الحضور القديمة",
    "view_payroll": "عرض الرواتب",
    "manage_payroll": "إضافة تسويات على الرواتب (مكافآت / خصومات)",
    "export_reports": "تصدير التقارير (Excel)",
    "submit_requests": "تقديم طلبات إجازة / سلفة نيابة عن الموظف",
    "approve_requests": "اعتماد طلبات الإجازات والسلف",
    "manage_penalties": "تسجيل الجزاءات والإنذارات",
    "manage_shifts": "جدولة الشفتات وتبديلها",
    "manage_evaluations": "تقييم أداء الموظفين",
    "manage_backups": "إدارة النسخ الاحتياطية وسجل العمليات",
}

# الأدوار الافتراضية وصلاحياتها ونطاقها المقترح (branch_scope: all/own، department: None = كل الأقسام)
DEFAULT_ROLES = [
    ("رئيس مجلس الإدارة", list(PERMISSIONS.keys())),
    ("مدير التشغيل", [k for k in PERMISSIONS if k != "manage_users"]),
    ("مدير الفروع", ["manage_branches", "manage_employees", "manage_documents",
                     "mark_attendance", "edit_attendance_log", "view_payroll",
                     "manage_payroll", "export_reports", "submit_requests",
                     "approve_requests", "manage_penalties", "manage_shifts",
                     "manage_evaluations", "manage_backups"]),
    ("مدير الموارد البشرية", ["manage_employees", "manage_documents", "mark_attendance",
                              "edit_attendance_log", "view_payroll", "manage_payroll",
                              "export_reports", "submit_requests", "approve_requests",
                              "manage_penalties", "manage_shifts", "manage_evaluations"]),
    ("مدير الفرع", ["manage_employees", "manage_documents", "mark_attendance",
                    "view_payroll", "export_reports", "submit_requests",
                    "manage_penalties", "manage_shifts", "manage_evaluations"]),
    ("مساعد مدير الفرع", ["mark_attendance", "view_payroll", "submit_requests", "manage_shifts"]),
    ("الشيف العمومي", ["mark_attendance", "view_payroll", "manage_documents",
                       "submit_requests", "manage_shifts", "manage_evaluations"]),
    ("مدير المطبخ", ["mark_attendance", "view_payroll", "submit_requests",
                     "manage_shifts", "manage_evaluations"]),
    ("محاسب", ["manage_employees", "mark_attendance", "view_payroll",
              "manage_payroll", "export_reports"]),
]

# طلبات جديدة أضيفت بعد الإصدار الأول - تُضاف لهذه الأدوار تلقائيًا لو لسه ملهاش صلاحيات
NEW_PERMISSIONS_BY_ROLE = {
    "رئيس مجلس الإدارة": ["submit_requests", "approve_requests", "manage_penalties",
                          "manage_shifts", "manage_evaluations", "manage_backups"],
    "مدير التشغيل": ["submit_requests", "approve_requests", "manage_penalties",
                     "manage_shifts", "manage_evaluations", "manage_backups"],
    "مدير الفروع": ["submit_requests", "approve_requests", "manage_penalties",
                    "manage_shifts", "manage_evaluations", "manage_backups"],
    "مدير الموارد البشرية": ["submit_requests", "approve_requests", "manage_penalties",
                             "manage_shifts", "manage_evaluations"],
    "مدير الفرع": ["submit_requests", "manage_penalties", "manage_shifts", "manage_evaluations"],
    "مساعد مدير الفرع": ["submit_requests", "manage_shifts"],
    "الشيف العمومي": ["submit_requests", "manage_shifts", "manage_evaluations"],
    "مدير المطبخ": ["submit_requests", "manage_shifts", "manage_evaluations"],
}

DEFAULT_ONBOARDING_ITEMS = [
    "استلام العقد الموقّع", "استلام الزي الرسمي", "تقديم الشهادة الصحية",
    "فتح حساب بنكي / تحويل الراتب", "تسليم بطاقة الحضور (البصمة)",
]

DEFAULT_OFFBOARDING_ITEMS = [
    "إخلاء طرف من المطبخ", "إخلاء طرف من المخزن", "إخلاء طرف من الكاشير",
    "إخلاء طرف من الإدارة المالية", "استرداد الزي الرسمي والمعدات",
]

DEFAULT_SHIFT_TYPES = [
    ("صباحي", "08:00", "16:00"),
    ("مسائي", "16:00", "24:00"),
    ("سهر", "20:00", "04:00"),
    ("جزئي", "10:00", "14:00"),
]

DEFAULT_LEAVE_TYPES = [
    ("سنوي", 21, 1),
    ("مرضي", 15, 1),
    ("عارضة", 6, 1),
    ("بدل راحة", None, 1),
    ("بدون راتب", None, 0),
]

DEFAULT_VIOLATION_TYPES = [
    "التأخير", "عدم الالتزام بالزي الرسمي", "النظافة الشخصية",
    "سوء التعامل مع العميل", "أخرى",
]

DEFAULT_KITCHEN_SUB_DEPARTMENTS = ["الشواية", "الأرز والمقبلات", "الحلواني", "الغسيل والتجهيز"]

# تدرج العقوبة حسب عدد مرات تكرار نفس المخالفة خلال السنة
VIOLATION_ESCALATION = [
    (1, "تنبيه شفهي", 0),
    (2, "إنذار كتابي", 0),
    (3, "خصم يوم", 1),
    (4, "خصم يومين", 2),
]


def escalation_for(occurrence_no):
    """يرجع (الوصف، عدد أيام الخصم) حسب عدد مرات تكرار المخالفة."""
    for n, label, days in VIOLATION_ESCALATION:
        if occurrence_no == n:
            return label, days
    return VIOLATION_ESCALATION[-1][1], VIOLATION_ESCALATION[-1][2]


def _migrate(conn):
    """يضيف أي أعمدة/جداول جديدة لقاعدة بيانات قديمة موجودة بالفعل، من غير ما يمسح بيانات."""
    branch_cols = [r["name"] for r in conn.execute("PRAGMA table_info(branches)").fetchall()]
    if "logo_path" not in branch_cols:
        conn.execute("ALTER TABLE branches ADD COLUMN logo_path TEXT")
    conn.commit()

    emp_cols = [r["name"] for r in conn.execute("PRAGMA table_info(employees)").fetchall()]
    if "department" not in emp_cols:
        conn.execute("ALTER TABLE employees ADD COLUMN department TEXT NOT NULL DEFAULT 'غير محدد'")
    if "photo_path" not in emp_cols:
        conn.execute("ALTER TABLE employees ADD COLUMN photo_path TEXT")
    if "residence" not in emp_cols:
        conn.execute("ALTER TABLE employees ADD COLUMN residence TEXT")
    for col, ddl in [
        ("housing_allowance", "REAL NOT NULL DEFAULT 0"),
        ("transport_allowance", "REAL NOT NULL DEFAULT 0"),
        ("meal_allowance", "REAL NOT NULL DEFAULT 0"),
        ("social_insurance", "REAL NOT NULL DEFAULT 0"),
        ("tax_deduction", "REAL NOT NULL DEFAULT 0"),
        ("national_id", "TEXT"),
        ("bank_name", "TEXT"),
        ("bank_account", "TEXT"),
        ("sub_department", "TEXT"),
        ("sort_order", "INTEGER"),
        ("last_leave_return", "TEXT"),   # تسجيل يدوي مباشر لآخر رجوع من إجازة (دورة الإجازات للمغتربين)
        ("last_leave_days", "INTEGER"),  # عدد أيام آخر إجازة أُخذت (4 = دورة متتالية كاملة، أو رقم أقل ليوم/أيام منفردة)
        ("residence_type", "TEXT NOT NULL DEFAULT 'مقيم'"),
        ("weekly_day_off", "TEXT"),
        ("phone", "TEXT"),
        ("relative_name", "TEXT"),
        ("relative_phone", "TEXT"),
        ("relative_relation", "TEXT"),
        ("housing_unit_id", "INTEGER REFERENCES company_housing_units(id)"),
    ]:
        if col not in emp_cols:
            conn.execute(f"ALTER TABLE employees ADD COLUMN {col} {ddl}")
    conn.commit()

    att_cols = [r["name"] for r in conn.execute("PRAGMA table_info(attendance)").fetchall()]
    if "leave_type_id" not in att_cols:
        conn.execute("ALTER TABLE attendance ADD COLUMN leave_type_id INTEGER REFERENCES leave_types(id)")
    if "check_in" not in att_cols:
        conn.execute("ALTER TABLE attendance ADD COLUMN check_in TEXT")
    if "check_out" not in att_cols:
        conn.execute("ALTER TABLE attendance ADD COLUMN check_out TEXT")
    conn.commit()

    _migrate_attendance_statuses(conn)

    adj_cols = [r["name"] for r in conn.execute("PRAGMA table_info(payroll_adjustments)").fetchall()]
    if "source_type" not in adj_cols:
        conn.execute("ALTER TABLE payroll_adjustments ADD COLUMN source_type TEXT")
    if "source_id" not in adj_cols:
        conn.execute("ALTER TABLE payroll_adjustments ADD COLUMN source_id INTEGER")
    conn.commit()

    doc_cols = [r["name"] for r in conn.execute("PRAGMA table_info(employee_documents)").fetchall()]
    if "expiry_date" not in doc_cols:
        conn.execute("ALTER TABLE employee_documents ADD COLUMN expiry_date TEXT")
    conn.commit()

    adv_cols = [r["name"] for r in conn.execute("PRAGMA table_info(advances)").fetchall()]
    if "advance_type" not in adv_cols:
        conn.execute("ALTER TABLE advances ADD COLUMN advance_type TEXT NOT NULL DEFAULT 'installment'")
    conn.commit()

    if conn.execute("SELECT COUNT(*) c FROM sub_departments").fetchone()["c"] == 0:
        for name in DEFAULT_KITCHEN_SUB_DEPARTMENTS:
            conn.execute(
                "INSERT INTO sub_departments (parent_department, name) VALUES ('مطبخ', ?)", (name,)
            )
        conn.commit()

    # لو في موظفين قدامى من غير تشيك ليست توظيف، نعمّلهم واحدة دلوقتي
    if conn.execute("SELECT COUNT(*) c FROM checklist_items").fetchone()["c"] == 0:
        old_employees = conn.execute("SELECT id FROM employees").fetchall()
        for e in old_employees:
            for item in DEFAULT_ONBOARDING_ITEMS:
                conn.execute(
                    "INSERT INTO checklist_items (employee_id, kind, item) VALUES (?, 'onboarding', ?)",
                    (e["id"], item),
                )

    # هل جدول users القديم لسه شغال بالعمود القديم role (بدل role_id)؟ لازم ننقل البيانات.
    user_cols = [r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if user_cols and "role_id" not in user_cols:
        _migrate_users_to_roles(conn, user_cols)
    conn.commit()

    # عمود إجبار تغيير كلمة المرور (للحسابات اللي لسه بالباسورد الافتراضي)
    user_cols = [r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "must_change_password" not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    weak = conn.execute("SELECT id, password_hash FROM users WHERE username='admin'").fetchone()
    if weak and check_password_hash(weak["password_hash"], DEFAULT_ADMIN_PASSWORD):
        conn.execute("UPDATE users SET must_change_password=1 WHERE id=?", (weak["id"],))
        conn.commit()

    _grant_new_permissions(conn)
    _seed_leave_and_violation_types(conn)
    _ensure_shift_type_columns(conn)
    _seed_shift_types(conn)
    conn.commit()


def _create_indexes(conn):
    """فهارس لتسريع التقارير والداشبورد مع زيادة عدد الموظفين وأيام الحضور."""
    stmts = [
        "CREATE INDEX IF NOT EXISTS idx_att_emp_date ON attendance(employee_id, date)",
        "CREATE INDEX IF NOT EXISTS idx_att_date ON attendance(date)",
        "CREATE INDEX IF NOT EXISTS idx_emp_branch_status ON employees(branch_id, status)",
        "CREATE INDEX IF NOT EXISTS idx_adj_emp_month ON payroll_adjustments(employee_id, month)",
        "CREATE INDEX IF NOT EXISTS idx_shifts_emp_date ON shifts(employee_id, date)",
        "CREATE INDEX IF NOT EXISTS idx_viol_emp_date ON violations(employee_id, date)",
        "CREATE INDEX IF NOT EXISTS idx_leave_emp ON leave_requests(employee_id, status)",
        "CREATE INDEX IF NOT EXISTS idx_adv_emp ON advances(employee_id, status)",
        # يمنع استيراد/إضافة نفس الموظف (نفس البصمة) مرتين في نفس الفرع، من غير ما يمنع بصمات فاضية
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_emp_branch_fp ON employees(branch_id, fingerprint_no) "
        "WHERE fingerprint_no IS NOT NULL AND fingerprint_no != ''",
    ]
    for q in stmts:
        try:
            conn.execute(q)
        except sqlite3.Error:
            pass
    conn.commit()


def _migrate_attendance_statuses(conn):
    """يضيف حالتي 'مأمورية' و'بداية العمل' لجدول الحضور لو لسه مش مدعومتين (يعيد بناء الجدول بأمان)."""
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='attendance'"
    ).fetchone()
    if not row or "resignation" in row["sql"]:
        return

    conn.execute("PRAGMA foreign_keys = OFF")
    conn.execute("ALTER TABLE attendance RENAME TO attendance_old_migration")
    conn.execute("""
        CREATE TABLE attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('present','leave','absence','half_day','mission','start_of_work','resignation','end_of_service')),
            note TEXT,
            check_in TEXT,
            check_out TEXT,
            leave_type_id INTEGER REFERENCES leave_types(id),
            UNIQUE(employee_id, date)
        )
    """)
    conn.execute("""
        INSERT INTO attendance (id, employee_id, date, status, note, check_in, check_out, leave_type_id)
        SELECT id, employee_id, date, status, note, check_in, check_out, leave_type_id
        FROM attendance_old_migration
    """)
    conn.execute("DROP TABLE attendance_old_migration")
    conn.commit()
    conn.execute("PRAGMA foreign_keys = ON")


def _grant_new_permissions(conn):
    """لو دور موجود من قبل ولسه ملهوش صلاحيات الطلبات/الجزاءات الجديدة، نضيفها له تلقائيًا."""
    roles = conn.execute("SELECT * FROM roles").fetchall()
    for role in roles:
        new_perms = NEW_PERMISSIONS_BY_ROLE.get(role["name"])
        if not new_perms:
            continue
        current = set(role["permissions"].split(",")) if role["permissions"] else set()
        missing = [p for p in new_perms if p not in current]
        if missing:
            updated = ",".join(sorted(current | set(missing)))
            conn.execute("UPDATE roles SET permissions=? WHERE id=?", (updated, role["id"]))


def _seed_leave_and_violation_types(conn):
    if conn.execute("SELECT COUNT(*) c FROM leave_types").fetchone()["c"] == 0:
        for name, quota, paid in DEFAULT_LEAVE_TYPES:
            conn.execute(
                "INSERT INTO leave_types (name, annual_quota, paid) VALUES (?, ?, ?)",
                (name, quota, paid),
            )
    if conn.execute("SELECT COUNT(*) c FROM violation_types").fetchone()["c"] == 0:
        for name in DEFAULT_VIOLATION_TYPES:
            conn.execute("INSERT INTO violation_types (name) VALUES (?)", (name,))


def _ensure_shift_type_columns(conn):
    cols = [r["name"] for r in conn.execute("PRAGMA table_info(shift_types)").fetchall()]
    if "is_off" not in cols:
        conn.execute("ALTER TABLE shift_types ADD COLUMN is_off INTEGER NOT NULL DEFAULT 0")
    if "code" not in cols:
        conn.execute("ALTER TABLE shift_types ADD COLUMN code TEXT")
    conn.execute("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT)")
    if not conn.execute("SELECT 1 FROM shift_types WHERE is_off=1").fetchone():
        try:
            conn.execute(
                "INSERT INTO shift_types (name, start_time, end_time, is_off, code) VALUES ('أوف', '00:00', '00:00', 1, 'off')")
        except sqlite3.IntegrityError:      # اسم 'أوف' مستخدم قبل كده كنوع عادي
            conn.execute(
                "INSERT INTO shift_types (name, start_time, end_time, is_off, code) VALUES ('أوف (إجازة أسبوعية)', '00:00', '00:00', 1, 'off')")
    conn.commit()


def _seed_shift_types(conn):
    if conn.execute("SELECT COUNT(*) c FROM shift_types WHERE is_off=0").fetchone()["c"] == 0:
        for name, start, end in DEFAULT_SHIFT_TYPES:
            conn.execute(
                "INSERT INTO shift_types (name, start_time, end_time) VALUES (?, ?, ?)",
                (name, start, end),
            )


def _migrate_users_to_roles(conn, old_cols):
    """يحوّل جدول المستخدمين القديم (role نصي: admin/accountant) لنظام الأدوار الجديد."""
    old_rows = conn.execute("SELECT * FROM users").fetchall()
    conn.execute("ALTER TABLE users RENAME TO users_old_migration")
    conn.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role_id INTEGER NOT NULL REFERENCES roles(id),
            branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
            department TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)
    chairman_id = conn.execute(
        "SELECT id FROM roles WHERE name='رئيس مجلس الإدارة'"
    ).fetchone()["id"]
    accountant_role_id = conn.execute(
        "SELECT id FROM roles WHERE name='محاسب'"
    ).fetchone()["id"]

    for r in old_rows:
        old_role = r["role"] if "role" in r.keys() else "accountant"
        role_id = chairman_id if old_role == "admin" else accountant_role_id
        conn.execute(
            """INSERT INTO users (id, username, password_hash, full_name, role_id, branch_id, department, created_at)
               VALUES (?, ?, ?, ?, ?, ?, NULL, ?)""",
            (r["id"], r["username"], r["password_hash"], r["full_name"], role_id,
             r["branch_id"], r["created_at"]),
        )
    conn.execute("DROP TABLE users_old_migration")


def _seed_roles(conn):
    existing = conn.execute("SELECT COUNT(*) c FROM roles").fetchone()["c"]
    if existing == 0:
        for name, perms in DEFAULT_ROLES:
            conn.execute(
                "INSERT INTO roles (name, permissions) VALUES (?, ?)",
                (name, ",".join(perms)),
            )
        conn.commit()


def init_db():
    os.makedirs(os.path.join(BASE_DIR, "data"), exist_ok=True)
    os.makedirs(os.path.join(UPLOADS_DIR, "employees"), exist_ok=True)
    os.makedirs(os.path.join(UPLOADS_DIR, "documents"), exist_ok=True)

    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()

    _seed_roles(conn)
    _migrate(conn)
    _create_indexes(conn)

    # seed أول مرة فقط: فرع رئيسي + مستخدم "رئيس مجلس إدارة" بكل الصلاحيات
    existing = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    if existing == 0:
        conn.execute(
            "INSERT INTO branches (name, address, phone) VALUES (?, ?, ?)",
            ("الفرع الرئيسي", "", ""),
        )
        chairman_id = conn.execute(
            "SELECT id FROM roles WHERE name='رئيس مجلس الإدارة'"
        ).fetchone()["id"]
        conn.execute(
            """INSERT INTO users (username, password_hash, full_name, role_id, branch_id, department, must_change_password)
               VALUES (?, ?, ?, ?, NULL, NULL, 1)""",
            ("admin", generate_password_hash(DEFAULT_ADMIN_PASSWORD), "المدير العام", chairman_id),
        )
        conn.commit()
    conn.close()

    if not backup_today_exists():
        try:
            backup_now()
        except Exception:
            pass  # النسخ الاحتياطي مش لازم يوقف تشغيل التطبيق لو فشل لأي سبب


def daily_rate(base_salary):
    return round((base_salary or 0) / 30, 2)


def hourly_rate(base_salary):
    return round(daily_rate(base_salary) / 8, 2)


def _time_to_minutes(t):
    h, m = map(int, t.split(":"))
    return h * 60 + m


def minutes_late(check_in, shift_start):
    """عدد دقائق التأخير عن بداية الشفت (0 لو حضر في الوقت أو قبله)."""
    diff = _time_to_minutes(check_in) - _time_to_minutes(shift_start)
    return max(0, diff)


def minutes_overtime(check_out, shift_start, shift_end):
    """عدد دقائق الأوفر تايم بعد نهاية الشفت، مع مراعاة الشفتات العابرة لمنتصف الليل."""
    ss = _time_to_minutes(shift_start)
    se = _time_to_minutes(shift_end)
    co = _time_to_minutes(check_out)
    crosses_midnight = (se <= ss) or (se == 24 * 60)
    if not crosses_midnight:
        return max(0, co - se)
    se_adj = se if se > ss else se + 24 * 60
    co_adj = co if co >= ss else co + 24 * 60
    return max(0, co_adj - se_adj)


def period_bounds(label, start_day=28):
    """
    يحوّل تسمية شهر (مثل '2026-09') إلى بداية ونهاية الفترة المحاسبية الفعلية.
    الفترة المسمّاة 'سبتمبر' تبدأ يوم 28 أغسطس وتنتهي يوم 27 سبتمبر.
    """
    year, month = map(int, label.split("-"))
    if month == 1:
        start_year, start_month = year - 1, 12
    else:
        start_year, start_month = year, month - 1

    last_day_start_month = calendar.monthrange(start_year, start_month)[1]
    sd = min(start_day, last_day_start_month)
    start_date = date(start_year, start_month, sd)

    if start_day > 1:
        end_day = start_day - 1
        last_day_end_month = calendar.monthrange(year, month)[1]
        end_date = date(year, month, min(end_day, last_day_end_month))
    else:
        end_date = date(year, month, calendar.monthrange(year, month)[1])

    return start_date, end_date


def current_period_label(start_day=28):
    """يحدد تسمية الفترة (شهر) الحالية بناءً على تاريخ اليوم."""
    today = date.today()
    if today.day >= start_day:
        y, m = today.year, today.month + 1
        if m > 12:
            m = 1
            y += 1
    else:
        y, m = today.year, today.month
    return f"{y:04d}-{m:02d}"


def log_action(conn, user, action, entity=None, entity_id=None, details=None):
    """يسجّل عملية في سجل العمليات (Audit Log)."""
    conn.execute(
        "INSERT INTO audit_log (user_id, username, action, entity, entity_id, details) VALUES (?, ?, ?, ?, ?, ?)",
        (user["id"] if user else None, user["full_name"] if user else "النظام",
         action, entity, entity_id, details),
    )


BACKUPS_DIR = os.path.join(BASE_DIR, "data", "backups")
BACKUP_RETENTION_DAYS = 30


def _snapshot_db(dest):
    """نسخة متّسقة من قاعدة البيانات حتى لو التطبيق شغّال (SQLite backup API)."""
    src = sqlite3.connect(DB_PATH, timeout=10)
    try:
        dst = sqlite3.connect(dest)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def backup_now(label=None):
    """نسخة احتياطية فورية من قاعدة البيانات، ويرجع اسم الملف."""
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    stamp = label or datetime.now().strftime("%Y-%m-%d_%H%M%S")
    dest = os.path.join(BACKUPS_DIR, f"app_{stamp}.db")
    if os.path.exists(DB_PATH):
        _snapshot_db(dest)
    _cleanup_old_backups()
    return os.path.basename(dest)


def backup_full():
    """نسخة كاملة (zip): قاعدة البيانات + كل الصور والمستندات المرفوعة."""
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    tmp_db = os.path.join(BACKUPS_DIR, f"_tmp_{stamp}.db")
    dest = os.path.join(BACKUPS_DIR, f"full_{stamp}.zip")
    _snapshot_db(tmp_db)
    try:
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(tmp_db, "data/app.db")
            if os.path.isdir(UPLOADS_DIR):
                for root, _dirs, files in os.walk(UPLOADS_DIR):
                    for f in files:
                        full = os.path.join(root, f)
                        z.write(full, os.path.join("static", "uploads", os.path.relpath(full, UPLOADS_DIR)))
    finally:
        if os.path.exists(tmp_db):
            os.remove(tmp_db)
    _cleanup_old_backups()
    return os.path.basename(dest)


def _cleanup_old_backups():
    if not os.path.isdir(BACKUPS_DIR):
        return
    cutoff = datetime.now().timestamp() - (BACKUP_RETENTION_DAYS * 86400)
    for fname in os.listdir(BACKUPS_DIR):
        fpath = os.path.join(BACKUPS_DIR, fname)
        if os.path.isfile(fpath) and os.path.getmtime(fpath) < cutoff:
            os.remove(fpath)


def list_backups():
    if not os.path.isdir(BACKUPS_DIR):
        return []
    files = []
    for fname in sorted(os.listdir(BACKUPS_DIR), reverse=True):
        fpath = os.path.join(BACKUPS_DIR, fname)
        if os.path.isfile(fpath):
            files.append({
                "name": fname,
                "size_kb": round(os.path.getsize(fpath) / 1024, 1),
                "date": datetime.fromtimestamp(os.path.getmtime(fpath)).strftime("%Y-%m-%d %H:%M"),
            })
    return files


def backup_today_exists():
    if not os.path.isdir(BACKUPS_DIR):
        return False
    today_prefix = f"app_{date.today().isoformat()}"
    return any(f.startswith(today_prefix) and f.endswith(".db") for f in os.listdir(BACKUPS_DIR))


def leave_balance(conn, employee_id, leave_type_id, year):
    """يرجع (المخصص، المستخدم، المتبقي) لموظف معين في نوع إجازة معين خلال سنة معينة."""
    lt = conn.execute("SELECT * FROM leave_types WHERE id=?", (leave_type_id,)).fetchone()
    if not lt:
        return None
    used = conn.execute(
        """SELECT COALESCE(SUM(days_count), 0) s FROM leave_requests
           WHERE employee_id=? AND leave_type_id=? AND status='approved'
                 AND substr(start_date,1,4)=?""",
        (employee_id, leave_type_id, str(year)),
    ).fetchone()["s"]
    allocated = lt["annual_quota"]
    remaining = (allocated - used) if allocated is not None else None
    return {"allocated": allocated, "used": used, "remaining": remaining}


EXPAT_CYCLE_DAYS = 26
EXPAT_CYCLE_LEAVE_DAYS = 4


def detect_last_leave_from_attendance(conn, employee_id, lookback_days=400):
    """يدوّر في سجل الحضور المستورد على آخر سلسلة أيام إجازة متتالية اتقفلت برجوع فعلي (يوم حضور
    بعدها)، ويرجّع (تاريخ الرجوع، عدد أيام السلسلة) أو None. ده بيخلّي دورة الإجازة تتحدّث تلقائيًا
    من بيانات الحضور المستوردة، من غير ما حد يحتاج يسجّلها يدويًا في كل مرة."""
    cutoff = (date.today() - timedelta(days=lookback_days)).isoformat()
    rows = conn.execute(
        "SELECT date, status FROM attendance WHERE employee_id=? AND date >= ? ORDER BY date ASC",
        (employee_id, cutoff),
    ).fetchall()
    if not rows:
        return None
    RETURN_MARKERS = ("present", "half_day", "mission", "start_of_work")
    best = None
    i, n = 0, len(rows)
    while i < n:
        if rows[i]["status"] == "leave":
            j = i
            while j < n and rows[j]["status"] == "leave":
                j += 1
            if j < n and rows[j]["status"] in RETURN_MARKERS:
                best = (rows[j]["date"], j - i)   # آخر سلسلة مقفولة تفوز، فبنكمل نمشي على طول
            i = j
        else:
            i += 1
    return best


def leave_rotation_status(conn, employee):
    """يحسب حالة دورة الإجازة للموظف حسب نوع إقامته:
    - مغترب: كل 26 يوم عمل يستحق 4 أيام إجازة، من آخر تاريخ رجوع (المسجَّل يدويًا لو موجود،
      وإلا آخر إجازة معتمدة، وإلا تاريخ التعيين). بيحسب رقم الدورة الحالية ويتقدّم بيها تلقائيًا
      لحد الدورة اللي إحنا فيها دلوقتي، عشان ميوريكش رقم أيام سالب ضخم لموظف اتأخر تسجيله فترة طويلة.
    - مقيم (نفس المحافظة): يوم إجازة أسبوعي ثابت."""
    if employee["residence_type"] == "مغترب":
        manual = employee["last_leave_return"] if "last_leave_return" in employee.keys() else None
        last_leave = conn.execute(
            """SELECT end_date FROM leave_requests WHERE employee_id=? AND status='approved'
               ORDER BY end_date DESC LIMIT 1""",
            (employee["id"],),
        ).fetchone()
        auto = detect_last_leave_from_attendance(conn, employee["id"])   # يدوّر في الحضور المستورد فعليًا
        auto_return, auto_days = auto if auto else (None, None)

        candidates = [d for d in (manual, last_leave["end_date"] if last_leave else None, auto_return) if d]
        if candidates:
            anchor_date = max(date.fromisoformat(d) for d in candidates)
            anchor_is_actual_return = True     # تاريخ رجوع فعلي مؤكَّد (مش مجرد تخمين من تاريخ التعيين)
            # الحضور المستورد هو المصدر الأحدث والأدق لو هو اللي فاز فعلًا بأحدث تاريخ
            anchor_from_attendance = bool(auto_return) and anchor_date.isoformat() == auto_return
        elif employee["start_date"]:
            anchor_date = date.fromisoformat(employee["start_date"])
            anchor_is_actual_return = False
            anchor_from_attendance = False
        else:
            return {"type": "مغترب", "last_return": None, "next_due": None, "days_left": None,
                    "cycle_no": None, "overdue_cycles": 0, "status": "غير محدد (سجّل تاريخ تعيين أو إجازة)"}

        cycle_len = EXPAT_CYCLE_DAYS + EXPAT_CYCLE_LEAVE_DAYS   # 26 عمل + 4 إجازة = 30 يوم للدورة الواحدة
        today = date.today()
        elapsed = (today - anchor_date).days
        cycles_completed = max(0, elapsed // cycle_len) if elapsed > 0 else 0
        # بداية الدورة الحالية (اللي إحنا فيها دلوقتي فعليًا)، مش أول دورة من الأول
        current_cycle_start = anchor_date + timedelta(days=cycles_completed * cycle_len)
        next_due = current_cycle_start + timedelta(days=EXPAT_CYCLE_DAYS)
        days_left = (next_due - today).days

        if days_left < 0:
            status = "في إجازة الدورة الحالية" if days_left >= -EXPAT_CYCLE_LEAVE_DAYS else "متأخر"
        elif days_left <= 3:
            status = "مستحق قريبًا"
        else:
            status = "عادي"

        manual_days = employee["last_leave_days"] if "last_leave_days" in employee.keys() else None
        return {
            "type": "مغترب", "last_return": anchor_date.isoformat(),
            "anchor_is_actual_return": anchor_is_actual_return,
            # لو التاريخ المعتمَد جه فعليًا من سجل الحضور المستورد (مش تسجيل يدوي ولا طلب إجازة)
            "anchor_from_attendance": anchor_from_attendance,
            "next_due": next_due.isoformat(), "days_left": days_left,
            "cycle_no": cycles_completed + 1,
            # لو الأصل تاريخ تعيين بس (مش رجوع فعلي مؤكَّد) وعدّى عليه دورة كاملة أو أكتر من غير تسجيل،
            # ده معناه بيانات الموظف محتاجة تحديث فعلي (مش مجرد تنبيه تأخير عادي)
            "needs_update": (not anchor_is_actual_return) and cycles_completed >= 1,
            "leave_days_due": EXPAT_CYCLE_LEAVE_DAYS,
            # عدد الأيام: المسجَّل يدويًا لو موجود، وإلا المكتشَف تلقائيًا من نفس سلسلة الإجازة المعتمَدة كمصدر
            "last_leave_days": manual_days if manual_days else (auto_days if anchor_from_attendance else None),
            "last_leave_days_is_auto": (not manual_days) and anchor_from_attendance and bool(auto_days),
            "status": status,
        }
    else:
        return {
            "type": "مقيم", "weekly_day_off": employee["weekly_day_off"] or "غير محدد",
            "status": "أسبوعي ثابت",
        }
