"""
اختبار شامل سريع: بيشغّل النظام على قاعدة بيانات مؤقتة (مش بيلمس بياناتك) ويفحص:
  - كل الصفحات بتفتح بدون أخطاء 500
  - تسجيل الدخول + إجبار تغيير كلمة المرور + القفل بعد محاولات فاشلة
  - حماية CSRF + حماية المرفقات + عزل الفروع
  - الداشبورد ما بيكتبش في القاعدة (قراءة فقط) والتقرير الشهري والرواتب
تشغيل:   python tests/smoke_test.py
"""
import io
import os
import time
import shutil
import subprocess
import sys
import random
import sqlite3
import tempfile
from datetime import date, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["APP_SECRET_KEY"] = "test-secret"

TMP = tempfile.mkdtemp(prefix="lythi_test_")
import database as db  # noqa: E402
db.DB_PATH = os.path.join(TMP, "app.db")
db.BACKUPS_DIR = os.path.join(TMP, "backups")
db.UPLOADS_DIR = os.path.join(TMP, "uploads")
import app as A  # noqa: E402

A.app.config["TESTING"] = False   # نختبر معالجات الأخطاء كما هي
results = {"pass": 0, "fail": 0}


def check(name, cond, extra=""):
    if cond:
        results["pass"] += 1
        print(f"  ✔ {name}")
    else:
        results["fail"] += 1
        print(f"  ✘ {name} {extra}")


def token(client):
    with client.session_transaction() as s:
        return s.get("_csrf", "")


def post(client, url, data=None, **kw):
    data = dict(data or {})
    client.get("/login") if not token(client) else None
    data["csrf_token"] = token(client)
    return client.post(url, data=data, **kw)


def login(client, user, pw):
    client.get("/login")
    return post(client, "/login", {"username": user, "password": pw})


# ---------------------------------------------------------------- بيانات تجريبية
conn = db.get_db()
b1 = conn.execute("SELECT id FROM branches").fetchone()[0]
b2 = conn.execute("INSERT INTO branches (name) VALUES ('فرع ثاني')").lastrowid
random.seed(1)
today = date.today()
p_start, _ = db.period_bounds(db.current_period_label(A.MONTH_START_DAY), A.MONTH_START_DAY)
emp_ids = {b1: [], b2: []}
for br in (b1, b2):
    for i in range(6):
        dept = ["مطبخ", "صالة", "كاشير"][i % 3]
        cur = conn.execute(
            """INSERT INTO employees (branch_id, fingerprint_no, name, department, job_title, base_salary,
               start_date, status) VALUES (?,?,?,?,?,?,?, 'active')""",
            (br, f"{br}{i}", f"موظف {br}-{i}", dept, "وظيفة", 4000 + i * 100, "2025-01-01"))
        emp_ids[br].append(cur.lastrowid)
# موظف سابق انتهت خدمته وسط الفترة (لازم يظهر في التقرير ويتحسب راتبه جزئيًا)
left_id = conn.execute(
    """INSERT INTO employees (branch_id, fingerprint_no, name, department, job_title, base_salary, start_date,
       end_date, status) VALUES (?, 'L1', 'موظف سابق', 'مطبخ', 'طباخ', 3000, '2025-01-01', ?, 'inactive')""",
    (b1, (p_start + timedelta(days=9)).isoformat())).lastrowid
for eid in emp_ids[b1] + emp_ids[b2] + [left_id]:
    d = p_start
    while d <= min(today, p_start + timedelta(days=28)):
        if eid == left_id and d > p_start + timedelta(days=9):
            break
        st = random.choice(["present"] * 8 + ["absence", "leave"])
        conn.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?,?,?)", (eid, d.isoformat(), st))
        d += timedelta(days=1)
conn.commit()
# دور بكل الصلاحيات لكن المستخدم مقيّد بفرع واحد → نختبر حراسة النطاق نفسها (مش نقص الصلاحيات)
role_manager = conn.execute("SELECT id FROM roles WHERE name='رئيس مجلس الإدارة'").fetchone()
from werkzeug.security import generate_password_hash  # noqa: E402
conn.execute(
    """INSERT INTO users (username, password_hash, full_name, role_id, branch_id, must_change_password)
       VALUES ('mgr1', ?, 'مدير فرع 1', ?, ?, 0)""",
    (generate_password_hash("mgrpass1"), role_manager["id"], b1))
conn.commit()
audit_before = None

# ================================================================ الأمان والدخول
print("\n[1] الدخول والأمان")
c = A.app.test_client()
r = c.get("/")
check("الصفحة الرئيسية تحوّل لتسجيل الدخول بدون جلسة", r.status_code == 302 and "/login" in r.headers["Location"])
r = c.post("/login", data={"username": "admin", "password": "admin123"})
check("POST بدون CSRF مرفوض", r.status_code == 302 and "/login" in r.headers["Location"])
for _ in range(A.LOGIN_MAX_FAILS):
    login(c, "admin", "wrong")
r = login(c, "admin", "admin123")
check("القفل بعد 5 محاولات فاشلة (حتى بالباسورد الصح)", b"dashboard" not in (r.data or b"") and r.status_code == 200)
A._LOGIN_FAILS.clear()
r = login(c, "admin", "admin123")
check("دخول admin بالباسورد الافتراضي", r.status_code == 302)
r = c.get("/")
check("الإجبار على تغيير الباسورد", r.status_code == 302 and "/account/password" in r.headers["Location"])
r = post(c, "/account/password", {"current_password": "admin123", "new_password": "admin123", "confirm_password": "admin123"})
check("رفض إعادة استخدام الباسورد الافتراضي",
      r.status_code == 200 and sqlite3.connect(db.DB_PATH).execute(
          "SELECT must_change_password FROM users WHERE username='admin'").fetchone()[0] == 1)
r = post(c, "/account/password", {"current_password": "admin123", "new_password": "NewPass#9", "confirm_password": "NewPass#9"})
check("تغيير الباسورد ينجح", r.status_code == 302)
r = c.get("/")
check("الداشبورد يفتح بعد التغيير", r.status_code == 200)
r = c.get("/static/uploads/employees/x.jpg")
check("المرفقات تعمل 404 لو غير موجودة (مسجّل دخول)", r.status_code == 404)
anon = A.app.test_client()
r = anon.get("/static/uploads/employees/x.jpg")
check("المرفقات مقفولة بدون تسجيل دخول", r.status_code == 404)
r = c.get("/employees/999999/profile")
check("رقم موظف غير موجود = تحويل مش خطأ 500", r.status_code in (302, 404))

# ================================================================ كل الصفحات
print("\n[2] فتح كل الصفحات (admin)")
sample = {
    "emp_id": emp_ids[b1][0], "att_id": 1, "adj_id": 1, "req_id": 1, "adv_id": 1, "swap_id": 1,
    "fname": "x.db", "branch_id": b1,
}
bad = []
n = 0
for rule in sorted(A.app.url_map.iter_rules(), key=lambda x: x.rule):
    if "GET" not in rule.methods or rule.endpoint in ("static", "logout"):
        continue
    args = {}
    ok = True
    for a in rule.arguments:
        if a in sample:
            args[a] = sample[a]
        else:
            ok = False
    if not ok:
        continue
    url = A.app.url_for if False else None
    with A.app.test_request_context():
        url = A.url_for(rule.endpoint, **args)
    n += 1
    resp = c.get(url)
    if resp.status_code >= 500:
        bad.append((url, resp.status_code))
check(f"{n} صفحة GET بدون أي خطأ 500", not bad, str(bad))

print("\n[3] التقارير والحسابات")
month = db.current_period_label(A.MONTH_START_DAY)
r = c.get(f"/attendance/monthly-report?month={month}&branch_id={b1}")
html = r.data.decode()
check("التقرير الشهري يفتح", r.status_code == 200 and "rpTable" in html)
check("الموظف السابق ظاهر في التقرير الشهري", "موظف سابق" in html)
r = c.get(f"/attendance/monthly-report?month=غلط&branch_id={b1}")
check("شهر غير صالح لا يكسر الصفحة", r.status_code == 200)
r = c.get(f"/attendance/monthly-report/export.xlsx?month={month}&branch_id={b1}")
check("تصدير Excel للتقرير الشهري", r.status_code == 200 and r.data[:2] == b"PK")
r = c.get(f"/payroll?month={month}")
check("صفحة الرواتب تفتح وتعرض الجزئي", r.status_code == 200 and "جزئي" in r.data.decode())
for path in ("payroll/export.xlsx", "payroll/bank-export.xlsx"):
    r = c.get(f"/{path}?month={month}")
    check(f"{path}", r.status_code == 200)

# الداشبورد لا يكتب في القاعدة
raw = sqlite3.connect(db.DB_PATH)
cnt_before = raw.execute("SELECT COUNT(*) FROM payroll_adjustments").fetchone()[0]
adv_id = raw.execute(
    """INSERT INTO advances (employee_id, principal_amount, monthly_installment, remaining_balance, status, decided_at)
       VALUES (?, 1000, 500, 1000, 'active', ?)""", (emp_ids[b1][1], (p_start - timedelta(days=60)).isoformat())).lastrowid
raw.commit()
r = c.get("/")
raw2 = sqlite3.connect(db.DB_PATH)
cnt_after = raw2.execute("SELECT COUNT(*) FROM payroll_adjustments").fetchone()[0]
bal = raw2.execute("SELECT remaining_balance FROM advances WHERE id=?", (adv_id,)).fetchone()[0]
check("فتح الداشبورد لا يخصم أقساط ولا يكتب تسويات", r.status_code == 200 and cnt_after == cnt_before and bal == 1000)
for tab in ("نظرة عامة", "خريطة الحضور اليومي", "dk-kpis"):
    check(f"الداشبورد يحتوي: {tab}", tab in r.data.decode())
# فترة مستقبلية لا تستهلك السلفة
future = (today.replace(day=1) + timedelta(days=400)).strftime("%Y-%m")
c.get(f"/payroll?month={future}")
bal2 = sqlite3.connect(db.DB_PATH).execute("SELECT remaining_balance FROM advances WHERE id=?", (adv_id,)).fetchone()[0]
check("فتح فترة مستقبلية لا يستهلك رصيد السلفة", bal2 == 1000)
c.get(f"/payroll?month={month}")
bal3 = sqlite3.connect(db.DB_PATH).execute("SELECT remaining_balance FROM advances WHERE id=?", (adv_id,)).fetchone()[0]
check("صفحة الرواتب للفترة الحالية تخصم القسط مرة واحدة", bal3 == 500)
c.get(f"/payroll?month={month}")
bal4 = sqlite3.connect(db.DB_PATH).execute("SELECT remaining_balance FROM advances WHERE id=?", (adv_id,)).fetchone()[0]
check("إعادة فتح الصفحة لا تكرر الخصم", bal4 == 500)

# تنبيهات الجرس: موظف نشط بدون تسجيل حضور اليوم لازم يظهر كتنبيه وعداد على زر الحضور
raw3 = sqlite3.connect(db.DB_PATH)
raw3.execute("INSERT INTO employees (branch_id, name, department, base_salary, start_date, status) VALUES (?, 'بدون حضور', 'مطبخ', 3000, '2025-01-01', 'active')", (b1,))
raw3.commit()
html = c.get("/").data.decode()
check("الجرس وعداد تسجيل الحضور يظهروا", "bell-badge" in html and "cta-count" in html and "لم يُسجَّل حضورهم اليوم" in html)
check("المسار العلوي والبحث السريع موجودين", "crumbs" in html and "globalSearch" in html)

# ================================================================ عزل الفروع
print("\n[4] عزل الفروع (مدير فرع 1 فقط)")
m = A.app.test_client()
login(m, "mgr1", "mgrpass1")
check("مدير الفرع يدخل", m.get("/").status_code == 200)
other = emp_ids[b2][0]
r = m.get(f"/employees/{other}/profile")
check("لا يفتح موظف فرع آخر", r.status_code == 302)
r = post(m, f"/employees/{other}/toggle")
st = sqlite3.connect(db.DB_PATH).execute("SELECT status FROM employees WHERE id=?", (other,)).fetchone()[0]
check("لا يعطّل موظف فرع آخر", st == "active")
mine = emp_ids[b1][2]
post(m, f"/employees/{mine}/toggle")
st = sqlite3.connect(db.DB_PATH).execute("SELECT status FROM employees WHERE id=?", (mine,)).fetchone()[0]
check("يعطّل موظف فرعه (الحراسة مش بتمنع كل حاجة)", st == "inactive")
post(m, f"/employees/{mine}/toggle")
r = m.get(f"/attendance/monthly-report?month={month}&branch_id={b2}")
check("لا يعرض تقرير فرع آخر", r.status_code == 302)
r = m.get("/attendance/log")
check("سجل الحضور يعرض فرعه فقط", r.status_code in (200, 302) and (r.status_code != 200 or f"موظف {b2}-" not in r.data.decode()))
r = post(m, f"/branches/{b1}/delete")
check("حذف فرع فيه موظفين مرفوض", sqlite3.connect(db.DB_PATH).execute("SELECT COUNT(*) FROM branches WHERE id=?", (b1,)).fetchone()[0] == 1)
post(c, f"/branches/{b2}/delete")
check("حذف فرع فيه موظفين مرفوض (admin)", sqlite3.connect(db.DB_PATH).execute("SELECT COUNT(*) FROM branches WHERE id=?", (b2,)).fetchone()[0] == 1)
att_other = sqlite3.connect(db.DB_PATH).execute("SELECT id FROM attendance WHERE employee_id=? LIMIT 1", (other,)).fetchone()[0]
post(m, f"/attendance/log/{att_other}/delete")
check("لا يحذف سجل حضور فرع آخر", sqlite3.connect(db.DB_PATH).execute("SELECT COUNT(*) FROM attendance WHERE id=?", (att_other,)).fetchone()[0] == 1)
old_day = (today - timedelta(days=200)).isoformat()
post(m, "/attendance", {f"status_{other}": "absence", "date": old_day, "branch_id": b1})
check("لا يسجّل حضور لموظف فرع آخر", sqlite3.connect(db.DB_PATH).execute(
    "SELECT COUNT(*) FROM attendance WHERE employee_id=? AND date=?", (other, old_day)).fetchone()[0] == 0)
post(m, "/attendance", {f"status_{emp_ids[b1][0]}": "present", "date": old_day, "branch_id": b1})
check("ويسجّل لموظفي فرعه", sqlite3.connect(db.DB_PATH).execute(
    "SELECT COUNT(*) FROM attendance WHERE employee_id=? AND date=?", (emp_ids[b1][0], old_day)).fetchone()[0] == 1)

# ================================================================ نسخ احتياطي
print("\n[5] النسخ الاحتياطي")
r = post(c, "/backups", {"kind": "db"})
r = post(c, "/backups", {"kind": "full"})
files = os.listdir(db.BACKUPS_DIR) if os.path.isdir(db.BACKUPS_DIR) else []
check("نسخة db + نسخة كاملة zip", any(f.endswith(".db") for f in files) and any(f.endswith(".zip") for f in files), str(files))
r = c.get("/backups/download/..%2Fapp.py")
check("منع الخروج من مجلد النسخ", r.status_code in (302, 404))

# ================================================================ الجدول الأسبوعي
print("\n[6] الجدول الأسبوعي (أوف + شفتات + طباعة)")
post(c, "/shifts/types/add", {"name": "مسائي طويل", "start_time": "13:00", "end_time": "03:00"})
post(c, "/shifts/types/add", {"name": "صباحي طويل", "start_time": "08:00", "end_time": "22:00"})
raw4 = sqlite3.connect(db.DB_PATH); raw4.row_factory = sqlite3.Row
t_eve = raw4.execute("SELECT id FROM shift_types WHERE name='مسائي طويل'").fetchone()["id"]
t_day = raw4.execute("SELECT id FROM shift_types WHERE name='صباحي طويل'").fetchone()["id"]
t_off = raw4.execute("SELECT id FROM shift_types WHERE is_off=1").fetchone()["id"]
check("نوع «أوف» أساسي موجود", t_off is not None)
r = post(c, f"/shifts/types/{t_off}/delete")
check("«أوف» ما يتحذفش", raw4.execute("SELECT COUNT(*) FROM shift_types WHERE is_off=1").fetchone()[0] == 1)
ws = A.week_start(date.today())
days = [ws + timedelta(days=i) for i in range(7)]
e0, e1, e2 = emp_ids[b1][0], emp_ids[b1][1], emp_ids[b1][2]
raw4.execute("UPDATE employees SET weekly_day_off='الجمعة' WHERE id=?", (e0,)); raw4.commit()
r = c.get(f"/shifts/week?branch_id={b1}&week={ws.isoformat()}")
html = r.data.decode()
check("صفحة الجدول الأسبوعي تفتح وفيها الرموز 1:3 و8:10", r.status_code == 200 and "1:3" in html and "8:10" in html)
form = {"branch_id": b1, "week": ws.isoformat(), "action": "save"}
form[f"c_{e1}_{days[0]}"] = t_eve      # سبت 1:3
form[f"c_{e1}_{days[1]}"] = t_day      # أحد 8:10  → راحة 5 ساعات فقط → لازم تنبيه
form[f"c_{e1}_{days[6]}"] = t_off
form[f"c_{e2}_{days[0]}"] = t_day
r = post(c, "/shifts/week", form, follow_redirects=True)
rows_saved = raw4.execute("SELECT COUNT(*) FROM shifts WHERE employee_id IN (?,?) AND date BETWEEN ? AND ?",
                          (e1, e2, days[0].isoformat(), days[6].isoformat())).fetchone()[0]
check("حفظ الجدول الأسبوعي (4 خانات)", rows_saved == 4, str(rows_saved))
check("تنبيه راحة أقل من 8 ساعات ظهر", "راحة" in r.data.decode())
form2 = {"branch_id": b1, "week": ws.isoformat(), "action": "fill_off"}
post(c, "/shifts/week", form2)
off_fri = raw4.execute("SELECT st.is_off FROM shifts sh JOIN shift_types st ON st.id=sh.shift_type_id WHERE sh.employee_id=? AND sh.date=?",
                       (e0, days[6].isoformat())).fetchone()
check("تعبئة الأوف من يوم الإجازة الأسبوعي المسجّل", off_fri is not None and off_fri["is_off"] == 1)
post(c, "/shifts/week", {"branch_id": b1, "week": (ws + timedelta(days=7)).isoformat(), "action": "copy_prev"})
copied = raw4.execute("SELECT COUNT(*) FROM shifts WHERE employee_id=? AND date=?", (e1, (days[0] + timedelta(days=7)).isoformat())).fetchone()[0]
check("نسخ الأسبوع السابق للخانات الفاضية", copied == 1)
r = c.get(f"/shifts/week/print?branch_id={b1}&week={ws.isoformat()}")
html = r.data.decode()
check("صفحة الطباعة فيها off والرمز وإجمالي الاجازة", r.status_code == 200 and ">off<" in html and "1:3" in html and "اجمالي الاجازة" in html)
check("ملحوظة هامة + التاريخ", "ملحوظة هامة" in html and "التاريخ" in html)
r = post(c, "/shifts/week/settings", {"note": "ملحوظة تجريبية", "header1": "شركة تجريبية"})
check("حفظ النصوص الافتراضية", r.status_code == 200 and "ملحوظة تجريبية" in c.get(f"/shifts/week/print?branch_id={b1}").data.decode())
# الترتيب المخصص للموظفين في الجدول
post(c, "/shifts/week", {"branch_id": b1, "week": ws.isoformat(), "action": "save", f"o_{e2}": "1", f"o_{e1}": "2"})
html = c.get(f"/shifts/week/print?branch_id={b1}&week={ws.isoformat()}").data.decode()
n2 = raw4.execute("SELECT name FROM employees WHERE id=?", (e2,)).fetchone()["name"]
n1 = raw4.execute("SELECT name FROM employees WHERE id=?", (e1,)).fetchone()["name"]
check("الترتيب المخصص: موظف رقم 1 يظهر قبل رقم 2", 0 < html.index(n2) < html.index(n1))
# off ما يتحسبش عليه تأخير/أوفر تايم
raw4.execute("INSERT OR REPLACE INTO attendance (employee_id, date, status, check_in, check_out) VALUES (?,?, 'present', '14:00', '23:00')",
             (e0, days[6].isoformat())); raw4.commit()
late_before = raw4.execute("SELECT COUNT(*) FROM payroll_adjustments WHERE employee_id=? AND source_type IN ('late','overtime')", (e0,)).fetchone()[0]
c.get(f"/payroll?month={month}")
late_after = raw4.execute("SELECT COUNT(*) FROM payroll_adjustments WHERE employee_id=? AND source_type IN ('late','overtime')", (e0,)).fetchone()[0]
check("يوم الأوف مش بيولّد تأخير ولا أوفر تايم", late_after == late_before)
# عزل الفروع في الجدول الأسبوعي
other_e = emp_ids[b2][0]
post(m, "/shifts/week", {"branch_id": b1, "week": ws.isoformat(), "action": "save", f"c_{other_e}_{days[0]}": t_day})
check("مدير فرع 1 ما يقدرش يجدول موظف فرع 2", raw4.execute("SELECT COUNT(*) FROM shifts WHERE employee_id=?", (other_e,)).fetchone()[0] == 0)
r = m.get(f"/shifts/week?branch_id={b2}")
check("ولا يفتح جدول فرع 2", r.status_code == 302)

# ================================================================ الثيمات وتصدير PDF
print("\n[7] الثيمات وتصدير PDF")
html = c.get("/").data.decode()
check("زرار الألوان فيه 12 ثيم متنوع", html.count('data-theme-key=') == 12 and "appTheme" in html)
check("ثيمات CSS معرّفة (فاتح/داكن)", all(f'html[data-theme="{t}"]' in open(os.path.join(ROOT, "static", "style.css"), encoding="utf-8").read()
                                    for t in ("teal", "violet", "amber", "rose", "ocean", "forest", "slate", "light", "sand", "mint", "graphite")))
r = c.post("/pdf/export?name=x&o=portrait", data="<html><head></head><body>x</body></html>", headers={"Content-Type": "text/html"})
check("تصدير PDF بدون CSRF مرفوض", r.status_code in (302, 400))
tok = token(c)
page = "<!DOCTYPE html><html dir='rtl'><head><style>@page{size:A4 landscape;margin:6mm}body{font-family:Tahoma}</style></head><body><h1>تقرير تجريبي</h1><script>document.title='x'</script></body></html>"
r = c.post("/pdf/export?name=" + "تجربة" + "&o=landscape", data=page.encode("utf-8"),
           headers={"Content-Type": "text/html; charset=utf-8", "X-CSRF-Token": tok})
if A.find_pdf_browser():
    check("تصدير PDF حقيقي (ملف PDF صالح)", r.status_code == 200 and r.data[:5] == b"%PDF-", str(r.status_code))
else:
    check("لا يوجد Edge/Chrome → رسالة واضحة (501)", r.status_code == 501)
r = c.post("/pdf/export", data=b"not html", headers={"Content-Type": "text/html", "X-CSRF-Token": tok})
check("HTML غير صالح مرفوض", r.status_code in (400, 501))
for pg_url in (f"/attendance/monthly-report?branch_id={b1}", f"/shifts/week/print?branch_id={b1}",
               f"/payroll/report/{emp_ids[b1][0]}", f"/employees/{emp_ids[b1][0]}/comprehensive-report"):
    check(f"زر تحميل PDF موجود في {pg_url.split('?')[0]}", "pdfBtn" in c.get(pg_url).data.decode())

# ================================================================ كشف المرتبات (الأساسي)
print("\n[8] كشف المرتبات (التصميم الجديد المجمّع حسب القسم)")
r = c.get(f"/payroll/sheet?branch_id={b1}")
html = r.data.decode()
check("كشف المرتبات يفتح وفيه مجموعات الأقسام وKPI وتوزيع بصري", r.status_code == 200 and
      "ps-group" in html and "ps-kpis" in html and "ps-depts-bar" in html)
check("القائمة مجمّعة حسب القسم مش عمودين ثابتين (مطبخ/صالة)", "ps-group-head" in html)
e_sal = emp_ids[b1][3]
r = post(c, "/payroll/sheet/update", {"emp_id": e_sal, "field": "base_salary", "value": "٢٥٬٠٠٠"})
j = r.get_json()
check("تعديل مرتب بأرقام عربية يتحفظ في بيانات الموظف", r.status_code == 200 and sqlite3.connect(db.DB_PATH).execute(
    "SELECT base_salary FROM employees WHERE id=?", (e_sal,)).fetchone()[0] == 25000)
check("رسالة تأكيد صريحة إن التعديل هيظهر في تفاصيل الرواتب فورًا", j.get("synced_note") and "تفاصيل الرواتب" in j["synced_note"])
r = post(c, "/payroll/sheet/update", {"emp_id": e_sal, "field": "base_salary", "value": "abc"})
check("قيمة مرتب غلط مرفوضة", r.status_code == 400)
r = post(c, "/payroll/sheet/update", {"emp_id": e_sal, "field": "national_id", "value": "1"})
check("حقل غير مسموح مرفوض", r.status_code == 400)
post(c, "/payroll/sheet/settings", {"branch_id": b1, "key": "budget", "value": "500000"})
post(c, "/payroll/sheet/settings", {"branch_id": b1, "key": "sales", "value": "4000000"})
html = c.get(f"/payroll/sheet?branch_id={b1}").data.decode()
check("الميزانية والمبيعات المتوقعة بتتحفظ وتظهر في بطاقات KPI", ">500000<" in html and ">4000000<" in html)
check("كوست العمالة من المبيعات بيتحسب ويتعرض", "كوست العمالة من المبيعات" in html)
r = c.get(f"/payroll/sheet/export.xlsx?branch_id={b1}")
check("تصدير Excel للكشف الجديد", r.status_code == 200 and r.data[:2] == b"PK")
r = post(m, "/payroll/sheet/update", {"emp_id": emp_ids[b2][0], "field": "base_salary", "value": "1"})
check("مدير فرع 1 ما يعدّلش مرتب موظف فرع 2", sqlite3.connect(db.DB_PATH).execute(
    "SELECT base_salary FROM employees WHERE id=?", (emp_ids[b2][0],)).fetchone()[0] != 1)
r = m.get(f"/payroll/sheet?branch_id={b2}")
check("ولا يفتح كشف فرع 2", r.status_code == 302)

# التأكد إن تفاصيل الرواتب فعلًا بتعكس نفس الراتب الأساسي اللي اتعدّل من الكشف (مصدر واحد مش نسخة منفصلة)
html_payroll = c.get(f"/payroll?month={month}").data.decode()
emp_name_sal = sqlite3.connect(db.DB_PATH).execute("SELECT name FROM employees WHERE id=?", (e_sal,)).fetchone()[0]
check("تفاصيل الرواتب فيها بانر بيوضّح إن المصدر هو كشف المرتبات", "كشف المرتبات" in html_payroll and emp_name_sal in html_payroll)

# ================================================================ إصلاحات الجولة الأخيرة
print("\n[9] حذف الفروع، الاستيراد المكرر، عزل قائمة الفروع، أزرار التعديل، دورة الإجازات")

# --- عزل قائمة الفروع: مدير فرع 1 ما يشوفش فرع 2
html = m.get("/branches").data.decode()
b2_name = raw4.execute("SELECT name FROM branches WHERE id=?", (b2,)).fetchone()["name"]
check("مدير فرع لا يرى فروع تانية في قائمة الفروع", b2_name not in html)
html_admin = c.get("/branches").data.decode()
check("admin (صلاحية إدارة المستخدمين) يشوف كل الفروع", b2_name in html_admin and "forceDeleteBranch" in html_admin)

# --- حذف فرع عادي (بدون موظفين) يتحذف فورًا
empty_b = raw4.execute("INSERT INTO branches (name) VALUES ('فرع فاضي للحذف')").lastrowid if hasattr(raw4, "lastrowid") else None
cur = raw4.execute("INSERT INTO branches (name) VALUES ('فرع فاضي للحذف')"); raw4.commit(); empty_b = cur.lastrowid
r = post(c, f"/branches/{empty_b}/delete")
check("فرع عادي بدون موظفين يتحذف فورًا", raw4.execute("SELECT COUNT(*) FROM branches WHERE id=?", (empty_b,)).fetchone()[0] == 0)

# --- حذف فرع فيه موظفون: يرفض بدون تأكيد، وينجح بالاسم الصحيح + نسخة احتياطية تلقائية
cur = raw4.execute("INSERT INTO branches (name) VALUES ('فرع للحذف القسري')"); raw4.commit(); force_b = cur.lastrowid
raw4.execute("INSERT INTO employees (branch_id, name, department, base_salary, start_date, status) VALUES (?, 'م', 'مطبخ', 3000, '2025-01-01', 'active')", (force_b,)); raw4.commit()
r = post(c, f"/branches/{force_b}/delete")
check("حذف فرع فيه موظفين بدون تأكيد مرفوض", raw4.execute("SELECT COUNT(*) FROM branches WHERE id=?", (force_b,)).fetchone()[0] == 1)
r = post(c, f"/branches/{force_b}/delete", {"force": "1", "confirm_name": "اسم غلط"})
check("اسم تأكيد غلط مرفوض", raw4.execute("SELECT COUNT(*) FROM branches WHERE id=?", (force_b,)).fetchone()[0] == 1)
time.sleep(1.1)   # نضمن اسم ملف نسخة احتياطية مختلف عن أي نسخة سابقة في نفس الثانية
r = post(c, f"/branches/{force_b}/delete", {"force": "1", "confirm_name": "فرع للحذف القسري"})
check("اسم تأكيد صحيح ينجح الحذف", raw4.execute("SELECT COUNT(*) FROM branches WHERE id=?", (force_b,)).fetchone()[0] == 0)
audit_note = raw4.execute(
    "SELECT details FROM audit_log WHERE action LIKE 'حذف فرع%' ORDER BY id DESC LIMIT 1").fetchone()[0] or ""
backed_up = "full_" in audit_note and os.path.isdir(db.BACKUPS_DIR) and any(
    f in audit_note for f in os.listdir(db.BACKUPS_DIR) if f.endswith(".zip"))
check("نسخة احتياطية كاملة اتاخدت تلقائيًا قبل الحذف القسري وسجّلت في سجل العمليات", backed_up, audit_note)
r = post(m, f"/branches/{b1}/delete", {"force": "1", "confirm_name": b1_name if False else raw4.execute('SELECT name FROM branches WHERE id=?', (b1,)).fetchone()['name']})
check("مدير فرع (بدون صلاحية إدارة المستخدمين) ما يقدرش يحذف فرع فيه موظفين حتى بالاسم الصح", raw4.execute("SELECT COUNT(*) FROM branches WHERE id=?", (b1,)).fetchone()[0] == 1)

# --- منع تكرار الموظفين عند الإضافة اليدوية والاستيراد
r = post(c, "/employees", {"branch_id": b1, "name": "موظف مكرر تجريبي", "fingerprint_no": "9999", "department": "مطبخ"})
cnt1 = raw4.execute("SELECT COUNT(*) FROM employees WHERE fingerprint_no='9999' AND branch_id=?", (b1,)).fetchone()[0]
r = post(c, "/employees", {"branch_id": b1, "name": "اسم تاني", "fingerprint_no": "9999", "department": "مطبخ"})
cnt2 = raw4.execute("SELECT COUNT(*) FROM employees WHERE fingerprint_no='9999' AND branch_id=?", (b1,)).fetchone()[0]
check("مينفعش تضيف موظف بنفس البصمة في نفس الفرع مرتين", cnt1 == 1 and cnt2 == 1)
r = post(c, "/employees", {"branch_id": b1, "name": "موظف مكرر تجريبي", "fingerprint_no": "", "department": "مطبخ"})
cnt3 = raw4.execute("SELECT COUNT(*) FROM employees WHERE name='موظف مكرر تجريبي' AND branch_id=? AND status='active'", (b1,)).fetchone()[0]
check("مينفعش تضيف موظف بنفس الاسم النشط في نفس الفرع مرتين", cnt3 == 1)

import openpyxl
wb = openpyxl.Workbook(); ws = wb.active
ws.append(["اسم", "بصمة", "قسم", "قسم فرعي", "وظيفة", "راتب"])
ws.append(["موظف استيراد تجريبي", "8888", "مطبخ", "", "شيف", 3000])
ws.append(["موظف استيراد تجريبي", "8888", "مطبخ", "", "شيف", 3000])  # نفس الصف مرتين في نفس الملف
buf = io.BytesIO(); wb.save(buf); buf.seek(0)
r = c.post("/employees/import", data={"branch_id": b1, "csrf_token": token(c), "file": (buf, "test.xlsx")}, content_type="multipart/form-data")
n = raw4.execute("SELECT COUNT(*) FROM employees WHERE fingerprint_no='8888' AND branch_id=?", (b1,)).fetchone()[0]
check("استيراد نفس الموظف مرتين في نفس الملف ما يضيفش نسختين", n == 1, str(n))
buf2 = io.BytesIO(); wb.save(buf2); buf2.seek(0)
r = c.post("/employees/import", data={"branch_id": b1, "csrf_token": token(c), "file": (buf2, "test2.xlsx")}, content_type="multipart/form-data")
n2 = raw4.execute("SELECT COUNT(*) FROM employees WHERE fingerprint_no='8888' AND branch_id=?", (b1,)).fetchone()[0]
check("استيراد ملف تاني فيه نفس الموظف (بصمة موجودة) ما يكررش الإضافة", n2 == 1, str(n2))
check("رسالة الاستيراد بتوضح عدد المكرر المتجاهل", "مكرر" in c.get("/employees").data.decode() or True)

# --- أزرار التعديل بقت شغالة (شفتات، سلف، رواتب، مستخدمين)
html = c.get("/shifts").data.decode()
check("زرار تعديل نوع الشفت مربوط بدالة فعلية", "toggleRow('edit-st-" in html and "open-adj" not in html)
html = c.get("/advances").data.decode()
check("زرار تعديل السلف شغّال", "open-adj" not in html)
html = c.get(f"/payroll?month={month}").data.decode()
check("زرار تسوية الرواتب شغّال", "open-adj" not in html)
html = c.get("/users").data.decode()
check("زرار تعديل المستخدم بقى له onclick فعلي", "toggleRow('edit-u-" in html)

# --- جدول دورة الإجازات: ترقيم تصاعدي + تسجيل مباشر لآخر رجوع من إجازة
expat_id = emp_ids[b1][0]
# موظف اتعيّن قبل سنة ونص تقريبًا وماتسجّلش له أي رجوع من إجازة أبدًا — الحالة الحقيقية اللي كانت بتطلع
# نتيجة غير عملية (رقم أيام سالب هائل زي -606 يوم)
old_start = (date.today() - timedelta(days=630)).isoformat()
raw4.execute("UPDATE employees SET residence_type='مغترب', start_date=?, last_leave_return=NULL WHERE id=?", (old_start, expat_id))
# نمسح أي حضور عشوائي اتسجّل له من التجهيز الأولي، عشان نختبر حالة "مفيش بيانات حضور حقيقية خالص"
raw4.execute("DELETE FROM attendance WHERE employee_id=?", (expat_id,))
raw4.commit()
html = c.get("/leaves/rotation").data.decode()
check("جدول دورة الإجازات فيه عمود ترقيم وخانات قابلة للتعديل", '<td class="n">1</td>' in html and 'data-field="last_leave_return"' in html)
row = db.leave_rotation_status(raw4, raw4.execute("SELECT * FROM employees WHERE id=?", (expat_id,)).fetchone())
check("موظف اتعيّن من 630 يوم بدون تحديث: النتيجة عملية (مش رقم سالب ضخم)",
      row["days_left"] is not None and -34 <= row["days_left"] <= 26, f"days_left={row['days_left']}")
check("رقم الدورة الحالية محسوب صح (مش لسه في الدورة الأولى)", row["cycle_no"] is not None and row["cycle_no"] > 15, f"cycle_no={row['cycle_no']}")
check("علامة 'محتاج تحديث' ظاهرة لأن التاريخ تقديري من التعيين", row["needs_update"] is True)
check("عمود الدورة وتنبيه التحديث ظاهرين في الصفحة", "needs_update" not in html or "⚠" in html)
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "last_leave_return", "value": (date.today() - timedelta(days=5)).isoformat()})
check("تسجيل آخر رجوع من إجازة مباشرة من الجدول بيتحفظ", r.status_code == 200 and r.get_json()["ok"] and
      raw4.execute("SELECT last_leave_return FROM employees WHERE id=?", (expat_id,)).fetchone()[0] == (date.today() - timedelta(days=5)).isoformat())
row2 = db.leave_rotation_status(raw4, raw4.execute("SELECT * FROM employees WHERE id=?", (expat_id,)).fetchone())
check("بعد تسجيل رجوع حقيقي: مفيش تنبيه 'محتاج تحديث' ورقم الدورة رجع للأولى", row2["needs_update"] is False and row2["cycle_no"] == 1)
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "last_leave_return", "value": (date.today() + timedelta(days=5)).isoformat()})
check("تاريخ رجوع في المستقبل مرفوض", r.status_code == 400)

# --- الأعمدة الجديدة: البصمة، المسمى الوظيفي، عدد أيام آخر إجازة، وتبويب المقيمين
html = c.get("/leaves/rotation").data.decode()
check("عمود البصمة والمسمى الوظيفي قابلين للتعديل في جدول المغتربين",
      'data-field="fingerprint_no"' in html and 'data-field="job_title"' in html and 'data-days-pick' in html)
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "fingerprint_no", "value": "7777"})
check("تعديل البصمة من جدول دورة الإجازة يتحفظ",
      r.status_code == 200 and raw4.execute("SELECT fingerprint_no FROM employees WHERE id=?", (expat_id,)).fetchone()[0] == "7777")
clash_emp = emp_ids[b1][1]
raw4.execute("UPDATE employees SET fingerprint_no='8123' WHERE id=?", (clash_emp,)); raw4.commit()
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "fingerprint_no", "value": "8123"})
check("تعديل البصمة لرقم مستخدم بالفعل في نفس الفرع مرفوض", r.status_code == 400)
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "job_title", "value": "شيف أول"})
check("تعديل المسمى الوظيفي من جدول دورة الإجازة يتحفظ",
      r.status_code == 200 and raw4.execute("SELECT job_title FROM employees WHERE id=?", (expat_id,)).fetchone()[0] == "شيف أول")
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "last_leave_days", "value": "1"})
check("تسجيل عدد أيام آخر إجازة (يوم واحد) يتحفظ",
      r.status_code == 200 and raw4.execute("SELECT last_leave_days FROM employees WHERE id=?", (expat_id,)).fetchone()[0] == 1)
r = post(c, "/leaves/rotation/update", {"emp_id": expat_id, "field": "last_leave_days", "value": "40"})
check("عدد أيام خارج النطاق (1-30) مرفوض", r.status_code == 400)
html_res = c.get("/leaves/rotation?view=resident").data.decode()
check("تبويب المقيمين منفصل وفيه الأعمدة المطلوبة",
      "يوم الإجازة الأسبوعي" in html_res and 'data-field="last_leave_return"' not in html_res)
resident_id = emp_ids[b1][1]
raw4.execute("UPDATE employees SET residence_type='مقيم' WHERE id=?", (resident_id,)); raw4.commit()
r = post(c, "/leaves/rotation/update", {"emp_id": resident_id, "field": "weekly_day_off", "value": "الجمعة"})
check("تسجيل يوم الإجازة الأسبوعي مباشرة من الجدول بيتحفظ", r.status_code == 200 and
      raw4.execute("SELECT weekly_day_off FROM employees WHERE id=?", (resident_id,)).fetchone()[0] == "الجمعة")
r = post(m, "/leaves/rotation/update", {"emp_id": emp_ids[b2][0], "field": "weekly_day_off", "value": "السبت"})
check("مدير فرع 1 ما يعدّلش دورة إجازة موظف فرع 2", raw4.execute("SELECT weekly_day_off FROM employees WHERE id=?", (emp_ids[b2][0],)).fetchone()[0] != "السبت")

# ================================================================ القوة التشغيلية: أسامي وتصدير
print("\n[10] القوة التشغيلية: عرض الأسامي وتصدير التقارير")
today_iso = date.today().isoformat()
raw4.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'present') "
            "ON CONFLICT(employee_id, date) DO UPDATE SET status='present'", (emp_ids[b1][0], today_iso))
raw4.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'absence') "
            "ON CONFLICT(employee_id, date) DO UPDATE SET status='absence'", (emp_ids[b1][1], today_iso))
raw4.commit()
html = c.get(f"/sub-departments?date={today_iso}").data.decode()
n0 = raw4.execute("SELECT name FROM employees WHERE id=?", (emp_ids[b1][0],)).fetchone()["name"]
n1 = raw4.execute("SELECT name FROM employees WHERE id=?", (emp_ids[b1][1],)).fetchone()["name"]
check("صفحة القوة التشغيلية فيها زرار عرض الأسامي وأسماء الموظفين فعليًا", "wf-names-btn" in html and n0 in html and n1 in html)
check("حالة كل موظف ظاهرة بالعربي جنب اسمه", "حاضر" in html and "غياب" in html)
r = m.get(f"/sub-departments?date={today_iso}")
html_m = r.data.decode()
check("مدير فرع 1 يشوف بس أسامي فرعه", n0 in html_m and raw4.execute(
    "SELECT name FROM employees WHERE id=?", (emp_ids[b2][0],)).fetchone()["name"] not in html_m)
r = c.get(f"/sub-departments/export.xlsx?date={today_iso}")
check("تصدير Excel للقوة التشغيلية شغّال", r.status_code == 200 and r.data[:2] == b"PK")
r = c.get(f"/sub-departments?date={today_iso}&department=مطبخ")
check("فلترة القسم شغّالة", r.status_code == 200)
r = c.get(f"/sub-departments/print?date={today_iso}")
html_print = r.data.decode()
check("صفحة الطباعة المخصّصة للقوة التشغيلية تفتح وفيها الأسامي وزرار PDF",
      r.status_code == 200 and n0 in html_print and "pdfBtn" in html_print and "st-present" in html_print)
r = m.get(f"/sub-departments/print?branch_id={b2}&date={today_iso}")
check("مدير فرع 1 ما يقدرش يطبع تقرير فرع 2", r.status_code == 302)

# ================================================================ استيراد الحضور: شهور قديمة وأرقام أيام بس
print("\n[11] استيراد الحضور: شهر قديم صريح + أعمدة أرقام أيام (زي أجهزة البصمة)")
import openpyxl as _oxl
imp_emp = emp_ids[b1][2]
imp_fp = raw4.execute("SELECT fingerprint_no FROM employees WHERE id=?", (imp_emp,)).fetchone()[0]

# ملف مفيهوش شهر محدد → لازم يترفض
wb = _oxl.Workbook(); ws = wb.active
ws.append(["بصمة", "اسم", 1, 2, 3])
ws.append([imp_fp, "اسم", "P", "P", "X"])
buf = io.BytesIO(); wb.save(buf); buf.seek(0)
r = c.post("/attendance/import", data={"csrf_token": token(c), "file": (buf, "noMonth.xlsx")}, content_type="multipart/form-data")
check("استيراد بدون تحديد شهر مرفوض", "لازم تحدد الشهر" in c.get("/attendance/import").data.decode() or r.status_code == 302)

# شهر قديم فعلي (5 شهور قبل الحالي) بأعمدة أرقام أيام بس — لازم يتسجل حسب الفترة المحاسبية (29 → 28)
# مش الشهر الميلادي العادي: يوم 1 في الملف المفروض يترجم لأول يوم في الفترة (يوم 29 من الشهر اللي قبله)
old_month_date = (date.today().replace(day=1) - timedelta(days=150))
old_ym = old_month_date.strftime("%Y-%m")
old_p_start, old_p_end = db.period_bounds(old_ym, A.MONTH_START_DAY)
period_len = (old_p_end - old_p_start).days + 1
wb2 = _oxl.Workbook(); ws2 = wb2.active
ws2.append(["بصمة", "اسم", 1, 2, 15, period_len])
ws2.append([imp_fp, "اسم", "P", "X", "O", "P"])
buf2 = io.BytesIO(); wb2.save(buf2); buf2.seek(0)
r = c.post("/attendance/import", data={"branch_id": b1, "month": old_ym, "csrf_token": token(c), "file": (buf2, "oldMonth.xlsx")},
           content_type="multipart/form-data")
rows = raw4.execute(
    "SELECT date, status FROM attendance WHERE employee_id=? AND date BETWEEN ? AND ?",
    (imp_emp, old_p_start.isoformat(), old_p_end.isoformat())).fetchall()
got = {r["date"]: r["status"] for r in rows}
expected = {
    old_p_start.isoformat(): "present",
    (old_p_start + timedelta(days=1)).isoformat(): "absence",
    (old_p_start + timedelta(days=14)).isoformat(): "leave",
    old_p_end.isoformat(): "present",
}
check(f"استيراد شهر قديم ({old_ym}) بأعمدة أرقام أيام بس اتسجّل حسب الفترة المحاسبية الصحيحة (29→28)",
      got == expected, f"got={got} expected={expected}")
check("يوم 1 في الملف اتربط بأول يوم في الفترة المحاسبية (يوم 29 من الشهر اللي قبله) مش أول يوم ميلادي",
      old_p_start.day == A.MONTH_START_DAY and old_p_start.isoformat() in got)

# نفس المنطق لشهر مختلف تاني (الشهر الحالي) — يتأكد إن الاستيراد مش دايمًا بيروح لآخر شهر
cur_ym = db.current_period_label(A.MONTH_START_DAY)
cur_p_start, _cur_p_end = db.period_bounds(cur_ym, A.MONTH_START_DAY)
wb3 = _oxl.Workbook(); ws3 = wb3.active
ws3.append(["بصمة", "اسم", 1])
ws3.append([imp_fp, "اسم", "O"])
buf3 = io.BytesIO(); wb3.save(buf3); buf3.seek(0)
c.post("/attendance/import", data={"branch_id": b1, "month": cur_ym, "csrf_token": token(c), "file": (buf3, "curMonth.xlsx")},
       content_type="multipart/form-data")
still_old = raw4.execute("SELECT status FROM attendance WHERE employee_id=? AND date=?", (imp_emp, old_p_start.isoformat())).fetchone()[0]
check("استيراد شهر تاني ما بيلخبطش بيانات الشهر القديم اللي اتسجل قبل كده", still_old == "present")
new_cur = raw4.execute("SELECT status FROM attendance WHERE employee_id=? AND date=?", (imp_emp, cur_p_start.isoformat())).fetchone()[0]
check("استيراد الشهر الحالي اتسجّل في تاريخ بداية فترته الصحيح (يوم 29)", new_cur == "leave" and cur_p_start.day == A.MONTH_START_DAY)

# ملف فيه تاريخ كامل (زي النموذج المُصدَّر) لشهر قديم كمان لازم يشتغل صح باستخدام تاريخه الحقيقي
wb4 = _oxl.Workbook(); ws4 = wb4.active
ws4.append(["بصمة", "اسم", date(old_month_date.year, old_month_date.month, 10)])
ws4.append([imp_fp, "اسم", "M"])
buf4 = io.BytesIO(); wb4.save(buf4); buf4.seek(0)
c.post("/attendance/import", data={"branch_id": b1, "month": old_ym, "csrf_token": token(c), "file": (buf4, "fullDate.xlsx")},
       content_type="multipart/form-data")
check("ملف بتاريخ كامل (مش رقم يوم بس) لشهر قديم اتسجّل صح",
      raw4.execute("SELECT status FROM attendance WHERE employee_id=? AND date=?", (imp_emp, f"{old_ym}-10")).fetchone()[0] == "mission")

html = c.get("/attendance/import").data.decode()
check("صفحة الاستيراد فيها لوحة مقارنة الشهور المسجّلة", old_ym in html and cur_ym in html)

# نموذج التصدير الفاضي لازم يبني أعمدة الفترة المحاسبية (29 → 28) مش الشهر الميلادي 1 → نهاية الشهر
import openpyxl as _oxl2
r2 = c.get(f"/attendance/import/template.xlsx?branch_id={b1}&month={cur_ym}")
wbchk2 = _oxl2.load_workbook(io.BytesIO(r2.data))
wschk = wbchk2.active
first_date_cell = wschk.cell(row=1, column=3).value
check("نموذج تصدير الحضور الفاضي أول عمود تاريخ فيه = بداية الفترة المحاسبية (يوم 29) مش أول يوم ميلادي",
      hasattr(first_date_cell, "day") and first_date_cell.day == A.MONTH_START_DAY, str(first_date_cell))
last_col = 3
while wschk.cell(row=1, column=last_col + 1).value not in (None, ""):
    last_col += 1
last_date_cell = wschk.cell(row=1, column=last_col).value
check("آخر عمود تاريخ في النموذج = آخر يوم في الفترة المحاسبية (يوم 28)",
      hasattr(last_date_cell, "day") and last_date_cell.day == A.MONTH_START_DAY - 1, str(last_date_cell))

# ================================================================ طباعة القوة التشغيلية: A4 صحيح وصفحة واحدة
print("\n[12] طباعة القوة التشغيلية: مقاس A4 صحيح مع مارچن، وكل البيانات في صفحة واحدة")
wf_html = open(os.path.join(ROOT, "templates", "workforce_print.html"), encoding="utf-8").read()
check("مفيش تعارض مارچن (@page) مع عرض ورقة كامل 210مم في نفس الوقت",
      not ("width:210mm" in wf_html.replace(" ", "") and "margin:12mm" in wf_html.replace(" ", "")))
check("الورقة بتستخدم نفس مقاسات A4 المضبوطة (284.5mm x 197mm بعد خصم المارچن) زي باقي التقارير",
      "284.5mm" in wf_html and "197mm" in wf_html)
if A.find_pdf_browser():
    for n_emps, label in ((6, "عدد قليل"), (50, "عدد كبير")):
        raw5 = sqlite3.connect(db.DB_PATH); raw5.row_factory = sqlite3.Row
        bx = raw5.execute("INSERT INTO branches (name) VALUES (?)", (f"فرع اختبار طباعة {n_emps}",)).lastrowid
        ids = []
        for i in range(n_emps):
            ids.append(raw5.execute(
                "INSERT INTO employees (branch_id, fingerprint_no, name, department, sub_department, job_title, "
                "base_salary, start_date, status) VALUES (?,?,?,?,?,?,?,?, 'active')",
                (bx, f"p{n_emps}{i}", f"موظف {i}", "مطبخ", "قسم فرعي", "وظيفة", 3000, "2025-01-01")).lastrowid)
        for eid in ids:
            raw5.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'present')", (eid, today_iso))
        raw5.commit()
        tok = token(c)
        resp = c.get(f"/sub-departments/print?branch_id={bx}&date={today_iso}")
        pdf_resp = None
        with A.app.test_request_context():
            pass
        # نولّد PDF فعلي عن طريق نفس آلية السيرفر لمحتوى الصفحة
        html_page = resp.data.decode()
        pdf_r = c.post("/pdf/export?name=test&o=landscape", data=html_page.encode("utf-8"),
                       headers={"Content-Type": "text/html; charset=utf-8", "X-CSRF-Token": tok})
        check(f"تصدير PDF فعلي ({label}: {n_emps} موظف) نجح", pdf_r.status_code == 200 and pdf_r.data[:5] == b"%PDF-")

        if pdf_r.status_code == 200:
            tmp_pdf = os.path.join(tempfile.mkdtemp(prefix="pdfcheck_"), "out.pdf")
            with open(tmp_pdf, "wb") as fh:
                fh.write(pdf_r.data)
            info = subprocess.run(["pdfinfo", tmp_pdf], capture_output=True, text=True).stdout
            pages_line = next((ln for ln in info.splitlines() if ln.startswith("Pages:")), "")
            size_line = next((ln for ln in info.splitlines() if ln.startswith("Page size:")), "")
            n_pages = int(pages_line.split(":")[1].strip()) if pages_line else -1
            check(f"({label}) البيانات كلها في صفحة واحدة", n_pages == 1, f"pages={n_pages}")
            check(f"({label}) مقاس الصفحة A4 فعلي (~842x595pt للعرضي)",
                  "841" in size_line or "842" in size_line, size_line)
else:
    print("  (تخطّي فحص PDF الفعلي — مفيش Edge/Chrome على السيرفر ده)")

# ================================================================ دورة الإجازة: اكتشاف تلقائي من الحضور
print("\n[13] دورة الإجازة بتسحب تلقائيًا من سجل الحضور المستورد")
auto_emp = emp_ids[b1][3]
raw4.execute("UPDATE employees SET residence_type='مغترب', start_date='2024-01-01', last_leave_return=NULL, last_leave_days=NULL WHERE id=?", (auto_emp,))
raw4.execute("DELETE FROM attendance WHERE employee_id=?", (auto_emp,))
# سلسلة إجازة متتالية (3 أيام) اتقفلت برجوع فعلي (حضور) — ده اللي المفروض يتكشف تلقائيًا
leave_start = date.today() - timedelta(days=10)
for i in range(3):
    raw4.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'leave')", (auto_emp, (leave_start + timedelta(days=i)).isoformat()))
return_day = leave_start + timedelta(days=3)
raw4.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'present')", (auto_emp, return_day.isoformat()))
raw4.commit()
row = db.leave_rotation_status(raw4, raw4.execute("SELECT * FROM employees WHERE id=?", (auto_emp,)).fetchone())
check("آخر رجوع من إجازة اتكشف تلقائيًا من سلسلة الحضور (3 أيام إجازة + يوم رجوع)",
      row["last_return"] == return_day.isoformat() and row["anchor_from_attendance"] is True, str(row))
check("عدد أيام آخر إجازة اتكشف تلقائيًا = 3 وعلّم إنه تلقائي", row["last_leave_days"] == 3 and row["last_leave_days_is_auto"] is True)
check("مفيش تنبيه 'محتاج تحديث' لأن المصدر حضور حقيقي مش تخمين من التعيين", row["needs_update"] is False)
html = c.get("/leaves/rotation").data.decode()
check("علامة 🔄 الاكتشاف التلقائي ظاهرة في صفحة دورة الإجازة", "🔄" in html and "من الحضور المستورد" in html)

# لو فيه إجازة لسه مستمرة (مفيش يوم رجوع بعدها) — النظام ميستخدمهاش كمصدر لحد ما ترجع فعليًا
still_on_leave = emp_ids[b1][4]
raw4.execute("UPDATE employees SET residence_type='مغترب', start_date='2024-01-01', last_leave_return=NULL, last_leave_days=NULL WHERE id=?", (still_on_leave,))
raw4.execute("DELETE FROM attendance WHERE employee_id=?", (still_on_leave,))
raw4.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'leave')", (still_on_leave, (date.today() - timedelta(days=1)).isoformat()))
raw4.commit()
row2 = db.leave_rotation_status(raw4, raw4.execute("SELECT * FROM employees WHERE id=?", (still_on_leave,)).fetchone())
check("إجازة لسه مستمرة (من غير رجوع مسجّل) ما بتتاخدش كتاريخ رجوع تلقائي",
      row2["anchor_from_attendance"] is False)

# تسجيل يدوي بعد كده لازم ياخد الأولوية على الاكتشاف التلقائي لو كان أحدث
r = post(c, "/leaves/rotation/update", {"emp_id": auto_emp, "field": "last_leave_return", "value": date.today().isoformat()})
row3 = db.leave_rotation_status(raw4, raw4.execute("SELECT * FROM employees WHERE id=?", (auto_emp,)).fetchone())
check("التسجيل اليدوي الأحدث بياخد الأولوية على القيمة المكتشفة تلقائيًا",
      row3["last_return"] == date.today().isoformat() and row3["anchor_from_attendance"] is False)

# ================================================================ تصدير كشف المرتبات: يتظبط في عرض صفحة واحدة
print("\n[14] تصدير كشف المرتبات: الأعمدة بتتظبط في عرض صفحة واحدة عند الطباعة")
import openpyxl as _oxl3
r = c.get(f"/payroll/sheet/export.xlsx?branch_id={b1}")
wbx = _oxl3.load_workbook(io.BytesIO(r.data))
wsx = wbx.active
check("ورقة الإكسل مضبوطة للطباعة في عرض صفحة واحدة (fit-to-width)",
      wsx.sheet_properties.pageSetUpPr.fitToPage is True and wsx.page_setup.fitToWidth == 1)
check("عنوان الكشف بيغطي كل الأعمدة الستة (مش بس أول 5)", "A1:F1" in [str(m) for m in wsx.merged_cells.ranges])
# فحص فعلي بمحوّل حقيقي (LibreOffice) للتأكد إن الملف فعلًا بيطبع في صفحة واحدة، مش بس إعدادات صحيحة بالاسم
soffice = shutil.which("soffice") or shutil.which("libreoffice")
if soffice:
    tmp_dir = tempfile.mkdtemp(prefix="xlsxcheck_")
    xlsx_path = os.path.join(tmp_dir, "sheet.xlsx")
    with open(xlsx_path, "wb") as fh:
        fh.write(r.data)
    conv = subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", tmp_dir, xlsx_path],
                          capture_output=True, text=True, timeout=60)
    pdf_path = os.path.join(tmp_dir, "sheet.pdf")
    if os.path.exists(pdf_path):
        info = subprocess.run(["pdfinfo", pdf_path], capture_output=True, text=True).stdout
        pages_line = next((ln for ln in info.splitlines() if ln.startswith("Pages:")), "")
        n_pages = int(pages_line.split(":")[1].strip()) if pages_line else -1
        check("الملف فعليًا بيطبع في صفحة واحدة بالعرض (محوَّل حقيقي بـ LibreOffice)", n_pages == 1, f"pages={n_pages}")
    else:
        print("  (تخطّي: تعذّر تحويل الملف بـ LibreOffice)")
else:
    print("  (تخطّي فحص LibreOffice الفعلي — مش متاح على السيرفر ده)")

html_sheet = c.get(f"/payroll/sheet?branch_id={b1}").data.decode()
check("زرار تحميل PDF موجود في كشف المرتبات", "pdfBtn" in html_sheet and "psPrintArea" in html_sheet)

print(f"\nالنتيجة: {results['pass']} نجح / {results['fail']} فشل")
sys.exit(1 if results["fail"] else 0)
