"""
اختبار واجهة حقيقي بمتصفح (Playwright): بيتأكد إن أزرار "تعديل" و"تسوية" فعليًا
بتفتح صف التفاصيل تحتها، مش بس إن الـ HTML شكله سليم. ده نوع أخطاء مايتصيدهوش
اختبار HTTP العادي (smoke_test.py) لأنه بيحصل بس لما جافاسكريبت شغّال فعليًا في المتصفح.

يتطلب: pip install playwright && playwright install chromium
تشغيل:  python tests/ui_smoke_test.py
"""
import os
import re
import sys
import tempfile
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["APP_SECRET_KEY"] = "ui-test-secret"

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("Playwright غير مثبّت — تخطّي اختبار الواجهة (ده اختياري، smoke_test.py الأساسي يكفي).")
    sys.exit(0)

TMP = tempfile.mkdtemp(prefix="lythi_ui_test_")
import database as db  # noqa: E402
db.DB_PATH = os.path.join(TMP, "app.db")
db.BACKUPS_DIR = os.path.join(TMP, "backups")
db.UPLOADS_DIR = os.path.join(TMP, "uploads")
import app as A  # noqa: E402

results = {"pass": 0, "fail": 0}


def check(name, cond):
    if cond:
        results["pass"] += 1
        print(f"  ✔ {name}")
    else:
        results["fail"] += 1
        print(f"  ✘ {name}")


# ---- بيانات تجريبية
conn = db.get_db()
b1 = conn.execute("SELECT id FROM branches").fetchone()[0]
eid = conn.execute(
    "INSERT INTO employees (branch_id, fingerprint_no, name, department, base_salary, start_date, status) "
    "VALUES (?, '1', 'موظف تجريبي', 'مطبخ', 3000, '2025-01-01', 'active')", (b1,)).lastrowid
conn.execute(
    "INSERT INTO advances (employee_id, principal_amount, monthly_installment, remaining_balance, status, decided_at) "
    "VALUES (?, 1000, 200, 1000, 'pending', ?)", (eid, date.today().isoformat()))
conn.execute("INSERT INTO shift_types (name, start_time, end_time) VALUES ('صباحي تجريبي', '08:00', '16:00')")
conn.execute(
    "INSERT INTO employees (branch_id, fingerprint_no, name, department, job_title, base_salary, start_date, status) "
    "VALUES (?, '900', 'موظف كشف المرتبات', 'مطبخ', 'شيف', 20000, '2025-01-01', 'active')", (b1,))
conn.commit()

import threading  # noqa: E402
from werkzeug.serving import make_server  # noqa: E402
PORT = 5099
srv = make_server("127.0.0.1", PORT, A.app, threaded=True)
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{PORT}"


def click_and_check_toggle(page, url, button_text, label):
    page.goto(BASE + url)
    page.wait_for_timeout(300)
    btn = page.locator(f"button:has-text('{button_text}')").first
    if btn.count() == 0:
        check(f"{label}: زرار {button_text} موجود", False)
        return
    onclick = btn.get_attribute("onclick") or ""
    m = re.search(r"'([^']+)'", onclick)
    if not m:
        check(f"{label}: الزرار مربوط بدالة toggle", False)
        return
    target_id = m.group(1)
    before = page.eval_on_selector(f"#{target_id}", "el => el.style.display")
    btn.click()
    page.wait_for_timeout(250)
    after = page.eval_on_selector(f"#{target_id}", "el => el.style.display")
    check(f"{label}: زرار {button_text} بيفتح صف التفاصيل فعليًا", before != after and after == "table-row")


with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1366, "height": 900})
    page.goto(BASE + "/login")
    page.fill("input[name=username]", "admin")
    page.fill("input[name=password]", "admin123")
    page.click("button[type=submit]")
    page.wait_for_load_state()
    page.fill("input[name=current_password]", "admin123")
    page.fill("input[name=new_password]", "UiTest#123")
    page.fill("input[name=confirm_password]", "UiTest#123")
    page.click("button[type=submit]")
    page.wait_for_load_state()

    click_and_check_toggle(page, "/users", "تعديل", "المستخدمون")
    click_and_check_toggle(page, "/advances", "تعديل", "السلف")
    click_and_check_toggle(page, "/shifts", "تعديل", "أنواع الشفتات")

    # صفحة الرواتب: زر "تسوية" يظهر فقط لو فيه صف موظف — تأكد إنه شغّال لو موجود
    page.goto(BASE + f"/payroll")
    page.wait_for_timeout(400)
    if page.locator("button:has-text('تسوية')").count() > 0:
        click_and_check_toggle(page, "/payroll", "تسوية", "الرواتب")

    # كشف المرتبات: خلية المرتب لازم تكون فعليًا قابلة للتحرير (مش بس شكلها كده) — تعديل حقيقي بالكيبورد
    page.goto(BASE + "/payroll/sheet")
    page.wait_for_timeout(400)
    cell = page.locator("td.sal[data-field=base_salary]").first
    if cell.count() > 0:
        before_db = cell.inner_text()
        cell.click()
        page.evaluate("""() => {
            var td = document.querySelector('td.sal[data-field=base_salary]');
            var range = document.createRange(); range.selectNodeContents(td);
            var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
        }""")
        page.keyboard.type("27500")
        page.keyboard.press("Tab")
        page.wait_for_timeout(500)
        after_text = cell.inner_text()
        check("كشف المرتبات: خلية المرتب فعليًا قابلة للتحرير وبتتحفظ (مش بس شكلها contenteditable)",
              before_db != after_text and after_text.replace(",", "") == "27500")
    else:
        check("كشف المرتبات: فيه خلية مرتب نقدر نختبرها", False)

    browser.close()

print(f"\nالنتيجة: {results['pass']} نجح / {results['fail']} فشل")
sys.exit(1 if results["fail"] else 0)
